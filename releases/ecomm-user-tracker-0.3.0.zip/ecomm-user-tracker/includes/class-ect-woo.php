<?php
/**
 * WooCommerce: link each new order to the visit it came from (for "sales by source").
 * Orders themselves are read from WooCommerce (HPOS compatible), not copied.
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Woo {

	const META = '_ect_session';

	public static function active() {
		return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_orders' );
	}

	public static function init() {
		add_action( 'woocommerce_new_order', array( __CLASS__, 'attach' ), 10, 2 );
		add_action( 'woocommerce_add_to_cart', array( __CLASS__, 'added_to_cart' ), 10, 4 );
	}

	/** Visit (session row id) of the current browser, from the tracker cookie. */
	public static function current_session() {
		$sid = isset( $_COOKIE['ect_sid'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['ect_sid'] ) ) : '';
		if ( ! preg_match( '/^[a-zA-Z0-9]{16,40}$/', $sid ) ) {
			return array( '', 0 );
		}
		$skey = ECT_Tracker::session_key( $sid );
		return array( $skey, ECT_DB::session_id_by_key( $skey ) );
	}

	/** Pro+: add to cart step for the funnel and abandoned carts. */
	public static function added_to_cart( $cart_key, $product_id, $quantity, $variation_id ) {
		if ( ! ECT_License::has( 'proplus' ) ) {
			return;
		}
		list( , $session_id ) = self::current_session();
		if ( ! $session_id ) {
			return;
		}
		$product = wc_get_product( $variation_id ? $variation_id : $product_id );
		$value   = $product ? (float) wc_get_price_to_display( $product ) * (int) $quantity : 0;
		ECT_DB::stage( $session_id, 2, $value );
		ECT_DB::event( $session_id, 'add_to_cart', $product ? $product->get_name() : '#' . $product_id, '', $value );
	}

	public static function attach( $order_id, $order = null ) {
		if ( ! ECT_License::has( 'pro' ) || is_admin() && ! wp_doing_ajax() ) {
			return;
		}
		$sid = isset( $_COOKIE['ect_sid'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['ect_sid'] ) ) : '';
		if ( ! preg_match( '/^[a-zA-Z0-9]{16,40}$/', $sid ) ) {
			return;
		}
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order_id );
		if ( $order ) {
			$skey = ECT_Tracker::session_key( $sid );
			$order->update_meta_data( self::META, $skey );
			$order->save_meta_data();
			$session_id = ECT_DB::session_id_by_key( $skey );
			if ( $session_id && ECT_License::has( 'proplus' ) ) {
				ECT_DB::stage( $session_id, 4 );
				ECT_DB::event( $session_id, 'purchase', '#' . $order->get_id(), '', (float) $order->get_total() );
			}
		}
	}

	public static function paid_statuses() {
		return apply_filters( 'ect_paid_order_statuses', array( 'wc-processing', 'wc-completed', 'wc-on-hold' ) );
	}

	/** @return WC_Order[] */
	public static function orders( $from, $to ) {
		if ( ! self::active() ) {
			return array();
		}
		return wc_get_orders(
			array(
				'status'       => self::paid_statuses(),
				'date_created' => $from . '...' . $to,
				'limit'        => 5000,
				'type'         => 'shop_order',
			)
		);
	}
}
