/* Ecomm User Tracker — lightweight visit tracker. */
(function () {
	var cfg = window.ectCfg;
	if (!cfg || !window.fetch) return;
	if (cfg.dnt && (navigator.doNotTrack === '1' || window.doNotTrack === '1')) return;
	if (navigator.webdriver) return;

	var ID_RE = /^[a-zA-Z0-9]{16,40}$/;
	function rnd() {
		var a = new Uint8Array(16);
		(window.crypto || window.msCrypto).getRandomValues(a);
		return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
	}
	function get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
	function set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

	var vid = get('ect_vid');
	if (!vid || !ID_RE.test(vid)) { vid = rnd(); set('ect_vid', vid); }

	// A visit (session) ends after 30 minutes without activity.
	var sid = null;
	function session() {
		var now = Date.now(), cur = get('ect_sid'), last = +get('ect_sid_t') || 0;
		if (!cur || !ID_RE.test(cur) || now - last > 30 * 60 * 1000) cur = rnd();
		set('ect_sid', cur);
		set('ect_sid_t', String(now));
		if (cfg.pro) document.cookie = 'ect_sid=' + cur + ';path=/;SameSite=Lax' + (location.protocol === 'https:' ? ';Secure' : '');
		return cur;
	}

	function params() {
		var out = {}, keys = ['utm_source', 'utm_medium', 'utm_campaign', 'gclid', 'gbraid', 'wbraid', 'msclkid', 'fbclid', 'ttclid'];
		try {
			var sp = new URLSearchParams(location.search);
			keys.forEach(function (k) { if (sp.get(k)) out[k] = sp.get(k).slice(0, 100); });
		} catch (e) {}
		return out;
	}

	function send(e) {
		sid = session();
		var data = { v: vid, s: sid, e: e, p: location.pathname };
		if (e === 'pv') { data.r = document.referrer || ''; data.q = params(); }
		var body = JSON.stringify(data);
		if (navigator.sendBeacon && navigator.sendBeacon(cfg.endpoint, new Blob([body], { type: 'application/json' }))) return;
		fetch(cfg.endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body, keepalive: true, credentials: 'omit' }).catch(function () {});
	}

	var timer = null, sentPv = false;
	function start() {
		if (timer) return;
		send(sentPv ? 'hb' : 'pv');
		sentPv = true;
		timer = setInterval(function () { send('hb'); }, (cfg.interval || 30) * 1000);
	}
	function stop() { clearInterval(timer); timer = null; }

	document.addEventListener('visibilitychange', function () { document.hidden ? stop() : start(); });
	if (!document.hidden) start();
})();
