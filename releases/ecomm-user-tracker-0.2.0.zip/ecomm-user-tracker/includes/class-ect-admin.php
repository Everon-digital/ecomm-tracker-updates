<?php
/**
 * Admin menu, pages, dashboard widget and settings.
 *
 * Free plan: Live visitors + countries are real data. Everything else is shown
 * blurred with dummy data and an Upgrade button (no real data is sent to the browser).
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Admin {

	const SLUG = 'ecomm-user-tracker';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'dashboard_widget' ) );
		add_action( 'admin_post_ect_geo_update', array( __CLASS__, 'handle_geo_update' ) );
		add_action( 'admin_post_ect_license', array( __CLASS__, 'handle_license' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( ECT_FILE ), array( __CLASS__, 'action_links' ) );
		add_action( 'admin_footer-plugins.php', array( __CLASS__, 'deactivate_modal' ) );
		add_action( 'wp_ajax_ect_deactivate_feedback', array( __CLASS__, 'deactivate_feedback' ) );
	}

	public static function pages() {
		return array(
			self::SLUG                    => __( 'Highlights', 'ecomm-user-tracker' ),
			self::SLUG . '-realtime'      => __( 'Real-time', 'ecomm-user-tracker' ),
			self::SLUG . '-traffic'       => __( 'Traffic', 'ecomm-user-tracker' ),
			self::SLUG . '-behavior'      => __( 'Behavior', 'ecomm-user-tracker' ),
			self::SLUG . '-marketing'     => __( 'Marketing', 'ecomm-user-tracker' ),
			self::SLUG . '-recordings'    => __( 'Session Recordings', 'ecomm-user-tracker' ),
			self::SLUG . '-insights'      => __( 'Insights & Benchmarks', 'ecomm-user-tracker' ),
			self::SLUG . '-reports'       => __( 'All Reports', 'ecomm-user-tracker' ),
			self::SLUG . '-settings'      => __( 'Settings', 'ecomm-user-tracker' ),
		);
	}

	public static function menu() {
		add_menu_page(
			__( 'Ecomm User Tracker', 'ecomm-user-tracker' ),
			__( 'Ecomm User Tracker', 'ecomm-user-tracker' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-chart-area',
			3
		);
		foreach ( self::pages() as $slug => $title ) {
			add_submenu_page( self::SLUG, $title, $title, 'manage_options', $slug, array( __CLASS__, 'render' ) );
		}
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">' . esc_html__( 'Dashboard', 'ecomm-user-tracker' ) . '</a>' );
		$links[] = '<a href="' . esc_url( ECT_UPGRADE_URL ) . '" target="_blank" style="font-weight:600">' . esc_html__( 'Upgrade', 'ecomm-user-tracker' ) . '</a>';
		return $links;
	}

	public static function assets( $hook ) {
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 'index.php' !== $hook && ! isset( self::pages()[ $page ] ) ) {
			return;
		}
		wp_enqueue_style( 'ect-admin', ECT_URL . 'assets/css/admin.css', array(), ECT_VERSION );
		wp_enqueue_script( 'ect-admin', ECT_URL . 'assets/js/admin.js', array(), ECT_VERSION, true );
		wp_localize_script(
			'ect-admin',
			'ectAdmin',
			array(
				'endpoint' => esc_url_raw( rest_url( 'ect/v1/live' ) ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'locale'   => str_replace( '_', '-', get_user_locale() ),
				'i18n'     => array(
					'unknown'  => __( 'Unknown', 'ecomm-user-tracker' ),
					'empty'    => __( 'No visitors at the moment', 'ecomm-user-tracker' ),
					'updated'  => __( 'Updated', 'ecomm-user-tracker' ),
				),
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* Page rendering                                                      */
	/* ------------------------------------------------------------------ */

	public static function render() {
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : self::SLUG; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$titles = self::pages();
		echo '<div class="wrap ect-wrap">';
		echo '<div class="ect-header"><div><h1>' . esc_html( isset( $titles[ $page ] ) ? $titles[ $page ] : '' ) . '</h1>';
		echo '<p class="ect-sub">' . esc_html( self::subtitle( $page ) ) . '</p></div>';
		echo '<span class="ect-plan">';
		/* translators: %s: plan name */
		echo esc_html( sprintf( __( '%s plan', 'ecomm-user-tracker' ), ECT_License::label() ) );
		if ( ! ECT_License::has( 'agency' ) ) {
			echo ' · <a href="' . esc_url( ECT_UPGRADE_URL ) . '" target="_blank">' . esc_html__( 'Upgrade', 'ecomm-user-tracker' ) . '</a>';
		}
		echo '</span></div>';
		if ( in_array( $page, array( self::SLUG, self::SLUG . '-traffic', self::SLUG . '-behavior' ), true ) && ECT_License::has( 'pro' ) ) {
			self::range_picker( $page );
		}

		switch ( $page ) {
			case self::SLUG:
				self::page_highlights();
				break;
			case self::SLUG . '-realtime':
				self::page_realtime();
				break;
			case self::SLUG . '-traffic':
				self::page_traffic();
				break;
			case self::SLUG . '-behavior':
				self::page_behavior();
				break;
			case self::SLUG . '-marketing':
				self::page_marketing();
				break;
			case self::SLUG . '-recordings':
				self::page_recordings();
				break;
			case self::SLUG . '-insights':
				self::page_insights();
				break;
			case self::SLUG . '-reports':
				self::page_reports();
				break;
			case self::SLUG . '-settings':
				self::page_settings();
				break;
		}
		echo '</div>';
	}

	private static function subtitle( $page ) {
		$map = array(
			self::SLUG                 => __( "Get a complete overview of your site's activity across all areas.", 'ecomm-user-tracker' ),
			self::SLUG . '-realtime'   => __( 'See how visitors interact with your site in real time.', 'ecomm-user-tracker' ),
			self::SLUG . '-traffic'    => __( "Track your site's traffic trends and get to know your visitors.", 'ecomm-user-tracker' ),
			self::SLUG . '-behavior'   => __( 'Learn how people navigate your site.', 'ecomm-user-tracker' ),
			self::SLUG . '-marketing'  => __( 'See which channels bring visitors, leads and sales.', 'ecomm-user-tracker' ),
			self::SLUG . '-recordings' => __( 'Watch how visitors use your site.', 'ecomm-user-tracker' ),
			self::SLUG . '-insights'   => __( 'Automatic insights and how you compare to similar stores.', 'ecomm-user-tracker' ),
			self::SLUG . '-reports'    => __( 'All reports in one place.', 'ecomm-user-tracker' ),
			self::SLUG . '-settings'   => __( 'Tracking and privacy settings.', 'ecomm-user-tracker' ),
		);
		return isset( $map[ $page ] ) ? $map[ $page ] : '';
	}

	/** Live visitors card — real data (Free). */
	private static function live_card( $with_countries = true ) {
		?>
		<div class="ect-card ect-live" data-ect-live>
			<div class="ect-live-head">
				<span class="ect-dot"></span>
				<span class="ect-live-count" data-ect-count>0</span>
				<span class="ect-live-label"><?php esc_html_e( 'live visitors', 'ecomm-user-tracker' ); ?></span>
			</div>
			<?php if ( $with_countries ) : ?>
				<h3><?php esc_html_e( 'Live visitors by country', 'ecomm-user-tracker' ); ?></h3>
				<ul class="ect-countries" data-ect-countries></ul>
				<p class="ect-empty" data-ect-empty><?php esc_html_e( "No visitors at the moment. Once you have real-time visitors, you'll see where they come from here.", 'ecomm-user-tracker' ); ?></p>
			<?php endif; ?>
			<p class="ect-muted" data-ect-updated></p>
		</div>
		<?php
	}

	/** Blurred locked section with dummy content + Upgrade. */
	private static function locked( $title, $plan, $kind = 'bars', $cols = 1 ) {
		$plan_label = array(
			'pro'     => 'Pro',
			'proplus' => 'Pro+',
			'agency'  => 'Agency',
		)[ $plan ];
		echo '<div class="ect-card ect-locked ect-span-' . (int) $cols . '">';
		echo '<h3>' . esc_html( $title ) . '</h3>';
		echo '<div class="ect-blur" aria-hidden="true">' . self::dummy( $kind ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="ect-lock-overlay"><span class="ect-badge">' . esc_html( $plan_label ) . '</span>';
		echo '<a class="button button-primary" href="' . esc_url( ECT_UPGRADE_URL . '&utm_content=' . rawurlencode( sanitize_title( $title ) ) ) . '" target="_blank">';
		/* translators: %s: plan name */
		echo esc_html( sprintf( __( 'Upgrade to %s', 'ecomm-user-tracker' ), $plan_label ) ) . '</a></div>';
		echo '</div>';
	}

	/** Static fake content — never real data. */
	private static function dummy( $kind ) {
		switch ( $kind ) {
			case 'kpis':
				$h = '<div class="ect-kpis">';
				foreach ( array( array( 'Site sessions', '1,284', '+12%' ), array( 'Total sales', '$4,920', '+8%' ), array( 'Total orders', '96', '+5%' ), array( 'Unique visitors', '842', '+9%' ) ) as $k ) {
					$h .= '<div class="ect-kpi"><span>' . $k[0] . '</span><strong>' . $k[1] . '</strong><em>' . $k[2] . '</em></div>';
				}
				return $h . '</div>';
			case 'chart':
				$h = '<svg viewBox="0 0 300 90" class="ect-fake-chart"><polyline fill="none" stroke="currentColor" stroke-width="3" points="0,70 30,55 60,62 90,40 120,48 150,25 180,35 210,20 240,30 270,12 300,22"/></svg>';
				return $h;
			case 'donut':
				return '<svg viewBox="0 0 42 42" class="ect-fake-donut"><circle cx="21" cy="21" r="15.9" fill="none" stroke="#c7d7fe" stroke-width="6"/><circle cx="21" cy="21" r="15.9" fill="none" stroke="currentColor" stroke-width="6" stroke-dasharray="70 30" stroke-dashoffset="25"/></svg>';
			case 'funnel':
				$h = '<div class="ect-fake-funnel">';
				foreach ( array( 100, 62, 30, 18, 9 ) as $v ) {
					$h .= '<span style="height:' . $v . '%"></span>';
				}
				return $h . '</div>';
			case 'cards':
				return '<div class="ect-fake-row"></div><div class="ect-fake-row"></div><div class="ect-fake-row short"></div>';
			default:
				$h = '<ul class="ect-fake-bars">';
				foreach ( array( array( '/homepage', 90 ), array( '/shop', 64 ), array( '/product/shoes', 41 ), array( '/cart', 22 ) ) as $b ) {
					$h .= '<li><span>' . $b[0] . '</span><i style="width:' . $b[1] . '%"></i></li>';
				}
				return $h . '</ul>';
		}
	}

	private static function grid_open( $cols = 3 ) {
		echo '<div class="ect-grid ect-cols-' . (int) $cols . '">';
	}

	private static function grid_close() {
		echo '</div>';
	}

	/* ------------------------------------------------------------------ */
	/* Helpers for real (Pro) data                                         */
	/* ------------------------------------------------------------------ */

	private static function range_days() {
		$allowed = ECT_License::has( 'proplus' ) ? array( 1, 7, 30, 90, 365 ) : array( 1, 7, 30 );
		$d       = isset( $_GET['range'] ) ? (int) $_GET['range'] : 30; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return in_array( $d, $allowed, true ) ? $d : 30;
	}

	private static function range_picker( $page ) {
		$labels = array(
			1   => __( 'Today', 'ecomm-user-tracker' ),
			7   => __( 'Last 7 days', 'ecomm-user-tracker' ),
			30  => __( 'Last 30 days', 'ecomm-user-tracker' ),
			90  => __( 'Last 90 days', 'ecomm-user-tracker' ),
			365 => __( 'Last 12 months', 'ecomm-user-tracker' ),
		);
		$cur = self::range_days();
		echo '<div class="ect-range">';
		foreach ( $labels as $d => $label ) {
			if ( $d > 30 && ! ECT_License::has( 'proplus' ) ) {
				continue;
			}
			$url = add_query_arg( array( 'page' => $page, 'range' => $d ), admin_url( 'admin.php' ) );
			echo '<a class="' . ( $d === $cur ? 'is-active' : '' ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '<span class="ect-muted">' . esc_html__( 'compared to previous period', 'ecomm-user-tracker' ) . '</span></div>';
	}

	private static $rep = null;
	private static $prev = null;

	private static function rep() {
		if ( null === self::$rep ) {
			self::$rep  = new ECT_Reports( self::range_days() );
			self::$prev = self::$rep->previous();
		}
		return self::$rep;
	}

	private static function card( $title, $html, $cols = 1 ) {
		echo '<div class="ect-card ect-span-' . (int) $cols . '"><h3>' . esc_html( $title ) . '</h3>' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/** Show real content if the plan allows, otherwise the blurred upsell. */
	private static function section( $title, $plan, $kind, $cols, $render ) {
		if ( ECT_License::has( $plan ) ) {
			self::card( $title, call_user_func( $render ), $cols );
		} else {
			self::locked( $title, $plan, $kind, $cols );
		}
	}

	private static function soon( $title, $cols = 1 ) {
		self::card( $title, '<p class="ect-empty">' . esc_html__( 'Coming soon in the next update.', 'ecomm-user-tracker' ) . '</p>', $cols );
	}

	private static function change( $now, $before, $lower_is_better = false ) {
		if ( ! $before ) {
			return '';
		}
		$pct = round( 100 * ( $now - $before ) / $before );
		if ( 0 == $pct ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual
			return '<em class="ect-chg">0%</em>';
		}
		$good = $lower_is_better ? $pct < 0 : $pct > 0;
		return '<em class="ect-chg ' . ( $good ? 'up' : 'down' ) . '">' . ( $pct > 0 ? '↑' : '↓' ) . abs( $pct ) . '%</em>';
	}

	private static function kpis( $items ) {
		$h = '<div class="ect-kpis">';
		foreach ( $items as $k ) {
			$h .= '<div class="ect-kpi"><span>' . esc_html( $k[0] ) . '</span><strong>' . esc_html( $k[1] ) . '</strong>' . ( isset( $k[2] ) ? $k[2] : '' ) . '</div>';
		}
		return $h . '</div>';
	}

	private static function money( $v ) {
		if ( function_exists( 'wc_price' ) ) {
			return html_entity_decode( wp_strip_all_tags( wc_price( $v ) ), ENT_QUOTES, 'UTF-8' );
		}
		return number_format_i18n( $v, 2 );
	}

	private static function duration( $sec ) {
		$sec = (int) round( $sec );
		return $sec >= 60 ? sprintf( '%dm %02ds', floor( $sec / 60 ), $sec % 60 ) : $sec . 's';
	}

	/**
	 * Horizontal bar list. $rows: [ [ 'k' => label, 'c' => count, ... ] ].
	 * $type: 'text' | 'country' | 'page'. $value_cb formats the right-hand value.
	 */
	private static function bars( $rows, $type = 'text', $value_cb = null, $empty = '' ) {
		if ( empty( $rows ) ) {
			return '<p class="ect-empty">' . esc_html( $empty ? $empty : __( 'No data for this period yet.', 'ecomm-user-tracker' ) ) . '</p>';
		}
		$max = 1;
		foreach ( $rows as $r ) {
			$max = max( $max, (float) $r['c'] );
		}
		$h = '<ul class="ect-countries">';
		foreach ( $rows as $r ) {
			$k = (string) $r['k'];
			if ( 'country' === $type ) {
				$label = '<span class="ect-c-name" data-ect-cc="' . esc_attr( $k ? $k : 'XX' ) . '">' . esc_html( $k ? $k : '—' ) . '</span>';
			} elseif ( 'device' === $type ) {
				$names = array(
					'mobile'  => __( 'Mobile', 'ecomm-user-tracker' ),
					'desktop' => __( 'Desktop', 'ecomm-user-tracker' ),
					'tablet'  => __( 'Tablet', 'ecomm-user-tracker' ),
				);
				$label = '<span class="ect-c-name">' . esc_html( isset( $names[ $k ] ) ? $names[ $k ] : $k ) . '</span>';
			} else {
				$label = '<span class="ect-c-name">' . esc_html( '' === $k ? '—' : $k ) . '</span>';
			}
			$val = $value_cb ? call_user_func( $value_cb, $r ) : number_format_i18n( $r['c'] );
			$h  .= '<li>' . $label . '<strong>' . esc_html( $val ) . '</strong><i style="width:' . max( 3, (int) round( 100 * $r['c'] / $max ) ) . '%"></i></li>';
		}
		return $h . '</ul>';
	}

	private static function chart( $series ) {
		$n = count( $series );
		if ( ! $n ) {
			return '';
		}
		$max = 0;
		foreach ( $series as $p ) {
			$max = max( $max, $p['value'] );
		}
		$step = max( 1, (int) ceil( $n / 8 ) );
		$fmt  = function ( $v ) {
			return number_format_i18n( $v, $v < 10 && floor( $v ) != $v ? 1 : 0 ); // phpcs:ignore Universal.Operators.StrictComparisons.LooseNotEqual
		};
		$h  = '<div class="ect-chart"><div class="ect-chart-y"><span>' . esc_html( $fmt( $max ) ) . '</span><span>' . esc_html( $fmt( $max / 2 ) ) . '</span><span>0</span></div><div class="ect-chart-body"><div class="ect-chart-bars">';
		foreach ( $series as $p ) {
			$pct = $max ? round( 100 * $p['value'] / $max, 1 ) : 0;
			$h  .= '<span title="' . esc_attr( $p['label'] . ': ' . $fmt( $p['value'] ) ) . '"><i style="height:' . ( $p['value'] ? max( 2, $pct ) : 0 ) . '%"></i></span>';
		}
		$h .= '</div><div class="ect-chart-x">';
		foreach ( $series as $i => $p ) {
			$h .= '<span>' . ( 0 === $i % $step ? esc_html( $p['label'] ) : '' ) . '</span>';
		}
		return $h . '</div></div></div>';
	}

	private static function weekday_chart( $avg ) {
		global $wp_locale;
		$series = array();
		foreach ( $avg as $i => $v ) {
			$series[] = array(
				'label' => $wp_locale ? $wp_locale->get_weekday_abbrev( $wp_locale->get_weekday( $i ) ) : (string) $i,
				'value' => $v,
			);
		}
		return self::chart( $series );
	}

	private static function sales_cache() {
		static $sales = null;
		if ( null === $sales ) {
			$sales = self::rep()->sales();
		}
		return $sales;
	}

	private static function woo_note() {
		return '<p class="ect-empty">' . esc_html__( 'Install WooCommerce to see sales and orders here.', 'ecomm-user-tracker' ) . '</p>';
	}

	/* ------------------------------------------------------------------ */
	/* Pages                                                               */
	/* ------------------------------------------------------------------ */

	private static function page_highlights() {
		self::grid_open( 3 );
		self::live_card( true );
		self::section(
			__( 'Key stats', 'ecomm-user-tracker' ),
			'pro',
			'kpis',
			2,
			function () {
				$t  = self::rep()->totals();
				$pt = self::$prev->totals();
				$items = array(
					array( __( 'Site sessions', 'ecomm-user-tracker' ), number_format_i18n( $t['sessions'] ), self::change( $t['sessions'], $pt['sessions'] ) ),
					array( __( 'Unique visitors', 'ecomm-user-tracker' ), number_format_i18n( $t['visitors'] ), self::change( $t['visitors'], $pt['visitors'] ) ),
				);
				if ( ECT_Woo::active() ) {
					$s  = self::sales_cache();
					$ps = self::$prev->sales();
					$items[] = array( __( 'Total sales', 'ecomm-user-tracker' ), self::money( $s['revenue'] ), self::change( $s['revenue'], $ps['revenue'] ) );
					$items[] = array( __( 'Total orders', 'ecomm-user-tracker' ), number_format_i18n( $s['orders'] ), self::change( $s['orders'], $ps['orders'] ) );
				} else {
					$items[] = array( __( 'Page views', 'ecomm-user-tracker' ), number_format_i18n( $t['pageviews'] ), self::change( $t['pageviews'], $pt['pageviews'] ) );
				}
				return self::kpis( $items );
			}
		);
		self::grid_close();

		echo '<h2 class="ect-section">' . esc_html__( 'Get to know your visitors', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::section( __( 'Sessions over time', 'ecomm-user-tracker' ), 'pro', 'chart', 1, function () { return self::chart( self::rep()->series() ); } );
		self::section( __( 'Top traffic sources', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::bars( self::rep()->sources( 6 ) ); } );
		self::section( __( 'Sessions by location', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::bars( self::rep()->by( 'country', 6 ), 'country' ); } );
		self::grid_close();

		echo '<h2 class="ect-section">' . esc_html__( 'Explore visitor engagement', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::section( __( 'Most visited pages', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::bars( self::rep()->top_pages( 6 ) ); } );
		self::section(
			__( 'Engagement stats', 'ecomm-user-tracker' ),
			'pro',
			'kpis',
			1,
			function () {
				$t = self::rep()->totals();
				return self::kpis(
					array(
						array( __( 'Avg. pages per session', 'ecomm-user-tracker' ), number_format_i18n( $t['per_sess'], 1 ) ),
						array( __( 'Avg. session duration', 'ecomm-user-tracker' ), self::duration( $t['duration'] ) ),
						array( __( 'Bounce rate', 'ecomm-user-tracker' ), $t['bounce'] . '%' ),
					)
				);
			}
		);
		if ( ECT_License::has( 'pro' ) ) {
			self::soon( __( 'Top button clicks', 'ecomm-user-tracker' ) );
		} else {
			self::locked( __( 'Top button clicks', 'ecomm-user-tracker' ), 'pro', 'bars' );
		}
		self::grid_close();
		self::recordings_banner();

		echo '<h2 class="ect-section">' . esc_html__( 'Analyze marketing performance', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::locked( __( 'Google Search Console', 'ecomm-user-tracker' ), 'proplus', 'cards' );
		self::locked( __( 'Email tools', 'ecomm-user-tracker' ), 'proplus', 'cards' );
		self::locked( __( 'Ad accounts', 'ecomm-user-tracker' ), 'proplus', 'cards' );
		self::grid_close();

		echo '<h2 class="ect-section">' . esc_html__( 'Track your sales', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		$money = function ( $r ) {
			return self::money( $r['rev'] );
		};
		self::section( __( 'Top selling items', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () use ( $money ) { return ECT_Woo::active() ? self::bars( self::sales_cache()['items'], 'text', $money, __( 'No products were sold on these dates.', 'ecomm-user-tracker' ) ) : self::woo_note(); } );
		self::section( __( 'Sales by source', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () use ( $money ) { return ECT_Woo::active() ? self::bars( self::sales_cache()['sources'], 'text', $money, __( 'No sales on these dates.', 'ecomm-user-tracker' ) ) : self::woo_note(); } );
		self::section( __( 'Top paying customers', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () use ( $money ) { return ECT_Woo::active() ? self::bars( self::sales_cache()['customers'], 'text', $money, __( "Here you'll see your top customers and the amount they spent.", 'ecomm-user-tracker' ) ) : self::woo_note(); } );
		self::grid_close();

		echo '<h2 class="ect-section">' . esc_html__( 'Monitor store performance', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::section(
			__( 'Top store products', 'ecomm-user-tracker' ),
			'pro',
			'bars',
			1,
			function () {
				return ECT_Woo::active() ? self::bars(
					self::sales_cache()['items'],
					'text',
					function ( $r ) {
						/* translators: %s: quantity */
						return sprintf( __( '%s sold', 'ecomm-user-tracker' ), number_format_i18n( $r['c'] ) );
					},
					__( 'No products in this period.', 'ecomm-user-tracker' )
				) : self::woo_note();
			}
		);
		self::locked( __( 'Conversion funnel', 'ecomm-user-tracker' ), 'proplus', 'funnel', 2 );
		self::grid_close();
	}

	private static function page_realtime() {
		self::grid_open( 3 );
		echo '<div class="ect-span-2">';
		self::live_card( true );
		echo '</div>';
		self::section(
			__( 'Recent visitors', 'ecomm-user-tracker' ),
			'pro',
			'cards',
			1,
			function () {
				$rows = ECT_Reports::recent_sessions( 8 );
				if ( ! $rows ) {
					return '<p class="ect-empty">' . esc_html__( 'No visitors in the last 30 minutes.', 'ecomm-user-tracker' ) . '</p>';
				}
				$icons = array(
					'mobile'  => '📱',
					'tablet'  => '📱',
					'desktop' => '🖥',
				);
				$h = '<ul class="ect-feed">';
				foreach ( $rows as $r ) {
					/* translators: %d: visitor number */
					$h .= '<li><span>' . ( isset( $icons[ $r['device'] ] ) ? $icons[ $r['device'] ] : '' ) . ' ' . esc_html( sprintf( __( 'Visitor #%d', 'ecomm-user-tracker' ), $r['id'] ) ) . ' <span data-ect-cc="' . esc_attr( $r['country'] ? $r['country'] : 'XX' ) . '" data-ect-flag-only></span></span>';
					$h .= '<small>' . esc_html( ECT_Source::label( $r['channel'], $r['source'] ) . ' · ' . $r['exit_page'] . ' · ' . human_time_diff( $r['last_seen'] ) ) . '</small></li>';
				}
				return $h . '</ul>';
			}
		);
		self::grid_close();
		self::grid_open( 3 );
		self::section(
			__( 'Visitors in the last 30 minutes', 'ecomm-user-tracker' ),
			'pro',
			'chart',
			1,
			function () {
				return '<p class="ect-big">' . esc_html( number_format_i18n( ECT_Reports::last30() ) ) . '</p>';
			}
		);
		self::section(
			__( 'Live activity', 'ecomm-user-tracker' ),
			'pro',
			'cards',
			1,
			function () {
				$rows = ECT_Reports::recent_pageviews( 10 );
				if ( ! $rows ) {
					return '<p class="ect-empty">' . esc_html__( 'No activity in the last 24 hours.', 'ecomm-user-tracker' ) . '</p>';
				}
				$h = '<ul class="ect-feed">';
				foreach ( $rows as $r ) {
					/* translators: 1: visitor number, 2: page */
					$h .= '<li><span>' . esc_html( sprintf( __( 'Visitor #%1$d viewed %2$s', 'ecomm-user-tracker' ), $r['sid'], $r['path'] ) ) . '</span><small>' . esc_html( human_time_diff( $r['ts'] ) ) . ' · <span data-ect-cc="' . esc_attr( $r['country'] ? $r['country'] : 'XX' ) . '"></span></small></li>';
				}
				return $h . '</ul>';
			}
		);
		self::section(
			__( 'Pages, sources & devices', 'ecomm-user-tracker' ),
			'pro',
			'donut',
			1,
			function () {
				return '<h4>' . esc_html__( 'Pages', 'ecomm-user-tracker' ) . '</h4>' . self::bars( ECT_Reports::live_breakdown( 'exit_page' ), 'text', null, __( 'No visitors at the moment', 'ecomm-user-tracker' ) )
					. '<h4>' . esc_html__( 'Traffic source', 'ecomm-user-tracker' ) . '</h4>' . self::bars( ECT_Reports::live_sources(), 'text', null, '—' )
					. '<h4>' . esc_html__( 'Device', 'ecomm-user-tracker' ) . '</h4>' . self::bars( ECT_Reports::live_breakdown( 'device' ), 'device', null, '—' );
			}
		);
		self::grid_close();
		self::grid_open( 1 );
		self::locked( __( 'Visitor snapshot', 'ecomm-user-tracker' ), 'proplus', 'funnel' );
		self::grid_close();
	}

	private static function page_traffic() {
		self::grid_open( 3 );
		self::section(
			__( 'Site sessions & unique visitors', 'ecomm-user-tracker' ),
			'pro',
			'kpis',
			2,
			function () {
				$t  = self::rep()->totals();
				$pt = self::$prev->totals();
				return self::kpis(
					array(
						array( __( 'Site sessions', 'ecomm-user-tracker' ), number_format_i18n( $t['sessions'] ), self::change( $t['sessions'], $pt['sessions'] ) ),
						array( __( 'Unique visitors', 'ecomm-user-tracker' ), number_format_i18n( $t['visitors'] ), self::change( $t['visitors'], $pt['visitors'] ) ),
						array( __( 'Page views', 'ecomm-user-tracker' ), number_format_i18n( $t['pageviews'] ), self::change( $t['pageviews'], $pt['pageviews'] ) ),
					)
				);
			}
		);
		self::section( __( 'Sessions by source and category', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::bars( self::rep()->sources( 10 ) ); } );
		self::section( __( 'Sessions over time', 'ecomm-user-tracker' ), 'pro', 'chart', 2, function () { return self::chart( self::rep()->series() ); } );
		self::section( __( 'Avg. sessions by day', 'ecomm-user-tracker' ), 'pro', 'funnel', 1, function () { return self::weekday_chart( self::rep()->weekdays() ); } );
		if ( ECT_License::has( 'pro' ) ) {
			self::soon( __( 'New vs returning visitors', 'ecomm-user-tracker' ) );
		} else {
			self::locked( __( 'New vs returning visitors', 'ecomm-user-tracker' ), 'pro', 'donut' );
		}
		self::section( __( 'Sessions by device', 'ecomm-user-tracker' ), 'pro', 'donut', 1, function () { return self::bars( self::rep()->by( 'device', 3 ), 'device' ); } );
		self::locked( __( 'Traffic insights', 'ecomm-user-tracker' ), 'agency', 'cards' );
		self::section( __( 'Sessions by country', 'ecomm-user-tracker' ), 'pro', 'bars', 3, function () { return self::bars( self::rep()->by( 'country', 15 ), 'country' ); } );
		self::grid_close();
	}

	private static function page_behavior() {
		self::grid_open( 3 );
		self::section(
			__( 'Session duration, pages per session, bounce rate', 'ecomm-user-tracker' ),
			'pro',
			'kpis',
			2,
			function () {
				$t  = self::rep()->totals();
				$pt = self::$prev->totals();
				return self::kpis(
					array(
						array( __( 'Avg. session duration', 'ecomm-user-tracker' ), self::duration( $t['duration'] ), self::change( $t['duration'], $pt['duration'] ) ),
						array( __( 'Avg. pages per session', 'ecomm-user-tracker' ), number_format_i18n( $t['per_sess'], 1 ), self::change( $t['per_sess'], $pt['per_sess'] ) ),
						array( __( 'Bounce rate', 'ecomm-user-tracker' ), $t['bounce'] . '%', self::change( $t['bounce'], $pt['bounce'], true ) ),
					)
				);
			}
		);
		if ( ECT_License::has( 'pro' ) ) {
			self::soon( __( 'Top clicks', 'ecomm-user-tracker' ) );
		} else {
			self::locked( __( 'Top clicks', 'ecomm-user-tracker' ), 'pro', 'bars' );
		}
		self::section( __( 'Top pages', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::bars( self::rep()->top_pages( 10 ) ); } );
		self::section( __( 'Entry pages', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::bars( self::rep()->by( 'entry_page', 10 ) ); } );
		self::section(
			__( 'Exit pages', 'ecomm-user-tracker' ),
			'pro',
			'bars',
			1,
			function () {
				return self::bars(
					self::rep()->exit_pages( 10 ),
					'text',
					function ( $r ) {
						/* translators: 1: exits, 2: exit rate */
						return sprintf( __( '%1$s · %2$s%% exit', 'ecomm-user-tracker' ), number_format_i18n( $r['c'] ), $r['rate'] );
					}
				);
			}
		);
		self::locked( __( 'Top navigation flows', 'ecomm-user-tracker' ), 'proplus', 'funnel', 3 );
		self::locked( __( 'Form submissions', 'ecomm-user-tracker' ), 'proplus', 'cards', 3 );
		self::grid_close();
		self::recordings_banner();
	}

	private static function page_marketing() {
		self::grid_open( 1 );
		self::locked( __( 'Performance by channel', 'ecomm-user-tracker' ), 'proplus', 'chart' );
		self::locked( __( 'Organic search', 'ecomm-user-tracker' ), 'proplus', 'bars' );
		self::locked( __( 'AI platforms', 'ecomm-user-tracker' ), 'proplus', 'bars' );
		self::locked( __( 'Email marketing', 'ecomm-user-tracker' ), 'proplus', 'cards' );
		self::grid_close();
	}

	private static function page_recordings() {
		self::grid_open( 1 );
		self::locked( __( 'Session recordings (Microsoft Clarity)', 'ecomm-user-tracker' ), 'proplus', 'cards' );
		self::grid_close();
	}

	private static function page_insights() {
		self::grid_open( 2 );
		self::locked( __( 'Insights', 'ecomm-user-tracker' ), 'agency', 'cards' );
		self::locked( __( 'Benchmarks', 'ecomm-user-tracker' ), 'agency', 'donut' );
		self::grid_close();
		echo '<div class="ect-card ect-hire"><p>' . esc_html__( 'Need help driving more traffic to your site?', 'ecomm-user-tracker' ) . '</p>';
		echo '<a class="button" target="_blank" href="https://everon.digital/?utm_source=ecomm-tracker&utm_medium=plugin&utm_campaign=hire-pro">' . esc_html__( 'Hire a Professional', 'ecomm-user-tracker' ) . '</a></div>';
	}

	private static function page_reports() {
		$cats = array(
			array( __( 'Sales', 'ecomm-user-tracker' ), 'pro' ),
			array( __( 'Accounting', 'ecomm-user-tracker' ), 'proplus' ),
			array( __( 'Traffic', 'ecomm-user-tracker' ), 'pro' ),
			array( __( 'Stores', 'ecomm-user-tracker' ), 'pro' ),
			array( __( 'Behavior', 'ecomm-user-tracker' ), 'pro' ),
			array( __( 'Marketing', 'ecomm-user-tracker' ), 'proplus' ),
			array( __( 'SEO', 'ecomm-user-tracker' ), 'proplus' ),
			array( __( 'People', 'ecomm-user-tracker' ), 'pro' ),
		);
		self::grid_open( 2 );
		foreach ( $cats as $c ) {
			self::locked( $c[0], $c[1], 'bars' );
		}
		self::grid_close();
	}

	private static function recordings_banner() {
		echo '<div class="ect-banner"><span>🎥 ' . esc_html__( 'Start recording site sessions to improve your visitor experience.', 'ecomm-user-tracker' ) . '</span>';
		echo '<a class="button" target="_blank" href="' . esc_url( ECT_UPGRADE_URL . '&utm_content=session-recordings' ) . '">' . esc_html__( 'Start Session Recordings', 'ecomm-user-tracker' ) . '</a></div>';
	}

	/* ------------------------------------------------------------------ */
	/* Settings                                                            */
	/* ------------------------------------------------------------------ */

	public static function register_settings() {
		register_setting(
			'ect_settings',
			'ect_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
			)
		);
	}

	public static function sanitize( $in ) {
		$out = array();
		foreach ( array( 'tracking', 'exclude_admins', 'respect_dnt', 'delete_data', 'auto_update' ) as $k ) {
			$out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
		}
		// Customer names are shown only after the admin confirms their privacy policy covers it.
		$out['hide_names'] = 1;
		if ( empty( $in['hide_names'] ) ) {
			if ( ! empty( $in['privacy_ok'] ) || ! ect_get_option( 'hide_names' ) ) {
				$out['hide_names'] = 0;
				if ( ect_get_option( 'hide_names' ) ) {
					$out['privacy_ok_by'] = get_current_user_id();
					$out['privacy_ok_at'] = time();
				}
			} else {
				add_settings_error( 'ect_settings', 'ect_privacy', __( 'To show customer names, please confirm that you added the text to your Privacy Policy.', 'ecomm-user-tracker' ) );
			}
		}
		$old = (array) get_option( 'ect_settings', array() );
		foreach ( array( 'privacy_ok_by', 'privacy_ok_at' ) as $k ) {
			if ( ! isset( $out[ $k ] ) && isset( $old[ $k ] ) ) {
				$out[ $k ] = $old[ $k ];
			}
		}
		return $out;
	}

	private static function page_settings() {
		if ( isset( $_GET['ect_geo'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$ok = 'ok' === $_GET['ect_geo']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-' . ( $ok ? 'success' : 'error' ) . '"><p>' . esc_html( $ok ? __( 'Country database updated.', 'ecomm-user-tracker' ) : __( 'Country database download failed. Your host may block outgoing downloads.', 'ecomm-user-tracker' ) ) . '</p></div>';
		}
		$fields = array(
			'tracking'       => __( 'Enable visitor tracking', 'ecomm-user-tracker' ),
			'exclude_admins' => __( 'Do not track logged-in admins, editors and shop managers', 'ecomm-user-tracker' ),
			'respect_dnt'    => __( 'Respect browser "Do Not Track"', 'ecomm-user-tracker' ),
			'auto_update'    => __( 'Automatically install plugin updates', 'ecomm-user-tracker' ),
			'delete_data'    => __( 'Delete all plugin data when the plugin is deleted', 'ecomm-user-tracker' ),
		);
		echo '<div class="ect-card ect-settings"><form method="post" action="options.php">';
		settings_fields( 'ect_settings' );
		foreach ( $fields as $k => $label ) {
			echo '<p><label><input type="checkbox" name="ect_settings[' . esc_attr( $k ) . ']" value="1" ' . checked( (int) ect_get_option( $k ), 1, false ) . '> ' . esc_html( $label ) . '</label></p>';
		}
		if ( ECT_License::has( 'pro' ) ) {
			$hide = (int) ect_get_option( 'hide_names' );
			echo '<p><label><input type="checkbox" id="ect-hide-names" name="ect_settings[hide_names]" value="1" ' . checked( $hide, 1, false ) . '> ' . esc_html__( 'Hide customer names in reports', 'ecomm-user-tracker' ) . '</label></p>';
			echo '<div id="ect-privacy" class="ect-privacy"' . ( $hide ? ' hidden' : '' ) . '><p>' . esc_html__( 'To show customer names, add this to your Privacy Policy:', 'ecomm-user-tracker' ) . '</p>';
			echo '<textarea readonly rows="3" onclick="this.select()">' . esc_textarea( __( 'We use Ecomm User Tracker to understand how visitors use our store. When you place an order or log in, your name may be linked to the pages you visited on our site. This data stays on our website and is deleted automatically after the retention period.', 'ecomm-user-tracker' ) ) . '</textarea>';
			echo '<p><label><input type="checkbox" name="ect_settings[privacy_ok]" value="1" ' . checked( ! $hide, true, false ) . '> ' . esc_html__( 'I have added this text to my Privacy Policy.', 'ecomm-user-tracker' ) . '</label></p></div>';
			echo "<script>document.getElementById('ect-hide-names').addEventListener('change',function(){document.getElementById('ect-privacy').hidden=this.checked;});</script>";
		}
		submit_button();
		echo '</form></div>';

		self::license_card();

		echo '<div class="ect-card ect-settings"><h3>' . esc_html__( 'Country database', 'ecomm-user-tracker' ) . '</h3>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ect_geo_update' );
		echo '<input type="hidden" name="action" value="ect_geo_update">';
		submit_button( __( 'Update now', 'ecomm-user-tracker' ), 'secondary', 'submit', false );
		echo '</form></div>';
		echo '<p class="ect-footer">' . esc_html__( 'IP geolocation by DB-IP', 'ecomm-user-tracker' ) . '</p>';
	}

	private static function license_card() {
		if ( isset( $_GET['ect_lic'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$msg = get_transient( 'ect_license_msg' );
			delete_transient( 'ect_license_msg' );
			if ( $msg ) {
				echo '<div class="notice notice-' . esc_attr( $msg[0] ) . '"><p>' . esc_html( $msg[1] ) . '</p></div>';
			}
		}
		echo '<div class="ect-card ect-settings"><h3>' . esc_html__( 'License', 'ecomm-user-tracker' ) . '</h3>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ect_license' );
		echo '<input type="hidden" name="action" value="ect_license">';
		$key = ECT_License::key();
		if ( $key ) {
			/* translators: %s: plan name */
			echo '<p>' . esc_html( sprintf( __( 'Active plan: %s', 'ecomm-user-tracker' ), ECT_License::label() ) ) . ' · <code>' . esc_html( substr( $key, 0, 4 ) . '••••' . substr( $key, -4 ) ) . '</code></p>';
			echo '<input type="hidden" name="do" value="deactivate">';
			submit_button( __( 'Deactivate license', 'ecomm-user-tracker' ), 'secondary', 'submit', false );
		} else {
			echo '<p><input type="text" name="key" class="regular-text" placeholder="XXXX-XXXX-XXXX-XXXX" autocomplete="off"> ';
			echo '<input type="hidden" name="do" value="activate">';
			submit_button( __( 'Activate', 'ecomm-user-tracker' ), 'primary', 'submit', false );
			echo '</p><p class="ect-muted"><a href="' . esc_url( ECT_UPGRADE_URL ) . '" target="_blank">' . esc_html__( 'Get a license key', 'ecomm-user-tracker' ) . '</a></p>';
		}
		echo '</form></div>';
	}

	public static function handle_license() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_license' );
		$do = isset( $_POST['do'] ) ? sanitize_key( $_POST['do'] ) : '';
		if ( 'deactivate' === $do ) {
			ECT_License::deactivate();
			$msg = array( 'success', __( 'License deactivated.', 'ecomm-user-tracker' ) );
		} else {
			$res = ECT_License::activate( isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '' );
			/* translators: %s: plan name */
			$msg = is_wp_error( $res ) ? array( 'error', $res->get_error_message() ) : array( 'success', sprintf( __( 'License activated: %s plan.', 'ecomm-user-tracker' ), ECT_License::label() ) );
		}
		set_transient( 'ect_license_msg', $msg, 60 );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '-settings&ect_lic=1' ) );
		exit;
	}

	public static function handle_geo_update() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_geo_update' );
		$res = ECT_Geo::update_db();
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '-settings&ect_geo=' . ( true === $res ? 'ok' : 'fail' ) ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Dashboard widget                                                    */
	/* ------------------------------------------------------------------ */

	public static function dashboard_widget() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		wp_add_dashboard_widget(
			'ect_live_widget',
			__( 'Ecomm User Tracker — Live', 'ecomm-user-tracker' ),
			function () {
				self::live_card( true );
				echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-realtime' ) ) . '">' . esc_html__( 'View Real-time Analytics', 'ecomm-user-tracker' ) . ' →</a></p>';
			}
		);
	}

	/* ------------------------------------------------------------------ */
	/* Deactivation feedback (optional)                                    */
	/* ------------------------------------------------------------------ */

	private static function feedback_reasons() {
		return array(
			'not_working'   => __( "It didn't work on my site", 'ecomm-user-tracker' ),
			'missing'       => __( "It's missing a feature I need", 'ecomm-user-tracker' ),
			'better'        => __( 'I found a better plugin', 'ecomm-user-tracker' ),
			'slow'          => __( 'It slowed down my site', 'ecomm-user-tracker' ),
			'temporary'     => __( "It's a temporary deactivation", 'ecomm-user-tracker' ),
			'other'         => __( 'Other', 'ecomm-user-tracker' ),
		);
	}

	public static function deactivate_modal() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		?>
		<div id="ect-deactivate" class="ect-modal" hidden>
			<div class="ect-modal-box" role="dialog" aria-modal="true" aria-labelledby="ect-deactivate-title">
				<h2 id="ect-deactivate-title"><?php esc_html_e( 'Quick feedback', 'ecomm-user-tracker' ); ?></h2>
				<p><?php esc_html_e( 'If you have a moment, please tell us why you are deactivating Ecomm User Tracker (optional):', 'ecomm-user-tracker' ); ?></p>
				<?php foreach ( self::feedback_reasons() as $key => $label ) : ?>
					<p><label><input type="radio" name="ect_reason" value="<?php echo esc_attr( $key ); ?>"> <?php echo esc_html( $label ); ?></label></p>
				<?php endforeach; ?>
				<textarea id="ect-reason-details" rows="3" placeholder="<?php esc_attr_e( 'Anything else? (optional)', 'ecomm-user-tracker' ); ?>"></textarea>
				<div class="ect-modal-actions">
					<button type="button" class="button-link" data-ect-skip><?php esc_html_e( 'Skip & Deactivate', 'ecomm-user-tracker' ); ?></button>
					<button type="button" class="button button-primary" data-ect-submit><?php esc_html_e( 'Submit & Deactivate', 'ecomm-user-tracker' ); ?></button>
				</div>
			</div>
		</div>
		<style>
			.ect-modal{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:100000;display:flex;align-items:center;justify-content:center}
			.ect-modal[hidden]{display:none}
			.ect-modal-box{background:#fff;border-radius:10px;padding:20px 24px;max-width:480px;width:calc(100% - 32px);box-shadow:0 10px 40px rgba(0,0,0,.25)}
			.ect-modal-box h2{margin-top:0}
			.ect-modal-box p{margin:6px 0}
			.ect-modal-box textarea{width:100%;margin-top:8px}
			.ect-modal-actions{display:flex;justify-content:space-between;align-items:center;margin-top:16px}
		</style>
		<script>
		(function () {
			var link = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( ECT_FILE ) ); ?>"] .deactivate a');
			var modal = document.getElementById('ect-deactivate');
			if (!link || !modal) return;
			var href = link.href;
			link.addEventListener('click', function (e) { e.preventDefault(); modal.hidden = false; });
			modal.addEventListener('click', function (e) { if (e.target === modal) modal.hidden = true; });
			document.addEventListener('keydown', function (e) { if (e.key === 'Escape') modal.hidden = true; });
			modal.querySelector('[data-ect-skip]').addEventListener('click', function () { location.href = href; });
			modal.querySelector('[data-ect-submit]').addEventListener('click', function () {
				var r = modal.querySelector('input[name="ect_reason"]:checked');
				var d = document.getElementById('ect-reason-details').value;
				if (!r && !d) { location.href = href; return; }
				var body = new URLSearchParams({
					action: 'ect_deactivate_feedback',
					_wpnonce: '<?php echo esc_js( wp_create_nonce( 'ect_feedback' ) ); ?>',
					reason: r ? r.value : '',
					details: d
				});
				this.disabled = true;
				fetch(ajaxurl, { method: 'POST', body: body, credentials: 'same-origin' })
					.finally(function () { location.href = href; });
				setTimeout(function () { location.href = href; }, 3000);
			});
		})();
		</script>
		<?php
	}

	public static function deactivate_feedback() {
		check_ajax_referer( 'ect_feedback' );
		if ( ! current_user_can( 'activate_plugins' ) ) {
			wp_send_json_error( null, 403 );
		}
		$reasons = self::feedback_reasons();
		$reason  = isset( $_POST['reason'] ) ? sanitize_key( wp_unslash( $_POST['reason'] ) ) : '';
		$details = isset( $_POST['details'] ) ? sanitize_textarea_field( wp_unslash( $_POST['details'] ) ) : '';
		if ( ECT_FEEDBACK_URL && ( isset( $reasons[ $reason ] ) || '' !== $details ) ) {
			wp_remote_post(
				ECT_FEEDBACK_URL,
				array(
					'timeout'  => 5,
					'blocking' => false,
					'headers'  => array( 'Content-Type' => 'application/json' ),
					'body'     => wp_json_encode(
						array(
							'plugin'      => 'ecomm-user-tracker',
							'version'     => ECT_VERSION,
							'reason'      => $reason,
							'details'     => substr( $details, 0, 1000 ),
							'wp_version'  => get_bloginfo( 'version' ),
							'php_version' => PHP_VERSION,
							'locale'      => get_locale(),
						)
					),
				)
			);
		}
		wp_send_json_success();
	}
}
