<?php
/**
 * Report queries for the admin pages (Pro and up).
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

class ECT_Reports {

	/** @var int */
	public $from;
	/** @var int */
	public $to;
	/** @var int */
	public $days;

	public function __construct( $days ) {
		$this->days = max( 1, (int) $days );
		$this->to   = time();
		$this->from = 1 === $this->days ? ( new DateTime( 'today', wp_timezone() ) )->getTimestamp() : $this->to - $this->days * DAY_IN_SECONDS;
	}

	private function range_sql( $col = 'started' ) {
		global $wpdb;
		return $wpdb->prepare( "{$col} BETWEEN %d AND %d", $this->from, $this->to );
	}

	/** Same-length period right before this one, for "% change". */
	public function previous() {
		$p       = new self( $this->days );
		$len     = $this->to - $this->from;
		$p->to   = $this->from - 1;
		$p->from = $this->from - $len;
		return $p;
	}

	public function totals() {
		global $wpdb;
		$t   = ECT_DB::sessions();
		$row = $wpdb->get_row(
			"SELECT COUNT(*) AS sessions, COUNT(DISTINCT visitor) AS visitors, COALESCE(SUM(pageviews),0) AS pageviews,
				COALESCE(AVG(last_seen - started),0) AS duration,
				COALESCE(SUM(CASE WHEN pageviews <= 1 AND last_seen - started < 10 THEN 1 ELSE 0 END),0) AS bounces
			FROM {$t} WHERE " . $this->range_sql(),
			ARRAY_A
		);
		$row             = array_map( 'floatval', (array) $row );
		$row['bounce']   = $row['sessions'] ? round( 100 * $row['bounces'] / $row['sessions'], 1 ) : 0;
		$row['per_sess'] = $row['sessions'] ? round( $row['pageviews'] / $row['sessions'], 1 ) : 0;
		return $row;
	}

	/** Sessions per day (or per hour for "Today"). */
	public function series() {
		global $wpdb;
		$t      = ECT_DB::sessions();
		$offset = (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
		$bucket = 1 === $this->days ? HOUR_IN_SECONDS : DAY_IN_SECONDS;
		$rows   = $wpdb->get_results(
			$wpdb->prepare( "SELECT FLOOR((started + %d) / %d) AS b, COUNT(*) AS c FROM {$t} WHERE " . $this->range_sql() . ' GROUP BY b', $offset, $bucket ),
			ARRAY_A
		);
		$map = array();
		foreach ( (array) $rows as $r ) {
			$map[ (int) $r['b'] ] = (int) $r['c'];
		}
		$out   = array();
		$start = (int) floor( ( $this->from + $offset ) / $bucket );
		$end   = (int) floor( ( $this->to + $offset ) / $bucket );
		for ( $b = $start; $b <= $end; $b++ ) {
			$ts    = $b * $bucket - $offset;
			$out[] = array(
				'label' => 1 === $this->days ? wp_date( 'H:00', $ts ) : wp_date( 'M j', $ts ),
				'value' => isset( $map[ $b ] ) ? $map[ $b ] : 0,
			);
		}
		return $out;
	}

	public function by( $column, $limit = 10 ) {
		global $wpdb;
		$allowed = array( 'country', 'device', 'entry_page', 'exit_page' );
		if ( ! in_array( $column, $allowed, true ) ) {
			return array();
		}
		$t = ECT_DB::sessions();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT {$column} AS k, COUNT(*) AS c FROM {$t} WHERE " . $this->range_sql() . " GROUP BY {$column} ORDER BY c DESC LIMIT %d", $limit ),
			ARRAY_A
		);
	}

	public function sources( $limit = 10 ) {
		global $wpdb;
		$t    = ECT_DB::sessions();
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT channel, source, COUNT(*) AS c FROM {$t} WHERE " . $this->range_sql() . ' GROUP BY channel, source ORDER BY c DESC LIMIT %d', $limit ),
			ARRAY_A
		);
		foreach ( $rows as &$r ) {
			$r['k'] = ECT_Source::label( $r['channel'], $r['source'] );
		}
		return $rows;
	}

	public function top_pages( $limit = 10 ) {
		global $wpdb;
		$p = ECT_DB::pageviews();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT path AS k, COUNT(*) AS c FROM {$p} WHERE " . $this->range_sql( 'ts' ) . ' GROUP BY path ORDER BY c DESC LIMIT %d', $limit ),
			ARRAY_A
		);
	}

	/** Exit rate per page = sessions that ended on the page / page views of the page. */
	public function exit_pages( $limit = 10 ) {
		global $wpdb;
		$s     = ECT_DB::sessions();
		$p     = ECT_DB::pageviews();
		$exits = $this->by( 'exit_page', $limit );
		foreach ( $exits as &$r ) {
			$views     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p} WHERE path = %s AND " . $this->range_sql( 'ts' ), $r['k'] ) );
			$r['rate'] = $views ? min( 100, round( 100 * $r['c'] / $views ) ) : 0;
		}
		unset( $s );
		return $exits;
	}

	/** Average sessions per weekday (0 = Sunday). */
	public function weekdays() {
		global $wpdb;
		$t      = ECT_DB::sessions();
		$offset = (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
		$rows   = (array) $wpdb->get_results( "SELECT started FROM {$t} WHERE " . $this->range_sql() );
		$counts = array_fill( 0, 7, 0 );
		foreach ( $rows as $r ) {
			$counts[ (int) gmdate( 'w', $r->started + $offset ) ]++;
		}
		$weeks = max( 1, $this->days / 7 );
		return array_map(
			function ( $c ) use ( $weeks ) {
				return round( $c / $weeks, 1 );
			},
			$counts
		);
	}

	/* ---------------- Real-time ---------------- */

	public static function recent_sessions( $limit = 10 ) {
		global $wpdb;
		$t = ECT_DB::sessions();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT id, started, last_seen, pageviews, exit_page, channel, source, device, country FROM {$t} WHERE last_seen >= %d ORDER BY last_seen DESC LIMIT %d", time() - 30 * MINUTE_IN_SECONDS, $limit ),
			ARRAY_A
		);
	}

	public static function recent_pageviews( $limit = 15 ) {
		global $wpdb;
		$s = ECT_DB::sessions();
		$p = ECT_DB::pageviews();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT p.path, p.ts, s.id AS sid, s.country, s.device FROM {$p} p JOIN {$s} s ON s.id = p.session_id WHERE p.ts >= %d ORDER BY p.ts DESC LIMIT %d", time() - DAY_IN_SECONDS, $limit ),
			ARRAY_A
		);
	}

	public static function last30() {
		global $wpdb;
		$t = ECT_DB::sessions();
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE last_seen >= %d", time() - 30 * MINUTE_IN_SECONDS ) );
	}

	public static function live_breakdown( $column ) {
		global $wpdb;
		if ( ! in_array( $column, array( 'device', 'exit_page' ), true ) ) {
			return array();
		}
		$t = ECT_DB::sessions();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT {$column} AS k, COUNT(*) AS c FROM {$t} WHERE last_seen >= %d GROUP BY {$column} ORDER BY c DESC LIMIT 8", time() - ECT_LIVE_WINDOW ),
			ARRAY_A
		);
	}

	public static function live_sources() {
		global $wpdb;
		$t    = ECT_DB::sessions();
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT channel, source, COUNT(*) AS c FROM {$t} WHERE last_seen >= %d GROUP BY channel, source ORDER BY c DESC LIMIT 8", time() - ECT_LIVE_WINDOW ),
			ARRAY_A
		);
		foreach ( $rows as &$r ) {
			$r['k'] = ECT_Source::label( $r['channel'], $r['source'] );
		}
		return $rows;
	}

	/* ---------------- WooCommerce ---------------- */

	public function sales() {
		$out = array(
			'orders'   => 0,
			'revenue'  => 0.0,
			'aov'      => 0.0,
			'items'    => array(),
			'sources'  => array(),
			'customers' => array(),
		);
		if ( ! ECT_Woo::active() ) {
			return $out;
		}
		global $wpdb;
		$t      = ECT_DB::sessions();
		$skeys  = array();
		$orders = ECT_Woo::orders( $this->from, $this->to );
		foreach ( $orders as $order ) {
			$total = (float) $order->get_total() - (float) $order->get_total_refunded();
			$out['orders']++;
			$out['revenue'] += $total;
			foreach ( $order->get_items() as $item ) {
				$name = $item->get_name();
				if ( ! isset( $out['items'][ $name ] ) ) {
					$out['items'][ $name ] = array(
						'k'   => $name,
						'c'   => 0,
						'rev' => 0,
					);
				}
				$out['items'][ $name ]['c']   += (int) $item->get_quantity();
				$out['items'][ $name ]['rev'] += (float) $item->get_total();
			}
			if ( ect_get_option( 'hide_names' ) ) {
				$email = strtolower( (string) $order->get_billing_email() );
				/* translators: %s: short anonymous customer id */
				$who = sprintf( __( 'Customer #%s', 'ecomm-user-tracker' ), $email ? strtoupper( substr( md5( $email . wp_salt( 'auth' ) ), 0, 5 ) ) : '—' );
			} else {
				$who = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
				$who = $who ? $who : __( 'Guest', 'ecomm-user-tracker' );
			}
			if ( ! isset( $out['customers'][ $who ] ) ) {
				$out['customers'][ $who ] = array(
					'k'   => $who,
					'c'   => 0,
					'rev' => 0,
				);
			}
			$out['customers'][ $who ]['c']++;
			$out['customers'][ $who ]['rev'] += $total;

			$skey  = $order->get_meta( ECT_Woo::META );
			$label = __( 'Unknown', 'ecomm-user-tracker' );
			if ( $skey ) {
				if ( ! isset( $skeys[ $skey ] ) ) {
					$row            = $wpdb->get_row( $wpdb->prepare( "SELECT channel, source FROM {$t} WHERE skey = %s", $skey ), ARRAY_A );
					$skeys[ $skey ] = $row ? ECT_Source::label( $row['channel'], $row['source'] ) : $label;
				}
				$label = $skeys[ $skey ];
			}
			if ( ! isset( $out['sources'][ $label ] ) ) {
				$out['sources'][ $label ] = array(
					'k'   => $label,
					'c'   => 0,
					'rev' => 0,
				);
			}
			$out['sources'][ $label ]['c']++;
			$out['sources'][ $label ]['rev'] += $total;
		}
		$out['aov'] = $out['orders'] ? $out['revenue'] / $out['orders'] : 0;
		foreach ( array( 'items', 'sources', 'customers' ) as $k ) {
			$list = array_values( $out[ $k ] );
			usort(
				$list,
				function ( $a, $b ) {
					return $b['rev'] <=> $a['rev'];
				}
			);
			$out[ $k ] = array_slice( $list, 0, 8 );
		}
		return $out;
	}
}
