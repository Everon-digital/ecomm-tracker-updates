<?php
/**
 * Front-end tracker script + REST endpoint that receives heartbeats.
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Tracker {

	const BOT_PATTERN = '/bot\b|bot\/|crawl|spider|slurp|facebookexternalhit|headlesschrome|lighthouse|pingdom|python-requests|curl\/|wget|httpclient/i';

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_filter( 'script_loader_tag', array( __CLASS__, 'no_optimize' ), 20, 2 );
		add_filter( 'rocket_delay_js_exclusions', array( __CLASS__, 'rocket_exclude' ) );
		add_filter( 'rocket_exclude_defer_js', array( __CLASS__, 'rocket_exclude' ) );
		add_filter( 'rocket_exclude_js', array( __CLASS__, 'rocket_exclude' ) );
		add_filter( 'litespeed_optm_js_defer_exc', array( __CLASS__, 'rocket_exclude' ) );
		add_filter( 'litespeed_optimize_js_excludes', array( __CLASS__, 'rocket_exclude' ) );
		add_filter( 'autoptimize_filter_js_exclude', array( __CLASS__, 'autoptimize_exclude' ) );
	}

	public static function should_track() {
		if ( ! ect_get_option( 'tracking' ) ) {
			return false;
		}
		if ( ect_get_option( 'exclude_admins' ) && is_user_logged_in() && current_user_can( 'edit_posts' ) ) {
			return false;
		}
		return true;
	}

	public static function enqueue() {
		if ( ! self::should_track() || is_preview() || is_customize_preview() ) {
			return;
		}
		wp_enqueue_script( 'ect-tracker', ECT_URL . 'assets/js/ect-live.js', array(), ECT_VERSION, true );
		wp_add_inline_script(
			'ect-tracker',
			'window.ectCfg=' . wp_json_encode(
				array(
					'endpoint' => esc_url_raw( rest_url( 'ect/v1/hit' ) ),
					'interval' => 30,
					'dnt'      => (bool) ect_get_option( 'respect_dnt' ),
					'pro'      => ECT_License::has( 'pro' ),
				)
			) . ';',
			'before'
		);
	}

	/**
	 * Keep cache/optimization plugins (LiteSpeed, WP Rocket, Autoptimize, SG Optimizer…)
	 * from delaying the tracker until user interaction — otherwise live visitors show up late.
	 */
	public static function no_optimize( $tag, $handle ) {
		if ( 'ect-tracker' !== $handle && 'ect-tracker-js-before' !== $handle ) {
			return $tag;
		}
		return str_replace( '<script ', '<script data-no-optimize="1" data-no-defer="1" data-no-minify="1" data-cfasync="false" nowprocket ', $tag );
	}

	public static function rocket_exclude( $list ) {
		$list[] = 'ecomm-user-tracker/assets/js/ect-live.js';
		$list[] = 'ectCfg';
		return $list;
	}

	public static function autoptimize_exclude( $exclude ) {
		return $exclude . ', ecomm-user-tracker/assets/js/ect-live.js, ectCfg';
	}

	public static function routes() {
		register_rest_route(
			'ect/v1',
			'/hit',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'hit' ),
				'permission_callback' => '__return_true', // Public: cached pages cannot carry nonces. Input is strictly validated.
			)
		);
		register_rest_route(
			'ect/v1',
			'/live',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'live' ),
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
			)
		);
	}

	public static function hit( WP_REST_Request $req ) {
		$resp = new WP_REST_Response( null, 204 );
		$resp->header( 'Cache-Control', 'no-store' );

		if ( ! ect_get_option( 'tracking' ) ) {
			return $resp;
		}
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		if ( '' === $ua || preg_match( self::BOT_PATTERN, $ua ) ) {
			return $resp;
		}

		$params = $req->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $req->get_body_params();
		}
		$vid = isset( $params['v'] ) ? (string) $params['v'] : '';
		if ( ! preg_match( '/^[a-zA-Z0-9]{16,40}$/', $vid ) ) {
			return $resp;
		}
		$page = isset( $params['p'] ) ? (string) $params['p'] : '';
		$page = substr( sanitize_text_field( wp_parse_url( $page, PHP_URL_PATH ) ?: '/' ), 0, 255 );

		// Visitor key rotates daily with a site secret, so it can't be linked across days.
		$salt    = wp_salt( 'auth' ) . gmdate( 'Y-m-d' );
		$visitor = substr( hash( 'sha256', $vid . $salt ), 0, 32 );

		$country = null;
		$geo     = function () use ( &$country ) {
			if ( null === $country ) {
				$country = ECT_Geo::country();
			}
			return $country;
		};
		ECT_DB::touch( $visitor, $page, $geo );

		// Pro: full visit history (pages, entry/exit, source, device).
		$sid = isset( $params['s'] ) ? (string) $params['s'] : '';
		if ( ECT_License::has( 'pro' ) && preg_match( '/^[a-zA-Z0-9]{16,40}$/', $sid ) ) {
			$e        = ( isset( $params['e'] ) && 'pv' === $params['e'] ) ? 'pv' : 'hb';
			$stable   = substr( hash( 'sha256', $vid . wp_salt( 'auth' ) ), 0, 32 );
			$skey     = self::session_key( $sid );
			$referrer = isset( $params['r'] ) ? esc_url_raw( substr( (string) $params['r'], 0, 500 ) ) : '';
			$q        = array();
			if ( isset( $params['q'] ) && is_array( $params['q'] ) ) {
				foreach ( array( 'utm_source', 'utm_medium', 'utm_campaign', 'gclid', 'gbraid', 'wbraid', 'msclkid', 'fbclid', 'ttclid' ) as $k ) {
					if ( isset( $params['q'][ $k ] ) && is_scalar( $params['q'][ $k ] ) ) {
						$q[ $k ] = substr( sanitize_text_field( (string) $params['q'][ $k ] ), 0, 100 );
					}
				}
			}
			ECT_DB::track_session(
				$skey,
				$stable,
				$e,
				$page,
				function () use ( $referrer, $q, $ua, $geo ) {
					list( $channel, $source ) = ECT_Source::classify( $referrer, $q );
					return array(
						'channel' => $channel,
						'source'  => $source,
						'device'  => ECT_Source::device( $ua ),
						'country' => call_user_func( $geo ),
					);
				}
			);
		}
		return $resp;
	}

	/** Session cookie / id → stored key. Also used to link WooCommerce orders to visits. */
	public static function session_key( $sid ) {
		return substr( hash( 'sha256', 'ect-session|' . $sid . wp_salt( 'auth' ) ), 0, 32 );
	}

	public static function live() {
		$resp = new WP_REST_Response( ECT_DB::live_stats() );
		$resp->header( 'Cache-Control', 'no-store' );
		return $resp;
	}
}
