<?php
/**
 * Database table, cron jobs and queries.
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_DB {

	const DB_VERSION = '2';

	public static function sessions() {
		global $wpdb;
		return $wpdb->prefix . 'ect_sessions';
	}

	public static function pageviews() {
		global $wpdb;
		return $wpdb->prefix . 'ect_pageviews';
	}

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'ect_visitors';
	}

	public static function activate() {
		self::create_table();
		if ( ! wp_next_scheduled( 'ect_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'ect_cleanup' );
		}
		if ( ! wp_next_scheduled( 'ect_geo_update' ) ) {
			wp_schedule_event( time() + 60, 'daily', 'ect_geo_update' );
		}
		// First geo download happens shortly after activation so activation itself stays fast.
		wp_schedule_single_event( time() + 5, 'ect_geo_update' );
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'ect_cleanup' );
		wp_clear_scheduled_hook( 'ect_geo_update' );
		wp_clear_scheduled_hook( 'ect_license_check' );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'ect_db_version' ) !== self::DB_VERSION ) {
			self::activate();
		}
	}

	private static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		// One row per visitor (hashed, rotates daily). No IP, no personal data.
		dbDelta(
			"CREATE TABLE {$table} (
				visitor CHAR(32) NOT NULL,
				country CHAR(2) NOT NULL DEFAULT '',
				page VARCHAR(255) NOT NULL DEFAULT '',
				first_seen INT UNSIGNED NOT NULL,
				last_seen INT UNSIGNED NOT NULL,
				hits INT UNSIGNED NOT NULL DEFAULT 1,
				PRIMARY KEY  (visitor),
				KEY last_seen (last_seen)
			) {$charset};"
		);
		$sessions  = self::sessions();
		$pageviews = self::pageviews();
		// Pro: one row per visit (session). Visitor = pseudonymous hash, no IP / personal data.
		dbDelta(
			"CREATE TABLE {$sessions} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				skey CHAR(32) NOT NULL,
				visitor CHAR(32) NOT NULL,
				started INT UNSIGNED NOT NULL,
				last_seen INT UNSIGNED NOT NULL,
				pageviews SMALLINT UNSIGNED NOT NULL DEFAULT 0,
				entry_page VARCHAR(255) NOT NULL DEFAULT '',
				exit_page VARCHAR(255) NOT NULL DEFAULT '',
				channel VARCHAR(20) NOT NULL DEFAULT 'direct',
				source VARCHAR(100) NOT NULL DEFAULT '',
				device VARCHAR(10) NOT NULL DEFAULT '',
				country CHAR(2) NOT NULL DEFAULT '',
				PRIMARY KEY  (id),
				UNIQUE KEY skey (skey),
				KEY started (started),
				KEY visitor (visitor)
			) {$charset};"
		);
		dbDelta(
			"CREATE TABLE {$pageviews} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				session_id BIGINT UNSIGNED NOT NULL,
				path VARCHAR(255) NOT NULL DEFAULT '',
				ts INT UNSIGNED NOT NULL,
				PRIMARY KEY  (id),
				KEY ts (ts),
				KEY session_id (session_id)
			) {$charset};"
		);
		update_option( 'ect_db_version', self::DB_VERSION );
	}

	public static function cleanup() {
		global $wpdb;
		$table = self::table();
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE last_seen < %d", time() - ECT_RETENTION ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// Visit history: kept according to the plan (Free 1 day, Pro 30 days, Pro+/Agency 1 year).
		$cutoff    = time() - ECT_License::retention_days() * DAY_IN_SECONDS;
		$sessions  = self::sessions();
		$pageviews = self::pageviews();
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$pageviews} WHERE ts < %d", $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$sessions} WHERE last_seen < %d", $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * @return bool True if a new visitor row was created.
	 */
	public static function touch( $visitor, $page, $country_cb ) {
		global $wpdb;
		$table = self::table();
		$now   = time();

		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET last_seen = %d, page = %s, hits = hits + 1 WHERE visitor = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$now,
				$page,
				$visitor
			)
		);
		if ( $updated ) {
			return false;
		}
		$wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$table} (visitor, country, page, first_seen, last_seen) VALUES (%s, %s, %s, %d, %d)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$visitor,
				call_user_func( $country_cb ),
				$page,
				$now,
				$now
			)
		);
		return true;
	}

	public static function live_stats() {
		global $wpdb;
		$table = self::table();
		$since = time() - ECT_LIVE_WINDOW;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT country, COUNT(*) AS c FROM {$table} WHERE last_seen >= %d GROUP BY country ORDER BY c DESC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$since
			),
			ARRAY_A
		);
		$total     = 0;
		$countries = array();
		foreach ( (array) $rows as $r ) {
			$total      += (int) $r['c'];
			$countries[] = array(
				'code'  => $r['country'] ? $r['country'] : 'XX',
				'count' => (int) $r['c'],
			);
		}
		return array(
			'live'      => $total,
			'countries' => $countries,
			'time'      => time(),
		);
	}

	/**
	 * Record a visit (Pro and up). $e = 'pv' (page view) or 'hb' (heartbeat).
	 */
	public static function track_session( $skey, $visitor, $e, $page, $meta_cb ) {
		global $wpdb;
		$sessions = self::sessions();
		$now      = time();

		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM {$sessions} WHERE skey = %s", $skey ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $row ) {
			if ( 'pv' !== $e ) {
				return; // A session only starts with a page view.
			}
			$meta = call_user_func( $meta_cb );
			$wpdb->query(
				$wpdb->prepare(
					"INSERT IGNORE INTO {$sessions} (skey, visitor, started, last_seen, pageviews, entry_page, exit_page, channel, source, device, country) VALUES (%s, %s, %d, %d, 0, %s, %s, %s, %s, %s, %s)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$skey,
					$visitor,
					$now,
					$now,
					$page,
					$page,
					$meta['channel'],
					$meta['source'],
					$meta['device'],
					$meta['country']
				)
			);
			$id = (int) $wpdb->insert_id;
			if ( ! $id ) {
				$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$sessions} WHERE skey = %s", $skey ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			}
		} else {
			$id = (int) $row->id;
		}
		if ( ! $id ) {
			return;
		}

		if ( 'pv' === $e ) {
			$wpdb->query( $wpdb->prepare( "UPDATE {$sessions} SET last_seen = %d, pageviews = pageviews + 1, exit_page = %s WHERE id = %d", $now, $page, $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->insert(
				self::pageviews(),
				array(
					'session_id' => $id,
					'path'       => $page,
					'ts'         => $now,
				),
				array( '%d', '%s', '%d' )
			);
		} else {
			$wpdb->query( $wpdb->prepare( "UPDATE {$sessions} SET last_seen = %d WHERE id = %d", $now, $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
	}
}
