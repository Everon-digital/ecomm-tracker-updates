<?php
/**
 * WooCommerce: link each new order to the visit it came from (for "sales by source").
 * Orders themselves are read from WooCommerce (HPOS compatible), not copied.
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Woo {

	const META = '_ect_session';

	public static function active() {
		return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_orders' );
	}

	public static function init() {
		add_action( 'woocommerce_new_order', array( __CLASS__, 'attach' ), 10, 2 );
	}

	public static function attach( $order_id, $order = null ) {
		if ( ! ECT_License::has( 'pro' ) || is_admin() && ! wp_doing_ajax() ) {
			return;
		}
		$sid = isset( $_COOKIE['ect_sid'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['ect_sid'] ) ) : '';
		if ( ! preg_match( '/^[a-zA-Z0-9]{16,40}$/', $sid ) ) {
			return;
		}
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order_id );
		if ( $order ) {
			$order->update_meta_data( self::META, ECT_Tracker::session_key( $sid ) );
			$order->save_meta_data();
		}
	}

	public static function paid_statuses() {
		return apply_filters( 'ect_paid_order_statuses', array( 'wc-processing', 'wc-completed', 'wc-on-hold' ) );
	}

	/** @return WC_Order[] */
	public static function orders( $from, $to ) {
		if ( ! self::active() ) {
			return array();
		}
		return wc_get_orders(
			array(
				'status'       => self::paid_statuses(),
				'date_created' => $from . '...' . $to,
				'limit'        => 5000,
				'type'         => 'shop_order',
			)
		);
	}
}
