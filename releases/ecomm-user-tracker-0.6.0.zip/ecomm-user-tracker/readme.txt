=== Ecomm User Tracker ===
Contributors: everondigital
Tags: analytics, live visitors, woocommerce, real-time, statistics
Requires at least: 7.1
Tested up to: 7.2
Requires PHP: 8.3
Stable tag: 0.6.0
License: GPLv2 or later

Live visitors, traffic sources, sales and store analytics for WordPress & WooCommerce. Lightweight and privacy-friendly.

== Description ==

* Live visitors count (last 5 minutes)
* Live visitors by country (with flags)
* Dashboard widget
* Pro / Pro+ / Agency unlock traffic sources (incl. AI tools), pages, orders, funnels, reports and more

IP geolocation by DB-IP (https://db-ip.com), CC BY 4.0.

== Changelog ==

= 0.6.0 =
* Abandoned cart recovery by email (Pro+ / Agency): up to 3 reminders with a one-click link back to the cart, optional coupon, unsubscribe link.
* Email payment links for pending and draft orders.
* Cart recovery report and Highlights card.

= 0.5.3 =
* Session recorder loads after the page has finished loading (no effect on page speed).
* Store emails show your store name as the source.
* Emails to admins and staff are no longer tagged.

= 0.5.2 =
* New button style across the plugin.

= 0.5.1 =
* New session recording player: visitor details, page list with jump-to-page, browser-style address bar.
* More reliable automatic updates and a "Check for updates" link on the Plugins screen.
* Requires WordPress 7.1+ and PHP 8.3+.

= 0.5.0 =
* Built-in session recordings (Pro+ / Agency): watch visits right in WordPress, saved on your own hosting. Form fields are always hidden.
* Pro+ keeps recordings 48 hours; Agency chooses 2, 7, 15 or 30 days and can turn auto-delete off.
* 1 GB monthly recording limit with usage bar; warning when space may fill up.
* Real-time: "Visitors in the last 30 minutes" now sits next to the live map.

= 0.4.0 =
* Custom date range with comparison to the previous period.
* Key stats: Add Stats (choose your numbers) and Create Alert.
* Email reports (daily / weekly / monthly) — Pro. Alerts for sales, traffic drops and abandoned carts — Pro+.
* Agency: white-label branding for email reports and printable (PDF) reports.
* World map for live visitors and sessions by location.
* Visitor full history popup.
* New reports: sales & AOV over time, coupons, refunds, customers over time, new vs returning customers, low / out of stock, slow-moving products, product analytics, out-of-stock products viewed, site searches (+ no results), clicks to contact, 404 errors, blog posts, posts that lead to sales, subscriptions.
* llms.txt generator (Pro+).
* Faster reports on big sites (smart caching).

= 0.3.9 =
* Data cards scroll inside the card (mouse wheel / touch) with no visible scrollbar, and show more rows.

= 0.3.8 =
* Button click tracking is now a Pro+ / Agency feature.

= 0.3.7 =
* Navigation flows redesigned: step summary (how many continue / leave) and the most common journeys with page names.
* Forms are recognised by type (contact, checkout, create account, login, newsletter) — works with custom forms; choose which types to track in Settings. Product option, cart, search and coupon forms are ignored.
* Checkout submissions are counted when the order is placed.

= 0.3.6 =
* Sales count every paid order, including custom statuses registered by other plugins.
* Sales by source also uses WooCommerce Order Attribution, so orders placed before tracking get a source.
* Settings: "Order check" shows how the latest orders are counted.

= 0.3.5 =
* "Open report" / "View more" buttons at the top and bottom of data cards.
* Recent visitors "View more" popup.
* Live activity shows which button each visitor clicked; new "Button Clicks by Page" and "Avg. Time on Page" reports.

= 0.3.4 =
* Live activity shows the latest 8 items with a "View more" popup (scrollable, keeps updating live).

= 0.3.3 =
* Real-time page updates every second without refreshing (recent visitors, live activity, pages/sources/devices, visitor snapshot).
* Live activity shows add to cart, checkout, purchases and form submissions; recent visitors show their shopping stage.

= 0.3.2 =
* Sales now include orders with custom statuses (e.g. Shipped, Delivered).

= 0.3.1 =
* Complimentary plan support for Everon Digital sites.

= 0.3.0 =
* Pro: new vs returning visitors, avg. time on page. Pro+: button click tracking.
* Pro+: conversion funnel, visitor snapshot, abandoned carts, device/browser/OS report with conversion.
* Pro+: navigation flows, form submissions (any form on the site).
* Pro+: Marketing — performance by channel, AI platforms, AI bots, AI visibility score, email click & sales tracking.
* Pro+: session recordings via Microsoft Clarity, accounting reports, All Reports with CSV export, 90-day and 12-month ranges.
* Agency: insights and benchmarks.

= 0.2.0 =
* Pro: page visits, entry & exit pages, sessions over time, avg. session duration, bounce rate.
* Pro: traffic sources — Google / Facebook organic vs ads, AI tools (ChatGPT, Claude, Gemini, Perplexity…), direct, email, referral.
* Pro: device type, sessions by country, real-time recent visitors and live activity.
* Pro: WooCommerce sales, orders, top products, sales by source, top customers.
* License key activation (Settings).

= 0.1.4 =
* Cleaner settings page.
* "Delete all plugin data" on by default.
* Optional feedback when deactivating.

= 0.1.3 =
* Tracker file renamed so common ad-block filter lists no longer block it (visitors were missing).
* More precise bot detection (fewer real visitors filtered out).

= 0.1.2 =
* Dashboard → Updates → "Check again" now fetches the latest plugin version immediately.

= 0.1.1 =
* Live visitors appear right away on sites using LiteSpeed Cache, WP Rocket, Autoptimize and similar (tracker excluded from JS delay/defer).
* Admin live view refreshes every 10 seconds.

= 0.1.0 =
* First release: live visitors + countries, admin menu, dashboard widget, self-hosted auto-updates.
