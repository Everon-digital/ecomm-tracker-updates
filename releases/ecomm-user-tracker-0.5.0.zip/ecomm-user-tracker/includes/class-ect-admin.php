<?php
/**
 * Admin menu, pages, dashboard widget and settings.
 *
 * Free plan: Live visitors + countries are real data. Everything else is shown
 * blurred with dummy data and an Upgrade button (no real data is sent to the browser).
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Admin {

	const SLUG = 'ecomm-user-tracker';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'dashboard_widget' ) );
		add_action( 'admin_post_ect_geo_update', array( __CLASS__, 'handle_geo_update' ) );
		add_action( 'admin_post_ect_license', array( __CLASS__, 'handle_license' ) );
		add_action( 'admin_post_ect_csv', array( __CLASS__, 'export_csv' ) );
		add_action( 'admin_post_ect_stats', array( __CLASS__, 'handle_stats' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( ECT_FILE ), array( __CLASS__, 'action_links' ) );
		add_action( 'admin_footer-plugins.php', array( __CLASS__, 'deactivate_modal' ) );
		add_action( 'wp_ajax_ect_deactivate_feedback', array( __CLASS__, 'deactivate_feedback' ) );
	}

	public static function pages() {
		return array(
			self::SLUG                    => __( 'Highlights', 'ecomm-user-tracker' ),
			self::SLUG . '-realtime'      => __( 'Real-time', 'ecomm-user-tracker' ),
			self::SLUG . '-traffic'       => __( 'Traffic', 'ecomm-user-tracker' ),
			self::SLUG . '-behavior'      => __( 'Behavior', 'ecomm-user-tracker' ),
			self::SLUG . '-marketing'     => __( 'Marketing', 'ecomm-user-tracker' ),
			self::SLUG . '-recordings'    => __( 'Session Recordings', 'ecomm-user-tracker' ),
			self::SLUG . '-insights'      => __( 'Insights & Benchmarks', 'ecomm-user-tracker' ),
			self::SLUG . '-reports'       => __( 'All Reports', 'ecomm-user-tracker' ),
			self::SLUG . '-settings'      => __( 'Settings', 'ecomm-user-tracker' ),
		);
	}

	public static function menu() {
		add_menu_page(
			__( 'Ecomm User Tracker', 'ecomm-user-tracker' ),
			__( 'Ecomm User Tracker', 'ecomm-user-tracker' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-chart-area',
			3
		);
		foreach ( self::pages() as $slug => $title ) {
			add_submenu_page( self::SLUG, $title, $title, 'manage_options', $slug, array( __CLASS__, 'render' ) );
		}
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">' . esc_html__( 'Dashboard', 'ecomm-user-tracker' ) . '</a>' );
		$links[] = '<a href="' . esc_url( ECT_UPGRADE_URL ) . '" target="_blank" style="font-weight:600">' . esc_html__( 'Upgrade', 'ecomm-user-tracker' ) . '</a>';
		return $links;
	}

	public static function assets( $hook ) {
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 'index.php' !== $hook && ! isset( self::pages()[ $page ] ) ) {
			return;
		}
		wp_enqueue_style( 'ect-admin', ECT_URL . 'assets/css/admin.css', array(), ECT_VERSION );
		wp_enqueue_script( 'ect-world', ECT_URL . 'assets/js/ect-world.js', array(), ECT_VERSION, true );
		wp_enqueue_script( 'ect-admin', ECT_URL . 'assets/js/admin.js', array( 'ect-world' ), ECT_VERSION, true );
		if ( self::SLUG . '-recordings' === $page && ECT_License::has( 'proplus' ) ) {
			wp_enqueue_style( 'ect-rrweb-player', ECT_URL . 'assets/vendor/rrweb/rrweb-player.css', array(), ECT_VERSION );
			wp_enqueue_script( 'ect-rrweb-player', ECT_URL . 'assets/vendor/rrweb/rrweb-player.min.js', array(), ECT_VERSION, true );
		}
		wp_localize_script(
			'ect-admin',
			'ectAdmin',
			array(
				'recording' => ECT_License::has( 'proplus' ) ? wp_nonce_url( admin_url( 'admin-post.php?action=ect_rec_get' ), 'ect_rec_get' ) : '',
				'endpoint' => esc_url_raw( rest_url( 'ect/v1/live' ) ),
				'visitor'  => ECT_License::has( 'pro' ) ? esc_url_raw( rest_url( 'ect/v1/visitor' ) ) : '',
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'locale'   => str_replace( '_', '-', get_user_locale() ),
				'i18n'     => array(
					'unknown'  => __( 'Unknown', 'ecomm-user-tracker' ),
					'empty'    => __( 'No visitors at the moment', 'ecomm-user-tracker' ),
					'updated'  => __( 'Updated', 'ecomm-user-tracker' ),
					'visitor'  => __( 'Visitor', 'ecomm-user-tracker' ),
					'norec'    => __( 'This recording is empty or still being saved. Try again in a minute.', 'ecomm-user-tracker' ),
				),
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* Page rendering                                                      */
	/* ------------------------------------------------------------------ */

	public static function render() {
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : self::SLUG; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$titles = self::pages();
		echo '<div class="wrap ect-wrap">';
		echo '<div class="ect-header"><div><h1>' . esc_html( isset( $titles[ $page ] ) ? $titles[ $page ] : '' ) . '</h1>';
		echo '<p class="ect-sub">' . esc_html( self::subtitle( $page ) ) . '</p></div>';
		echo '<span class="ect-plan">';
		/* translators: %s: plan name */
		echo esc_html( sprintf( __( '%s plan', 'ecomm-user-tracker' ), ECT_License::label() ) );
		if ( ! ECT_License::has( 'agency' ) ) {
			echo ' · <a href="' . esc_url( ECT_UPGRADE_URL ) . '" target="_blank">' . esc_html__( 'Upgrade', 'ecomm-user-tracker' ) . '</a>';
		}
		echo '</span></div>';
		if ( in_array( $page, array( self::SLUG, self::SLUG . '-traffic', self::SLUG . '-behavior' ), true ) && ECT_License::has( 'pro' ) ) {
			echo '<p class="ect-subscribe"><a class="button" href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-settings#ect-alerts' ) ) . '">✉ ' . esc_html__( 'Subscribe', 'ecomm-user-tracker' ) . '</a></p>';
			self::range_picker( $page );
		}

		switch ( $page ) {
			case self::SLUG:
				self::page_highlights();
				break;
			case self::SLUG . '-realtime':
				self::page_realtime();
				break;
			case self::SLUG . '-traffic':
				self::page_traffic();
				break;
			case self::SLUG . '-behavior':
				self::page_behavior();
				break;
			case self::SLUG . '-marketing':
				self::page_marketing();
				break;
			case self::SLUG . '-recordings':
				self::page_recordings();
				break;
			case self::SLUG . '-insights':
				self::page_insights();
				break;
			case self::SLUG . '-reports':
				self::page_reports();
				break;
			case self::SLUG . '-settings':
				self::page_settings();
				break;
		}
		echo '</div>';
	}

	private static function subtitle( $page ) {
		$map = array(
			self::SLUG                 => __( "Get a complete overview of your site's activity across all areas.", 'ecomm-user-tracker' ),
			self::SLUG . '-realtime'   => __( 'See how visitors interact with your site in real time.', 'ecomm-user-tracker' ),
			self::SLUG . '-traffic'    => __( "Track your site's traffic trends and get to know your visitors.", 'ecomm-user-tracker' ),
			self::SLUG . '-behavior'   => __( 'Learn how people navigate your site.', 'ecomm-user-tracker' ),
			self::SLUG . '-marketing'  => __( 'See which channels bring visitors, leads and sales.', 'ecomm-user-tracker' ),
			self::SLUG . '-recordings' => __( 'Watch how visitors use your site.', 'ecomm-user-tracker' ),
			self::SLUG . '-insights'   => __( 'Automatic insights and how you compare to similar stores.', 'ecomm-user-tracker' ),
			self::SLUG . '-reports'    => __( 'All reports in one place.', 'ecomm-user-tracker' ),
			self::SLUG . '-settings'   => __( 'Tracking and privacy settings.', 'ecomm-user-tracker' ),
		);
		return isset( $map[ $page ] ) ? $map[ $page ] : '';
	}

	/** Live visitors card — real data (Free). */
	private static function live_card( $with_countries = true, $map = false ) {
		?>
		<div class="ect-card ect-live" data-ect-live>
			<div class="ect-live-head">
				<span class="ect-dot"></span>
				<span class="ect-live-count" data-ect-count>0</span>
				<span class="ect-live-label"><?php esc_html_e( 'live visitors', 'ecomm-user-tracker' ); ?></span>
			</div>
			<?php if ( $map ) : ?>
				<div class="ect-map" data-ect-map="live"></div>
			<?php endif; ?>
			<?php if ( $with_countries ) : ?>
				<h3><?php esc_html_e( 'Live visitors by country', 'ecomm-user-tracker' ); ?></h3>
				<div class="ect-scroll"><ul class="ect-countries" data-ect-countries></ul></div>
				<p class="ect-empty" data-ect-empty><?php esc_html_e( "No visitors at the moment. Once you have real-time visitors, you'll see where they come from here.", 'ecomm-user-tracker' ); ?></p>
			<?php endif; ?>
			<p class="ect-muted" data-ect-updated></p>
		</div>
		<?php
	}

	/** Blurred locked section with dummy content + Upgrade. */
	private static function locked( $title, $plan, $kind = 'bars', $cols = 1 ) {
		$plan_label = array(
			'pro'     => 'Pro',
			'proplus' => 'Pro+',
			'agency'  => 'Agency',
		)[ $plan ];
		echo '<div class="ect-card ect-locked ect-span-' . (int) $cols . '">';
		echo '<h3>' . esc_html( $title ) . '</h3>';
		echo '<div class="ect-blur" aria-hidden="true">' . self::dummy( $kind ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="ect-lock-overlay"><span class="ect-badge">' . esc_html( $plan_label ) . '</span>';
		echo '<a class="button button-primary" href="' . esc_url( ECT_UPGRADE_URL . '&utm_content=' . rawurlencode( sanitize_title( $title ) ) ) . '" target="_blank">';
		/* translators: %s: plan name */
		echo esc_html( sprintf( __( 'Upgrade to %s', 'ecomm-user-tracker' ), $plan_label ) ) . '</a></div>';
		echo '</div>';
	}

	/** Static fake content — never real data. */
	private static function dummy( $kind ) {
		switch ( $kind ) {
			case 'kpis':
				$h = '<div class="ect-kpis">';
				foreach ( array( array( 'Site sessions', '1,284', '+12%' ), array( 'Total sales', '$4,920', '+8%' ), array( 'Total orders', '96', '+5%' ), array( 'Unique visitors', '842', '+9%' ) ) as $k ) {
					$h .= '<div class="ect-kpi"><span>' . $k[0] . '</span><strong>' . $k[1] . '</strong><em>' . $k[2] . '</em></div>';
				}
				return $h . '</div>';
			case 'chart':
				$h = '<svg viewBox="0 0 300 90" class="ect-fake-chart"><polyline fill="none" stroke="currentColor" stroke-width="3" points="0,70 30,55 60,62 90,40 120,48 150,25 180,35 210,20 240,30 270,12 300,22"/></svg>';
				return $h;
			case 'donut':
				return '<svg viewBox="0 0 42 42" class="ect-fake-donut"><circle cx="21" cy="21" r="15.9" fill="none" stroke="#c7d7fe" stroke-width="6"/><circle cx="21" cy="21" r="15.9" fill="none" stroke="currentColor" stroke-width="6" stroke-dasharray="70 30" stroke-dashoffset="25"/></svg>';
			case 'funnel':
				$h = '<div class="ect-fake-funnel">';
				foreach ( array( 100, 62, 30, 18, 9 ) as $v ) {
					$h .= '<span style="height:' . $v . '%"></span>';
				}
				return $h . '</div>';
			case 'cards':
				return '<div class="ect-fake-row"></div><div class="ect-fake-row"></div><div class="ect-fake-row short"></div>';
			default:
				$h = '<ul class="ect-fake-bars">';
				foreach ( array( array( '/homepage', 90 ), array( '/shop', 64 ), array( '/product/shoes', 41 ), array( '/cart', 22 ) ) as $b ) {
					$h .= '<li><span>' . $b[0] . '</span><i style="width:' . $b[1] . '%"></i></li>';
				}
				return $h . '</ul>';
		}
	}

	private static function grid_open( $cols = 3 ) {
		echo '<div class="ect-grid ect-cols-' . (int) $cols . '">';
	}

	private static function grid_close() {
		echo '</div>';
	}

	/* ------------------------------------------------------------------ */
	/* Helpers for real (Pro) data                                         */
	/* ------------------------------------------------------------------ */

	private static function range_days() {
		$custom = self::range_custom();
		if ( $custom ) {
			return max( 1, (int) ceil( ( $custom[1] - $custom[0] ) / DAY_IN_SECONDS ) );
		}
		$allowed = ECT_License::has( 'proplus' ) ? array( 1, 7, 30, 90, 365 ) : array( 1, 7, 30 );
		$d       = isset( $_GET['range'] ) ? (int) $_GET['range'] : 30; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return in_array( $d, $allowed, true ) ? $d : 30;
	}

	/** Custom dates from the date picker: [ from, to ] timestamps, clamped to the plan's data history. */
	private static function range_custom() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$f = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '';
		$t = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '';
		// phpcs:enable
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $f ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $t ) ) {
			return null;
		}
		try {
			$from = ( new DateTime( $f . ' 00:00:00', wp_timezone() ) )->getTimestamp();
			$to   = ( new DateTime( $t . ' 23:59:59', wp_timezone() ) )->getTimestamp();
		} catch ( Exception $e ) {
			return null;
		}
		$oldest = time() - ECT_License::retention_days() * DAY_IN_SECONDS;
		$from   = max( $from, $oldest );
		$to     = min( $to, time() );
		return $from < $to ? array( $from, $to ) : null;
	}

	/** Query args that keep the chosen period when moving between pages and reports. */
	private static function range_args() {
		$c = self::range_custom();
		if ( $c ) {
			return array(
				'from' => wp_date( 'Y-m-d', $c[0] ),
				'to'   => wp_date( 'Y-m-d', $c[1] ),
			);
		}
		return array( 'range' => self::range_days() );
	}

	private static function range_picker( $page ) {
		$labels = array(
			1   => __( 'Today', 'ecomm-user-tracker' ),
			7   => __( 'Last 7 days', 'ecomm-user-tracker' ),
			30  => __( 'Last 30 days', 'ecomm-user-tracker' ),
			90  => __( 'Last 90 days', 'ecomm-user-tracker' ),
			365 => __( 'Last 12 months', 'ecomm-user-tracker' ),
		);
		$custom = self::range_custom();
		$cur    = $custom ? 0 : self::range_days();
		parse_str( (string) wp_parse_url( 'x?page=' . $page, PHP_URL_QUERY ), $base );
		echo '<div class="ect-range">';
		foreach ( $labels as $d => $label ) {
			if ( $d > 30 && ! ECT_License::has( 'proplus' ) ) {
				continue;
			}
			$url = add_query_arg( array_merge( $base, array( 'range' => $d ) ), admin_url( 'admin.php' ) );
			echo '<a class="' . ( $d === $cur ? 'is-active' : '' ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
		}
		$min = wp_date( 'Y-m-d', time() - ECT_License::retention_days() * DAY_IN_SECONDS );
		$max = wp_date( 'Y-m-d' );
		echo '<form method="get" action="' . esc_url( admin_url( 'admin.php' ) ) . '" class="ect-range-custom' . ( $custom ? ' is-active' : '' ) . '">';
		foreach ( $base as $k => $v ) {
			echo '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '">';
		}
		echo '<input type="date" name="from" min="' . esc_attr( $min ) . '" max="' . esc_attr( $max ) . '" value="' . esc_attr( $custom ? wp_date( 'Y-m-d', $custom[0] ) : '' ) . '" required> – ';
		echo '<input type="date" name="to" min="' . esc_attr( $min ) . '" max="' . esc_attr( $max ) . '" value="' . esc_attr( $custom ? wp_date( 'Y-m-d', $custom[1] ) : '' ) . '" required> ';
		echo '<button class="button">' . esc_html__( 'Apply', 'ecomm-user-tracker' ) . '</button></form>';
		$prev = self::rep()->previous();
		/* translators: 1: start date, 2: end date */
		echo '<span class="ect-muted">' . esc_html( sprintf( __( 'compared to previous period (%1$s – %2$s)', 'ecomm-user-tracker' ), wp_date( 'M j', $prev->from ), wp_date( 'M j, Y', $prev->to ) ) ) . '</span></div>';
	}

	private static $rep = null;
	private static $prev = null;

	private static function rep() {
		if ( null === self::$rep ) {
			$custom     = self::range_custom();
			self::$rep  = $custom ? ECT_Reports::between( $custom[0], $custom[1] ) : new ECT_Reports( self::range_days() );
			self::$prev = self::$rep->previous();
		}
		return self::$rep;
	}

	private static function card( $title, $html, $cols = 1 ) {
		echo '<div class="ect-card ect-span-' . (int) $cols . '"><h3>' . esc_html( $title ) . '</h3><div class="ect-scroll">' . $html . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/** Card title → full report in All Reports ("Open report" buttons). */
	private static function report_for( $title ) {
		static $map = null;
		if ( null === $map ) {
			$t   = 'ecomm-user-tracker';
			$map = array(
				__( 'Top traffic sources', $t )                => 'tr-sources',
				__( 'Sessions by source and category', $t )    => 'tr-sources',
				__( 'Sessions by location', $t )               => 'tr-countries',
				__( 'Sessions by country', $t )                => 'tr-countries',
				__( 'Most visited pages', $t )                 => 'bh-pages',
				__( 'Top pages', $t )                          => 'bh-pages',
				__( 'Entry pages', $t )                        => 'tr-entry',
				__( 'Exit pages', $t )                         => 'bh-exit',
				__( 'Top button clicks', $t )                  => 'bh-clicks-page',
				__( 'Top clicks', $t )                         => 'bh-clicks-page',
				__( 'Top selling items', $t )                  => 'sales-items',
				__( 'Top store products', $t )                 => 'sales-items',
				__( 'Sales by source', $t )                    => 'sales-source',
				__( 'Top paying customers', $t )               => 'sales-customers',
				__( 'Conversion funnel', $t )                  => 'st-funnel',
				__( 'Abandoned carts', $t )                    => 'st-abandoned',
				__( 'New vs returning visitors', $t )          => 'tr-newret',
				__( 'Sessions by device', $t )                 => 'tr-device',
				__( 'Device report', $t )                      => 'sales-device',
				__( 'Browsers', $t )                           => 'tr-browsers',
				__( 'Operating systems', $t )                  => 'tr-os',
				__( 'Form submissions', $t )                   => 'bh-forms',
				__( 'Top site searches', $t )                  => 'bh-search',
				__( 'Searches with no results', $t )           => 'bh-noresult',
				__( 'Clicks to contact', $t )                  => 'bh-contact',
				__( '404 errors', $t )                         => 'bh-404',
				__( 'Top blog posts', $t )                     => 'blog-top',
				__( 'Sales over time', $t )                    => 'sales-time',
				__( 'Product analytics', $t )                  => 'st-products',
				__( 'Low stock', $t )                          => 'inv-low',
				__( 'Performance by channel', $t )             => 'mk-channels',
				__( 'Paid ads', $t )                           => 'mk-channels',
				__( 'AI platforms', $t )                       => 'mk-ai',
				__( 'Email marketing', $t )                    => 'mk-email',
				__( 'AI bots reading your site', $t )          => 'seo-bots',
				__( 'Avg. time on page', $t )                  => 'bh-time',
			);
		}
		return isset( $map[ $title ] ) ? $map[ $title ] : '';
	}

	private static function card_link( $report, $label = '' ) {
		$url = add_query_arg( array_merge( array( 'page' => self::SLUG . '-reports', 'report' => $report ), self::range_args() ), admin_url( 'admin.php' ) );
		return '<a class="ect-card-link" href="' . esc_url( $url ) . '">' . esc_html( $label ? $label : __( 'Open report', 'ecomm-user-tracker' ) ) . ' →</a>';
	}

	/**
	 * Cache heavy report output for big sites. Only ranges longer than one day are cached:
	 * 5 minutes when the range includes today, 12 hours for past ranges.
	 */
	private static function cached( $key, $cb ) {
		$r = self::rep();
		if ( $r->to - $r->from <= DAY_IN_SECONDS + 60 || isset( $_GET['ect_nocache'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return call_user_func( $cb );
		}
		$tkey = 'ect_c_' . md5( $key . '|' . $r->from . '|' . $r->to . '|' . ECT_License::plan() . '|' . get_user_locale() . '|' . ECT_VERSION );
		$hit  = get_transient( $tkey );
		if ( false !== $hit ) {
			return $hit;
		}
		$val = call_user_func( $cb );
		set_transient( $tkey, $val, $r->to >= time() - HOUR_IN_SECONDS ? 5 * MINUTE_IN_SECONDS : 12 * HOUR_IN_SECONDS );
		return $val;
	}

	/** Show real content if the plan allows, otherwise the blurred upsell. */
	private static function section( $title, $plan, $kind, $cols, $render, $live = null ) {
		if ( ECT_License::has( $plan ) ) {
			$render = function () use ( $title, $render, $live ) {
				return self::cached( 'sec|' . $title, $render ) . ( $live ? call_user_func( $live ) : '' );
			};
			$report = self::report_for( $title );
			$def    = $report ? self::find_report( $report ) : null;
			if ( $def && ECT_License::has( $def[1] ) ) {
				$link = self::card_link( $report );
				echo '<div class="ect-card ect-span-' . (int) $cols . '"><div class="ect-card-head"><h3>' . esc_html( $title ) . '</h3>' . $link . '</div><div class="ect-scroll">' . call_user_func( $render ) . '</div><p class="ect-card-foot">' . $link . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				return;
			}
			self::card( $title, call_user_func( $render ), $cols );
		} else {
			self::locked( $title, $plan, $kind, $cols );
		}
	}

	private static function soon( $title, $cols = 1 ) {
		self::card( $title, '<p class="ect-empty">' . esc_html__( 'Coming soon in the next update.', 'ecomm-user-tracker' ) . '</p>', $cols );
	}

	private static function change( $now, $before, $lower_is_better = false ) {
		if ( ! $before ) {
			return '';
		}
		$pct = round( 100 * ( $now - $before ) / $before );
		if ( 0 == $pct ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual
			return '<em class="ect-chg">0%</em>';
		}
		$good = $lower_is_better ? $pct < 0 : $pct > 0;
		return '<em class="ect-chg ' . ( $good ? 'up' : 'down' ) . '">' . ( $pct > 0 ? '↑' : '↓' ) . abs( $pct ) . '%</em>';
	}

	private static function kpis( $items ) {
		$h = '<div class="ect-kpis">';
		foreach ( $items as $k ) {
			$h .= '<div class="ect-kpi"><span>' . esc_html( $k[0] ) . '</span><strong>' . esc_html( $k[1] ) . '</strong>' . ( isset( $k[2] ) ? $k[2] : '' ) . '</div>';
		}
		return $h . '</div>';
	}

	private static function money( $v ) {
		if ( function_exists( 'wc_price' ) ) {
			return html_entity_decode( wp_strip_all_tags( wc_price( $v ) ), ENT_QUOTES, 'UTF-8' );
		}
		return number_format_i18n( $v, 2 );
	}

	private static function duration( $sec ) {
		$sec = (int) round( $sec );
		return $sec >= 60 ? sprintf( '%dm %02ds', floor( $sec / 60 ), $sec % 60 ) : $sec . 's';
	}

	/**
	 * Horizontal bar list. $rows: [ [ 'k' => label, 'c' => count, ... ] ].
	 * $type: 'text' | 'country' | 'page'. $value_cb formats the right-hand value.
	 */
	private static function bars( $rows, $type = 'text', $value_cb = null, $empty = '' ) {
		if ( empty( $rows ) ) {
			return '<p class="ect-empty">' . esc_html( $empty ? $empty : __( 'No data for this period yet.', 'ecomm-user-tracker' ) ) . '</p>';
		}
		$max = 1;
		foreach ( $rows as $r ) {
			$max = max( $max, (float) $r['c'] );
		}
		$h = '<ul class="ect-countries">';
		foreach ( $rows as $r ) {
			$k = (string) $r['k'];
			if ( 'country' === $type ) {
				$label = '<span class="ect-c-name" data-ect-cc="' . esc_attr( $k ? $k : 'XX' ) . '">' . esc_html( $k ? $k : '—' ) . '</span>';
			} elseif ( 'device' === $type ) {
				$names = array(
					'mobile'  => __( 'Mobile', 'ecomm-user-tracker' ),
					'desktop' => __( 'Desktop', 'ecomm-user-tracker' ),
					'tablet'  => __( 'Tablet', 'ecomm-user-tracker' ),
				);
				$label = '<span class="ect-c-name">' . esc_html( isset( $names[ $k ] ) ? $names[ $k ] : $k ) . '</span>';
			} else {
				$label = '<span class="ect-c-name">' . esc_html( '' === $k ? '—' : $k ) . '</span>';
			}
			$val = $value_cb ? call_user_func( $value_cb, $r ) : number_format_i18n( $r['c'] );
			$h  .= '<li>' . $label . '<strong>' . esc_html( $val ) . '</strong><i style="width:' . max( 3, (int) round( 100 * $r['c'] / $max ) ) . '%"></i></li>';
		}
		return $h . '</ul>';
	}

	/** World map, coloured by count per country (drawn by admin.js). */
	private static function map( $rows ) {
		$m = array();
		foreach ( $rows as $r ) {
			if ( $r['k'] ) {
				$m[ $r['k'] ] = (int) $r['c'];
			}
		}
		return '<div class="ect-map" data-ect-map="' . esc_attr( wp_json_encode( (object) $m ) ) . '"></div>';
	}

	private static function chart( $series ) {
		$n = count( $series );
		if ( ! $n ) {
			return '';
		}
		$max = 0;
		foreach ( $series as $p ) {
			$max = max( $max, $p['value'] );
		}
		$step = max( 1, (int) ceil( $n / 8 ) );
		$fmt  = function ( $v ) {
			return number_format_i18n( $v, $v < 10 && floor( $v ) != $v ? 1 : 0 ); // phpcs:ignore Universal.Operators.StrictComparisons.LooseNotEqual
		};
		$h  = '<div class="ect-chart"><div class="ect-chart-y"><span>' . esc_html( $fmt( $max ) ) . '</span><span>' . esc_html( $fmt( $max / 2 ) ) . '</span><span>0</span></div><div class="ect-chart-body"><div class="ect-chart-bars">';
		foreach ( $series as $p ) {
			$pct = $max ? round( 100 * $p['value'] / $max, 1 ) : 0;
			$h  .= '<span title="' . esc_attr( $p['label'] . ': ' . $fmt( $p['value'] ) ) . '"><i style="height:' . ( $p['value'] ? max( 2, $pct ) : 0 ) . '%"></i></span>';
		}
		$h .= '</div><div class="ect-chart-x">';
		foreach ( $series as $i => $p ) {
			$h .= '<span>' . ( 0 === $i % $step ? esc_html( $p['label'] ) : '' ) . '</span>';
		}
		return $h . '</div></div></div>';
	}

	private static function weekday_chart( $avg ) {
		global $wp_locale;
		$series = array();
		foreach ( $avg as $i => $v ) {
			$series[] = array(
				'label' => $wp_locale ? $wp_locale->get_weekday_abbrev( $wp_locale->get_weekday( $i ) ) : (string) $i,
				'value' => $v,
			);
		}
		return self::chart( $series );
	}

	private static function sales_cache() {
		static $sales = null;
		if ( null === $sales ) {
			$sales = self::rep()->sales();
		}
		return $sales;
	}

	private static function funnel_html( $steps ) {
		$first = max( 1, $steps[0]['c'] );
		$last  = end( $steps );
		$h     = '<p class="ect-funnel-rate">' . esc_html( round( 100 * $last['c'] / $first, 1 ) . '%' ) . ' <small>' . esc_html__( 'conversion', 'ecomm-user-tracker' ) . '</small></p><div class="ect-funnel">';
		$prev  = null;
		foreach ( $steps as $st ) {
			$pct = round( 100 * $st['c'] / $first, 1 );
			$h  .= '<div><div class="ect-funnel-bar"><i style="height:' . max( $st['c'] ? 2 : 0, $pct ) . '%"></i></div><span>' . esc_html( $st['k'] ) . '</span><strong>' . esc_html( number_format_i18n( $st['c'] ) ) . '</strong>';
			if ( null !== $prev ) {
				/* translators: %s: percent */
				$h .= '<small>' . esc_html( sprintf( __( '%s%% of previous', 'ecomm-user-tracker' ), $prev ? round( 100 * $st['c'] / $prev ) : 0 ) ) . '</small>';
			}
			$h   .= '</div>';
			$prev = $st['c'];
		}
		return $h . '</div>';
	}

	/** Simple table. $cols: [ key => header ], values already formatted. */
	private static function table( $cols, $rows, $empty = '' ) {
		if ( empty( $rows ) ) {
			return '<p class="ect-empty">' . esc_html( $empty ? $empty : __( 'No data for this period yet.', 'ecomm-user-tracker' ) ) . '</p>';
		}
		$h = '<table class="ect-table"><thead><tr>';
		foreach ( $cols as $c ) {
			$h .= '<th>' . esc_html( $c ) . '</th>';
		}
		$h .= '</tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$h .= '<tr>';
			foreach ( array_keys( $cols ) as $k ) {
				$h .= '<td>' . ( isset( $r[ $k ] ) ? $r[ $k ] : '' ) . '</td>'; // Callers escape.
			}
			$h .= '</tr>';
		}
		return $h . '</tbody></table>';
	}

	private static function connect_soon( $text ) {
		return '<p>' . esc_html( $text ) . '</p><p class="ect-empty">' . esc_html__( 'Connection coming soon.', 'ecomm-user-tracker' ) . '</p>';
	}

	/** Every stat that can be shown in Key stats ("Add Stats"). */
	private static function stats_catalog() {
		return array(
			'sessions'  => array( __( 'Site sessions', 'ecomm-user-tracker' ), 'pro' ),
			'visitors'  => array( __( 'Unique visitors', 'ecomm-user-tracker' ), 'pro' ),
			'pageviews' => array( __( 'Page views', 'ecomm-user-tracker' ), 'pro' ),
			'sales'     => array( __( 'Total sales', 'ecomm-user-tracker' ), 'pro' ),
			'orders'    => array( __( 'Total orders', 'ecomm-user-tracker' ), 'pro' ),
			'aov'       => array( __( 'Average order value', 'ecomm-user-tracker' ), 'pro' ),
			'conv'      => array( __( 'Conversion rate', 'ecomm-user-tracker' ), 'pro' ),
			'bounce'    => array( __( 'Bounce rate', 'ecomm-user-tracker' ), 'pro' ),
			'duration'  => array( __( 'Avg. session duration', 'ecomm-user-tracker' ), 'pro' ),
			'ai'        => array( __( 'Visits from AI tools', 'ecomm-user-tracker' ), 'pro' ),
			'forms'     => array( __( 'Form submissions', 'ecomm-user-tracker' ), 'proplus' ),
			'abandoned' => array( __( 'Abandoned cart value', 'ecomm-user-tracker' ), 'proplus' ),
		);
	}

	private static function chosen_stats() {
		$c = ect_get_option( 'key_stats' );
		return is_array( $c ) && $c ? $c : array( 'sessions', 'visitors', 'sales', 'orders' );
	}

	/** [ value, previous value, formatter, lower_is_better ] for one stat. */
	private static function stat_value( $key, $rep ) {
		$t = $rep->totals();
		switch ( $key ) {
			case 'sessions':
				return array( $t['sessions'], 'num' );
			case 'visitors':
				return array( $t['visitors'], 'num' );
			case 'pageviews':
				return array( $t['pageviews'], 'num' );
			case 'bounce':
				return array( $t['bounce'], 'pct', true );
			case 'duration':
				return array( $t['duration'], 'dur' );
			case 'sales':
				return array( $rep->sales()['revenue'], 'money' );
			case 'orders':
				return array( $rep->sales()['orders'], 'num' );
			case 'aov':
				return array( $rep->sales()['aov'], 'money' );
			case 'conv':
				$o = $rep->sales()['orders'];
				return array( $t['sessions'] ? round( 100 * $o / $t['sessions'], 2 ) : 0, 'pct' );
			case 'ai':
				$ai = 0;
				foreach ( $rep->channels() as $c ) {
					if ( 'ai' === $c['channel'] ) {
						$ai = (int) $c['c'];
					}
				}
				return array( $ai, 'num' );
			case 'forms':
				return array( array_sum( wp_list_pluck( $rep->forms()['forms'], 'x' ) ), 'num' );
			case 'abandoned':
				return array( $rep->abandoned( 1 )['value'], 'money', true );
		}
		return array( 0, 'num' );
	}

	private static function fmt( $v, $type ) {
		switch ( $type ) {
			case 'money':
				return self::money( $v );
			case 'pct':
				return number_format_i18n( $v, 1 ) . '%';
			case 'dur':
				return self::duration( $v );
			default:
				return number_format_i18n( $v );
		}
	}

	private static function key_stats_html() {
		$cat   = self::stats_catalog();
		$items = array();
		foreach ( self::chosen_stats() as $key ) {
			if ( ! isset( $cat[ $key ] ) || ! ECT_License::has( $cat[ $key ][1] ) ) {
				continue;
			}
			if ( in_array( $key, array( 'sales', 'orders', 'aov', 'conv', 'abandoned' ), true ) && ! ECT_Woo::active() ) {
				continue;
			}
			$now     = self::stat_value( $key, self::rep() );
			$before  = self::stat_value( $key, self::$prev );
			$items[] = array( $cat[ $key ][0], self::fmt( $now[0], $now[1] ), self::change( $now[0], $before[0], ! empty( $now[2] ) ) );
		}
		return self::kpis( $items );
	}

	private static function stats_modal() {
		$chosen = self::chosen_stats();
		echo '<div id="ect-stats-modal" class="ect-modal" hidden><div class="ect-modal-box ect-modal-lg" role="dialog" aria-modal="true"><div class="ect-modal-head"><h2>' . esc_html__( 'Add Stats', 'ecomm-user-tracker' ) . '</h2><button type="button" class="ect-modal-close" data-ect-close>×</button></div>';
		echo '<form class="ect-modal-body" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ect_stats' );
		echo '<input type="hidden" name="action" value="ect_stats"><p class="ect-muted">' . esc_html__( 'Choose the numbers you want to see in Key stats.', 'ecomm-user-tracker' ) . '</p>';
		foreach ( self::stats_catalog() as $key => $def ) {
			$lock = ECT_License::has( $def[1] ) ? '' : ' disabled';
			echo '<label class="ect-block"><input type="checkbox" name="stats[]" value="' . esc_attr( $key ) . '"' . checked( in_array( $key, $chosen, true ), true, false ) . $lock . '> ' . esc_html( $def[0] ) . ( $lock ? ' <span class="ect-badge">' . esc_html( ECT_License::label( $def[1] ) ) . '</span>' : '' ) . '</label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		submit_button( __( 'Save', 'ecomm-user-tracker' ) );
		echo '</form></div></div>';
	}

	public static function handle_stats() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_stats' );
		$picked            = isset( $_POST['stats'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['stats'] ) ) : array();
		$opts              = (array) get_option( 'ect_settings', array() );
		$opts['key_stats'] = array_values( array_intersect( array_keys( self::stats_catalog() ), $picked ) );
		update_option( 'ect_settings', $opts );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG ) );
		exit;
	}

	private static function woo_note() {
		return '<p class="ect-empty">' . esc_html__( 'Install WooCommerce to see sales and orders here.', 'ecomm-user-tracker' ) . '</p>';
	}

	/* ------------------------------------------------------------------ */
	/* Pages                                                               */
	/* ------------------------------------------------------------------ */

	private static function page_highlights() {
		self::grid_open( 3 );
		self::live_card( true );
		if ( ECT_License::has( 'pro' ) ) {
			echo '<div class="ect-card ect-span-2"><div class="ect-card-head"><h3>' . esc_html__( 'Key stats', 'ecomm-user-tracker' ) . '</h3><span class="ect-head-actions">';
			if ( ECT_License::has( 'proplus' ) ) {
				echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-settings#ect-alerts' ) ) . '">🔔 ' . esc_html__( 'Create Alert', 'ecomm-user-tracker' ) . '</a> ';
			}
			echo '<button type="button" class="button" data-ect-open="ect-stats-modal">＋ ' . esc_html__( 'Add Stats', 'ecomm-user-tracker' ) . '</button></span></div>' . self::key_stats_html() . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			self::stats_modal();
		} else {
			self::locked( __( 'Key stats', 'ecomm-user-tracker' ), 'pro', 'kpis', 2 );
		}
		self::grid_close();

		echo '<h2 class="ect-section">' . esc_html__( 'Get to know your visitors', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::section( __( 'Sessions over time', 'ecomm-user-tracker' ), 'pro', 'chart', 1, function () { return self::chart( self::rep()->series() ); } );
		self::section( __( 'Top traffic sources', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::bars( self::rep()->sources( 25 ) ); } );
		self::section( __( 'Sessions by location', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::map( self::rep()->by( 'country', 300 ) ) . self::bars( self::rep()->by( 'country', 30 ), 'country' ); } );
		self::grid_close();

		echo '<h2 class="ect-section">' . esc_html__( 'Explore visitor engagement', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::section( __( 'Most visited pages', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::bars( self::rep()->top_pages( 30 ) ); } );
		self::section(
			__( 'Engagement stats', 'ecomm-user-tracker' ),
			'pro',
			'kpis',
			1,
			function () {
				$t = self::rep()->totals();
				return self::kpis(
					array(
						array( __( 'Avg. pages per session', 'ecomm-user-tracker' ), number_format_i18n( $t['per_sess'], 1 ) ),
						array( __( 'Avg. session duration', 'ecomm-user-tracker' ), self::duration( $t['duration'] ) ),
						array( __( 'Bounce rate', 'ecomm-user-tracker' ), $t['bounce'] . '%' ),
					)
				);
			}
		);
		self::section( __( 'Top button clicks', 'ecomm-user-tracker' ), 'proplus', 'bars', 1, function () { return self::bars( self::rep()->events_by( 'click', 30 ) ); } );
		self::grid_close();
		self::recordings_banner();

		echo '<h2 class="ect-section">' . esc_html__( 'Analyze marketing performance', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::section( __( 'See how people find you in Google', 'ecomm-user-tracker' ), 'proplus', 'cards', 1, function () { return self::connect_soon( __( 'Connect Google Search Console to see your search queries, clicks and positions.', 'ecomm-user-tracker' ) ); } );
		self::section(
			__( 'Email marketing', 'ecomm-user-tracker' ),
			'proplus',
			'cards',
			1,
			function () {
				$d = self::rep()->channel_detail( 'email', 'campaign' );
				return self::bars( $d['rows'], 'text', null, __( 'Links in emails sent from your site are tagged automatically. Email visits will show here.', 'ecomm-user-tracker' ) );
			}
		);
		self::section( __( 'Paid ads', 'ecomm-user-tracker' ), 'proplus', 'cards', 1, function () { return self::bars( array_values( array_filter( self::rep()->channels(), function ( $c ) { return in_array( $c['channel'], array( 'paid_search', 'paid_social' ), true ); } ) ), 'text', null, __( 'No visits from Google or Facebook ads in this period.', 'ecomm-user-tracker' ) ); } );
		self::grid_close();
		self::ai_banner();

		echo '<h2 class="ect-section">' . esc_html__( 'Track your sales', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		$money = function ( $r ) {
			return self::money( $r['rev'] );
		};
		self::section( __( 'Top selling items', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () use ( $money ) { return ECT_Woo::active() ? self::bars( self::sales_cache()['items'], 'text', $money, __( 'No products were sold on these dates.', 'ecomm-user-tracker' ) ) : self::woo_note(); } );
		self::section( __( 'Sales by source', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () use ( $money ) { return ECT_Woo::active() ? self::bars( self::sales_cache()['sources'], 'text', $money, __( 'No sales on these dates.', 'ecomm-user-tracker' ) ) : self::woo_note(); } );
		self::section( __( 'Top paying customers', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () use ( $money ) { return ECT_Woo::active() ? self::bars( self::sales_cache()['customers'], 'text', $money, __( "Here you'll see your top customers and the amount they spent.", 'ecomm-user-tracker' ) ) : self::woo_note(); } );
		self::grid_close();

		echo '<h2 class="ect-section">' . esc_html__( 'Monitor store performance', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::section(
			__( 'Top store products', 'ecomm-user-tracker' ),
			'pro',
			'bars',
			1,
			function () {
				return ECT_Woo::active() ? self::bars(
					self::sales_cache()['items'],
					'text',
					function ( $r ) {
						/* translators: %s: quantity */
						return sprintf( __( '%s sold', 'ecomm-user-tracker' ), number_format_i18n( $r['c'] ) );
					},
					__( 'No products in this period.', 'ecomm-user-tracker' )
				) : self::woo_note();
			}
		);
		self::section( __( 'Conversion funnel', 'ecomm-user-tracker' ), 'proplus', 'funnel', 2, function () { return self::funnel_html( self::rep()->funnel() ); } );
		self::grid_close();
		self::grid_open( 1 );
		self::section( __( 'Abandoned carts', 'ecomm-user-tracker' ), 'proplus', 'cards', 1, array( __CLASS__, 'abandoned_html' ) );
		self::grid_close();
		self::grid_open( 3 );
		self::section( __( 'Sales over time', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return ECT_Woo::active() ? self::bars( array_reverse( self::rep()->woo_daily() ), 'text', function ( $r ) { return self::money( $r['rev'] ) . ' · ' . number_format_i18n( $r['c'] ); }, '' ) : self::woo_note(); } );
		self::section( __( 'Product analytics', 'ecomm-user-tracker' ), 'proplus', 'bars', 1, function () { return ECT_Woo::active() ? self::bars( array_map( function ( $r ) { return array( 'k' => $r['k'], 'c' => $r['views'], 'cart' => $r['cart'], 'b' => $r['c'] ); }, array_slice( self::rep()->product_analytics(), 0, 30 ) ), 'text', function ( $r ) { /* translators: 1: views, 2: added to cart, 3: bought */ return sprintf( __( '%1$s views · %2$s cart · %3$s sold', 'ecomm-user-tracker' ), number_format_i18n( $r['c'] ), number_format_i18n( $r['cart'] ), number_format_i18n( $r['b'] ) ); }, __( 'Product views will show here.', 'ecomm-user-tracker' ) ) : self::woo_note(); } );
		self::section( __( 'Low stock', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return ECT_Woo::active() ? self::bars( array_map( function ( $r ) { return array( 'k' => $r['k'], 'c' => max( 1, (int) $r['stock'] ), 's' => $r['stock'] ); }, array_slice( self::rep()->inventory( 'low' ), 0, 30 ) ), 'text', function ( $r ) { return $r['s']; }, __( 'All products are well stocked.', 'ecomm-user-tracker' ) ) : self::woo_note(); } );
		self::grid_close();
		if ( ECT_License::has( 'pro' ) ) {
			self::visitor_modal();
		}
	}

	public static function abandoned_html() {
		$a   = self::rep()->abandoned( 8 );
		$h   = self::kpis(
			array(
				array( __( 'Abandoned carts', 'ecomm-user-tracker' ), number_format_i18n( $a['count'] ) ),
				array( __( 'Lost revenue', 'ecomm-user-tracker' ), self::money( $a['value'] ) ),
			)
		);
		$rows = array();
		foreach ( $a['list'] as $r ) {
			$rows[] = array(
				/* translators: %d: visitor number */
				'v' => '<a href="#" data-ect-visitor="' . (int) $r['id'] . '">' . esc_html( sprintf( __( 'Visitor #%d', 'ecomm-user-tracker' ), $r['id'] ) ) . '</a> <span data-ect-cc="' . esc_attr( $r['country'] ? $r['country'] : 'XX' ) . '" data-ect-flag-only></span>',
				'm' => esc_html( self::money( $r['cart_value'] ) ),
				's' => esc_html( ECT_Source::label( $r['channel'], $r['source'] ) ),
				't' => esc_html( human_time_diff( $r['last_seen'] ) ),
			);
		}
		$h .= '<div class="ect-grid ect-cols-2"><div>' . self::table(
			array(
				'v' => __( 'Visitor', 'ecomm-user-tracker' ),
				'm' => __( 'Cart value', 'ecomm-user-tracker' ),
				's' => __( 'Source', 'ecomm-user-tracker' ),
				't' => __( 'Left', 'ecomm-user-tracker' ),
			),
			$rows,
			__( 'No abandoned carts in this period.', 'ecomm-user-tracker' )
		) . '</div><div><h4>' . esc_html__( 'Most abandoned products', 'ecomm-user-tracker' ) . '</h4>' . self::bars( $a['products'], 'text', null, '—' ) . '</div></div>';
		return $h;
	}

	private static function ai_banner() {
		if ( ECT_License::has( 'proplus' ) ) {
			echo '<div class="ect-banner"><span>✨ ' . esc_html__( 'See how your site appears on AI platforms like ChatGPT, Gemini and Perplexity.', 'ecomm-user-tracker' ) . '</span><a class="button" href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-marketing#ai-visibility' ) ) . '">' . esc_html__( 'Go to AI Visibility', 'ecomm-user-tracker' ) . '</a></div>';
		} else {
			echo '<div class="ect-banner"><span>✨ ' . esc_html__( 'See how your site appears on AI platforms like ChatGPT, Gemini and Perplexity.', 'ecomm-user-tracker' ) . '</span><a class="button" target="_blank" href="' . esc_url( ECT_UPGRADE_URL . '&utm_content=ai-visibility' ) . '">' . esc_html__( 'Upgrade to Pro+', 'ecomm-user-tracker' ) . '</a></div>';
		}
	}

	/** Real-time sections; also returned by the live endpoint so the page updates every second. */
	public static function realtime_sections() {
		return array(
			'rt_recent'    => array( __( 'Recent visitors', 'ecomm-user-tracker' ), 'pro', 'cards', 1 ),
			'rt_last30'    => array( __( 'Visitors in the last 30 minutes', 'ecomm-user-tracker' ), 'pro', 'chart', 1 ),
			'rt_activity'  => array( __( 'Live activity', 'ecomm-user-tracker' ), 'pro', 'cards', 1 ),
			'rt_breakdown' => array( __( 'Pages, sources & devices', 'ecomm-user-tracker' ), 'pro', 'donut', 1 ),
			'rt_snapshot'  => array( __( 'Visitor snapshot', 'ecomm-user-tracker' ), 'proplus', 'funnel', 1 ),
		);
	}

	/** HTML of every real-time section the current plan may see. */
	public static function live_sections_html( $full = false ) {
		$out = array();
		foreach ( self::realtime_sections() as $key => $def ) {
			if ( ECT_License::has( $def[1] ) ) {
				$out[ $key ] = call_user_func( array( __CLASS__, $key ) );
			}
		}
		if ( $full && ECT_License::has( 'pro' ) ) {
			$out['rt_activity_full'] = self::rt_activity_full();
			$out['rt_recent_full']   = self::rt_recent_full();
		}
		return $out;
	}

	private static function stage_label( $stage ) {
		$labels = array(
			1 => '👀 ' . __( 'Viewing products', 'ecomm-user-tracker' ),
			2 => '🛒 ' . __( 'Added to cart', 'ecomm-user-tracker' ),
			3 => '💳 ' . __( 'At checkout', 'ecomm-user-tracker' ),
			4 => '✅ ' . __( 'Purchased', 'ecomm-user-tracker' ),
		);
		return isset( $labels[ (int) $stage ] ) && ECT_License::has( 'proplus' ) ? $labels[ (int) $stage ] : '';
	}

	public static function rt_recent_full() {
		return self::rt_recent( 100 );
	}

	public static function rt_recent( $limit = 20 ) {
		$rows = ECT_Reports::recent_sessions( $limit );
		if ( ! $rows ) {
			return '<p class="ect-empty">' . esc_html__( 'No visitors in the last 30 minutes.', 'ecomm-user-tracker' ) . '</p>';
		}
		$icons = array(
			'mobile'  => '📱',
			'tablet'  => '📱',
			'desktop' => '🖥',
		);
		$h = '<ul class="ect-feed">';
		foreach ( $rows as $r ) {
			$live  = $r['last_seen'] >= time() - ECT_LIVE_WINDOW;
			$stage = self::stage_label( $r['stage'] );
			/* translators: %d: visitor number */
			$h .= '<li class="ect-clickable" data-ect-visitor="' . (int) $r['id'] . '"><span>' . ( $live ? '<i class="ect-dot ect-dot-sm"></i> ' : '' ) . ( isset( $icons[ $r['device'] ] ) ? $icons[ $r['device'] ] : '' ) . ' ' . esc_html( sprintf( __( 'Visitor #%d', 'ecomm-user-tracker' ), $r['id'] ) ) . ' <span data-ect-cc="' . esc_attr( $r['country'] ? $r['country'] : 'XX' ) . '" data-ect-flag-only></span>' . ( $stage ? ' <b class="ect-stage ect-stage-' . (int) $r['stage'] . '">' . esc_html( $stage ) . '</b>' : '' ) . '</span>';
			/* translators: %d: number of pages */
			$h .= '<small>' . esc_html( ECT_Source::label( $r['channel'], $r['source'] ) . ' · ' . $r['exit_page'] . ' · ' . sprintf( _n( '%d page', '%d pages', (int) $r['pageviews'], 'ecomm-user-tracker' ), $r['pageviews'] ) . ' · ' . human_time_diff( $r['last_seen'] ) ) . '</small></li>';
		}
		$h .= '</ul>';
		if ( $limit < 50 && count( $rows ) >= $limit ) {
			$h .= '<p class="ect-more"><button type="button" class="button" data-ect-open="ect-recent-modal">' . esc_html__( 'View more', 'ecomm-user-tracker' ) . '</button></p>';
		}
		return $h;
	}

	/** Full history of one visit (opened from Recent visitors / abandoned carts). */
	public static function visitor_html( $id ) {
		$v = ECT_Reports::visit( $id );
		if ( ! $v ) {
			return '<p class="ect-empty">' . esc_html__( 'This visit is no longer available.', 'ecomm-user-tracker' ) . '</p>';
		}
		$s     = $v['session'];
		$names = array(
			'mobile'  => __( 'Mobile', 'ecomm-user-tracker' ),
			'desktop' => __( 'Desktop', 'ecomm-user-tracker' ),
			'tablet'  => __( 'Tablet', 'ecomm-user-tracker' ),
		);
		$facts = array(
			array( __( 'Came from', 'ecomm-user-tracker' ), ECT_Source::label( $s['channel'], $s['source'] ) . ( $s['campaign'] ? ' · ' . $s['campaign'] : '' ) ),
			array( __( 'Location', 'ecomm-user-tracker' ), '<span data-ect-cc="' . esc_attr( $s['country'] ? $s['country'] : 'XX' ) . '"></span>' ),
			array( __( 'Device', 'ecomm-user-tracker' ), ( isset( $names[ $s['device'] ] ) ? $names[ $s['device'] ] : $s['device'] ) . ( $s['browser'] ? ' · ' . $s['browser'] : '' ) . ( $s['os'] ? ' · ' . $s['os'] : '' ) ),
			array( __( 'Visit length', 'ecomm-user-tracker' ), self::duration( $s['last_seen'] - $s['started'] ) . ' · ' . sprintf( /* translators: %d: pages */ _n( '%d page', '%d pages', (int) $s['pageviews'], 'ecomm-user-tracker' ), $s['pageviews'] ) ),
			array( __( 'Visitor', 'ecomm-user-tracker' ), $s['is_new'] ? __( 'New visitor', 'ecomm-user-tracker' ) : __( 'Returning visitor', 'ecomm-user-tracker' ) ),
		);
		$h = '<div class="ect-facts">';
		foreach ( $facts as $f ) {
			$h .= '<div><span>' . esc_html( $f[0] ) . '</span><b>' . wp_kses( $f[1], array( 'span' => array( 'data-ect-cc' => true ) ) ) . '</b></div>';
		}
		$stage = self::stage_label( $s['stage'] );
		$h    .= '</div>' . ( $stage ? '<p><b class="ect-stage ect-stage-' . (int) $s['stage'] . '">' . esc_html( $stage ) . '</b></p>' : '' );
		$h    .= '<h4>' . esc_html__( 'Timeline', 'ecomm-user-tracker' ) . '</h4><ol class="ect-timeline">';
		$icons = array(
			'pv'          => '📄',
			'click'       => '🖱',
			'add_to_cart' => '🛒',
			'checkout'    => '💳',
			'purchase'    => '✅',
			'form_start'  => '✏️',
			'form_submit' => '📝',
			'search'      => '🔍',
			'contact'     => '📞',
		);
		foreach ( $v['steps'] as $st ) {
			switch ( $st['type'] ) {
				case 'pv':
					/* translators: 1: page name, 2: time on page */
					$text = sprintf( __( 'Viewed %1$s', 'ecomm-user-tracker' ), self::page_name( $st['label'] ) ) . ( $st['dur'] ? ' · ' . self::duration( $st['dur'] ) : '' );
					break;
				case 'click':
					/* translators: 1: button text */
					$text = sprintf( __( 'Clicked “%s”', 'ecomm-user-tracker' ), $st['label'] );
					break;
				case 'add_to_cart':
					/* translators: %s: product */
					$text = sprintf( __( 'Added %s to cart', 'ecomm-user-tracker' ), $st['label'] ) . ( $st['value'] > 0 ? ' · ' . self::money( $st['value'] ) : '' );
					break;
				case 'checkout':
					$text = __( 'Reached checkout', 'ecomm-user-tracker' );
					break;
				case 'purchase':
					/* translators: %s: amount */
					$text = sprintf( __( 'Placed order %1$s · %2$s', 'ecomm-user-tracker' ), $st['label'], self::money( $st['value'] ) );
					break;
				case 'form_start':
					/* translators: %s: form */
					$text = sprintf( __( 'Started filling %s', 'ecomm-user-tracker' ), ECT_Reports::form_label( $st['label'] ) );
					break;
				case 'form_submit':
					/* translators: %s: form */
					$text = sprintf( __( 'Submitted %s', 'ecomm-user-tracker' ), ECT_Reports::form_label( $st['label'] ) );
					break;
				case 'search':
					/* translators: %s: search term */
					$text = sprintf( __( 'Searched for “%s”', 'ecomm-user-tracker' ), $st['label'] ) . ( 0 == $st['value'] ? ' · ' . __( 'no results', 'ecomm-user-tracker' ) : '' ); // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual
					break;
				case 'contact':
					/* translators: %s: phone / email / WhatsApp */
					$text = sprintf( __( 'Clicked to contact (%s)', 'ecomm-user-tracker' ), $st['label'] );
					break;
				default:
					$text = $st['type'] . ' ' . $st['label'];
			}
			$h .= '<li><span class="ect-tl-ico">' . ( isset( $icons[ $st['type'] ] ) ? $icons[ $st['type'] ] : '•' ) . '</span><div>' . esc_html( $text ) . '<small>' . esc_html( wp_date( 'H:i:s', $st['ts'] ) ) . '</small></div></li>';
		}
		$h .= '</ol>';
		if ( $v['past'] ) {
			$h .= '<h4>' . esc_html__( 'Earlier visits by this visitor', 'ecomm-user-tracker' ) . '</h4><ul class="ect-feed">';
			foreach ( $v['past'] as $p ) {
				$h .= '<li><a href="#" data-ect-visitor="' . (int) $p['id'] . '">' . esc_html( wp_date( get_option( 'date_format' ) . ' H:i', $p['started'] ) ) . '</a><small>' . esc_html( ECT_Source::label( $p['channel'], $p['source'] ) . ' · ' . sprintf( /* translators: %d pages */ _n( '%d page', '%d pages', (int) $p['pageviews'], 'ecomm-user-tracker' ), $p['pageviews'] ) . ( self::stage_label( $p['stage'] ) ? ' · ' . self::stage_label( $p['stage'] ) : '' ) ) . '</small></li>';
			}
			$h .= '</ul>';
		}
		return $h;
	}

	private static function visitor_modal() {
		echo '<div id="ect-visitor-modal" class="ect-modal" hidden><div class="ect-modal-box ect-modal-lg" role="dialog" aria-modal="true"><div class="ect-modal-head"><h2 data-ect-visitor-title>' . esc_html__( 'Visitor', 'ecomm-user-tracker' ) . '</h2><button type="button" class="ect-modal-close" data-ect-close>×</button></div><div class="ect-modal-body" data-ect-visitor-body></div></div></div>';
	}

	public static function rt_last30() {
		return '<p class="ect-big">' . esc_html( number_format_i18n( ECT_Reports::last30() ) ) . '</p>';
	}

	public static function rt_activity( $limit = 25 ) {
		$rows = ECT_Reports::recent_activity( $limit );
		if ( ! $rows ) {
			return '<p class="ect-empty">' . esc_html__( 'No activity in the last 24 hours.', 'ecomm-user-tracker' ) . '</p>';
		}
		$h = '<ul class="ect-feed">';
		foreach ( $rows as $r ) {
			$h .= '<li class="ect-clickable" data-ect-visitor="' . (int) $r['sid'] . '"><span>' . esc_html( $r['text'] ) . '</span><small>' . esc_html( human_time_diff( $r['ts'] ) ) . ' · <span data-ect-cc="' . esc_attr( $r['country'] ? $r['country'] : 'XX' ) . '"></span></small></li>';
		}
		$h .= '</ul>';
		if ( $limit < 50 && count( $rows ) >= $limit ) {
			$h .= '<p class="ect-more"><button type="button" class="button" data-ect-open="ect-activity-modal">' . esc_html__( 'View more', 'ecomm-user-tracker' ) . '</button></p>';
		}
		return $h;
	}

	/** Full live activity for the "View more" popup (last 24 hours). */
	public static function rt_activity_full() {
		return self::rt_activity( 200 );
	}

	public static function rt_breakdown() {
		return '<h4>' . esc_html__( 'Pages', 'ecomm-user-tracker' ) . '</h4>' . self::bars( ECT_Reports::live_breakdown( 'exit_page' ), 'text', null, __( 'No visitors at the moment', 'ecomm-user-tracker' ) )
			. '<h4>' . esc_html__( 'Traffic source', 'ecomm-user-tracker' ) . '</h4>' . self::bars( ECT_Reports::live_sources(), 'text', null, '—' )
			. '<h4>' . esc_html__( 'Device', 'ecomm-user-tracker' ) . '</h4>' . self::bars( ECT_Reports::live_breakdown( 'device' ), 'device', null, '—' );
	}

	public static function rt_snapshot() {
		$s = ECT_Reports::snapshot();
		return '<p class="ect-muted">' . esc_html__( 'Current number of visitors at each stage of the shopping process.', 'ecomm-user-tracker' ) . '</p>' . self::kpis(
			array(
				array( '🖥 ' . __( 'Browsing site', 'ecomm-user-tracker' ), number_format_i18n( $s['browsing'] ) ),
				array( '🛒 ' . __( 'Adding to cart', 'ecomm-user-tracker' ), number_format_i18n( $s['cart'] ) ),
				array( '💳 ' . __( 'Checking out', 'ecomm-user-tracker' ), number_format_i18n( $s['checkout'] ) ),
				array( '✅ ' . __( 'Purchased (30 min)', 'ecomm-user-tracker' ), number_format_i18n( $s['bought'] ) ),
			)
		);
	}

	private static function live_section( $key ) {
		$def = self::realtime_sections()[ $key ];
		if ( ECT_License::has( $def[1] ) ) {
			$modals = array(
				'rt_recent'   => 'ect-recent-modal',
				'rt_activity' => 'ect-activity-modal',
			);
			$top    = isset( $modals[ $key ] ) ? '<button type="button" class="button-link ect-card-link" data-ect-open="' . esc_attr( $modals[ $key ] ) . '">' . esc_html__( 'View more', 'ecomm-user-tracker' ) . ' →</button>' : '';
			echo '<div class="ect-card ect-span-' . (int) $def[3] . '"><div class="ect-card-head"><h3>' . esc_html( $def[0] ) . '</h3>' . $top . '</div><div class="ect-scroll" data-ect-sec="' . esc_attr( $key ) . '">' . call_user_func( array( __CLASS__, $key ) ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			self::locked( $def[0], $def[1], $def[2], $def[3] );
		}
	}

	private static function page_realtime() {
		self::grid_open( 3 );
		echo '<div class="ect-span-2">';
		self::live_card( true, true );
		echo '</div>';
		self::live_section( 'rt_last30' );
		self::grid_close();
		self::grid_open( 3 );
		self::live_section( 'rt_recent' );
		self::live_section( 'rt_activity' );
		self::live_section( 'rt_breakdown' );
		self::grid_close();
		self::grid_open( 1 );
		self::live_section( 'rt_snapshot' );
		self::grid_close();
		if ( ECT_License::has( 'pro' ) ) {
			self::visitor_modal();
			echo '<div id="ect-recent-modal" class="ect-modal" hidden><div class="ect-modal-box ect-modal-lg" role="dialog" aria-modal="true" aria-labelledby="ect-recent-title">';
			echo '<div class="ect-modal-head"><h2 id="ect-recent-title"><span class="ect-dot"></span> ' . esc_html__( 'Recent visitors', 'ecomm-user-tracker' ) . '</h2><button type="button" class="ect-modal-close" data-ect-close aria-label="' . esc_attr__( 'Close', 'ecomm-user-tracker' ) . '">×</button></div>';
			echo '<div class="ect-modal-body" data-ect-sec="rt_recent_full" data-ect-lazy>' . self::rt_recent_full() . '</div></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '<div id="ect-activity-modal" class="ect-modal" hidden><div class="ect-modal-box ect-modal-lg" role="dialog" aria-modal="true" aria-labelledby="ect-activity-title">';
			echo '<div class="ect-modal-head"><h2 id="ect-activity-title"><span class="ect-dot"></span> ' . esc_html__( 'Live activity', 'ecomm-user-tracker' ) . '</h2><button type="button" class="ect-modal-close" data-ect-close aria-label="' . esc_attr__( 'Close', 'ecomm-user-tracker' ) . '">×</button></div>';
			echo '<div class="ect-modal-body" data-ect-sec="rt_activity_full" data-ect-lazy>' . self::rt_activity_full() . '</div></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	private static function page_traffic() {
		self::grid_open( 3 );
		self::section(
			__( 'Site sessions & unique visitors', 'ecomm-user-tracker' ),
			'pro',
			'kpis',
			2,
			function () {
				$t  = self::rep()->totals();
				$pt = self::$prev->totals();
				return self::kpis(
					array(
						array( __( 'Site sessions', 'ecomm-user-tracker' ), number_format_i18n( $t['sessions'] ), self::change( $t['sessions'], $pt['sessions'] ) ),
						array( __( 'Unique visitors', 'ecomm-user-tracker' ), number_format_i18n( $t['visitors'] ), self::change( $t['visitors'], $pt['visitors'] ) ),
						array( __( 'Page views', 'ecomm-user-tracker' ), number_format_i18n( $t['pageviews'] ), self::change( $t['pageviews'], $pt['pageviews'] ) ),
					)
				);
			}
		);
		self::section( __( 'Sessions by source and category', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::bars( self::rep()->sources( 25 ) ); } );
		self::section( __( 'Sessions over time', 'ecomm-user-tracker' ), 'pro', 'chart', 2, function () { return self::chart( self::rep()->series() ); } );
		self::section( __( 'Avg. sessions by day', 'ecomm-user-tracker' ), 'pro', 'funnel', 1, function () { return self::weekday_chart( self::rep()->weekdays() ); } );
		self::section( __( 'New vs returning visitors', 'ecomm-user-tracker' ), 'pro', 'donut', 1, function () { return self::bars( self::rep()->new_returning() ); } );
		self::section( __( 'Sessions by device', 'ecomm-user-tracker' ), 'pro', 'donut', 1, function () { return self::bars( self::rep()->by( 'device', 3 ), 'device' ); } );
		self::section(
			__( 'Traffic insights', 'ecomm-user-tracker' ),
			'agency',
			'cards',
			1,
			function () {
				$list = self::rep()->insights();
				return self::insights_html( array_slice( $list, 0, 3 ) ) . '<p><a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-insights' ) ) . '">' . esc_html__( 'See all insights', 'ecomm-user-tracker' ) . ' →</a></p>';
			}
		);
		self::section( __( 'Sessions by country', 'ecomm-user-tracker' ), 'pro', 'bars', 3, function () { return self::bars( self::rep()->by( 'country', 15 ), 'country' ); } );
		$conv = function ( $r ) {
			/* translators: 1: sessions, 2: conversion rate */
			return sprintf( __( '%1$s · %2$s%% conv.', 'ecomm-user-tracker' ), number_format_i18n( $r['c'] ), $r['rate'] );
		};
		self::section( __( 'Device report', 'ecomm-user-tracker' ), 'proplus', 'bars', 1, function () use ( $conv ) { return self::bars( self::rep()->conversion_by( 'device' ), 'device', $conv ); } );
		self::section( __( 'Browsers', 'ecomm-user-tracker' ), 'proplus', 'bars', 1, function () use ( $conv ) { return self::bars( self::rep()->conversion_by( 'browser' ), 'text', $conv ); } );
		self::section( __( 'Operating systems', 'ecomm-user-tracker' ), 'proplus', 'bars', 1, function () use ( $conv ) { return self::bars( self::rep()->conversion_by( 'os' ), 'text', $conv ); } );
		self::grid_close();
	}

	private static function page_behavior() {
		self::grid_open( 3 );
		self::section(
			__( 'Session duration, pages per session, bounce rate', 'ecomm-user-tracker' ),
			'pro',
			'kpis',
			2,
			function () {
				$t  = self::rep()->totals();
				$pt = self::$prev->totals();
				return self::kpis(
					array(
						array( __( 'Avg. session duration', 'ecomm-user-tracker' ), self::duration( $t['duration'] ), self::change( $t['duration'], $pt['duration'] ) ),
						array( __( 'Avg. pages per session', 'ecomm-user-tracker' ), number_format_i18n( $t['per_sess'], 1 ), self::change( $t['per_sess'], $pt['per_sess'] ) ),
						array( __( 'Bounce rate', 'ecomm-user-tracker' ), $t['bounce'] . '%', self::change( $t['bounce'], $pt['bounce'], true ) ),
					)
				);
			}
		);
		self::section( __( 'Top clicks', 'ecomm-user-tracker' ), 'proplus', 'bars', 1, function () { return self::bars( self::rep()->events_by( 'click', 30 ), 'text', null, __( 'Button and link clicks will show here.', 'ecomm-user-tracker' ) ); } );
		self::section( __( 'Top pages', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::bars( self::rep()->top_pages( 30 ) ); } );
		self::section( __( 'Top site searches', 'ecomm-user-tracker' ), 'proplus', 'bars', 1, function () { return self::bars( self::rep()->searches( false, 30 ), 'text', null, __( 'What visitors search for on your site will show here.', 'ecomm-user-tracker' ) ); } );
		self::section( __( 'Searches with no results', 'ecomm-user-tracker' ), 'proplus', 'bars', 1, function () { return self::bars( self::rep()->searches( true, 30 ), 'text', null, __( 'No empty searches. Great!', 'ecomm-user-tracker' ) ); } );
		self::section( __( 'Clicks to contact', 'ecomm-user-tracker' ), 'proplus', 'bars', 1, function () { return self::bars( self::rep()->events_by( 'contact', 30 ), 'text', null, __( 'Phone, email and WhatsApp link clicks will show here.', 'ecomm-user-tracker' ) ); } );
		self::section( __( '404 errors', 'ecomm-user-tracker' ), 'proplus', 'bars', 1, function () { return self::bars( self::rep()->errors_404( 30 ), 'text', null, __( 'No broken pages visited.', 'ecomm-user-tracker' ) ); } );
		self::section( __( 'Top blog posts', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::bars( self::rep()->blog_posts( false, 30 ), 'text', null, __( 'Blog post visits will show here.', 'ecomm-user-tracker' ) ); } );
		self::section( __( 'Entry pages', 'ecomm-user-tracker' ), 'pro', 'bars', 1, function () { return self::bars( self::rep()->by( 'entry_page', 30 ) ); } );
		self::section(
			__( 'Exit pages', 'ecomm-user-tracker' ),
			'pro',
			'bars',
			1,
			function () {
				return self::bars(
					self::rep()->exit_pages( 30 ),
					'text',
					function ( $r ) {
						/* translators: 1: exits, 2: exit rate */
						return sprintf( __( '%1$s · %2$s%% exit', 'ecomm-user-tracker' ), number_format_i18n( $r['c'] ), $r['rate'] );
					}
				);
			}
		);
		self::section(
			__( 'Avg. time on page', 'ecomm-user-tracker' ),
			'pro',
			'bars',
			3,
			function () {
				return self::bars(
					self::rep()->time_on_page( 30 ),
					'text',
					function ( $r ) {
						return self::duration( $r['c'] );
					}
				);
			}
		);
		self::section( __( 'Top navigation flows', 'ecomm-user-tracker' ), 'proplus', 'funnel', 3, array( __CLASS__, 'flows_html' ) );
		self::section( __( 'Form submissions', 'ecomm-user-tracker' ), 'proplus', 'cards', 3, array( __CLASS__, 'forms_html' ) );
		self::grid_close();
		self::recordings_banner();
	}

	/** Friendly page name for a path: "/" → Home, "/product/klow/" → product title. */
	private static function page_name( $path ) {
		static $cache = array();
		if ( isset( $cache[ $path ] ) ) {
			return $cache[ $path ];
		}
		$name = $path;
		if ( '/' === $path ) {
			$name = __( 'Home', 'ecomm-user-tracker' );
		} else {
			$id = url_to_postid( home_url( $path ) );
			if ( ! $id && function_exists( 'wc_get_page_id' ) ) {
				foreach ( array( 'shop', 'cart', 'checkout', 'myaccount' ) as $wc ) {
					$pid = wc_get_page_id( $wc );
					if ( $pid > 0 && untrailingslashit( (string) wp_parse_url( get_permalink( $pid ), PHP_URL_PATH ) ) === untrailingslashit( $path ) ) {
						$id = $pid;
						break;
					}
				}
			}
			if ( $id ) {
				$title = get_the_title( $id );
				$name  = $title ? wp_strip_all_tags( $title ) : $path;
			}
		}
		$cache[ $path ] = $name;
		return $name;
	}

	public static function flows_html() {
		$steps = self::rep()->flows();
		$top   = self::rep()->top_paths( 8 );
		if ( ! $steps[0]['total'] ) {
			return '<p class="ect-empty">' . esc_html__( 'No visits in this period yet.', 'ecomm-user-tracker' ) . '</p>';
		}
		$names = array( __( 'Landed on the site', 'ecomm-user-tracker' ), __( 'Opened a 2nd page', 'ecomm-user-tracker' ), __( 'Opened a 3rd page', 'ecomm-user-tracker' ), __( 'Opened a 4th page', 'ecomm-user-tracker' ) );
		$first = max( 1, $steps[0]['total'] );

		// 1. How many visitors keep going at each step.
		$h = '<div class="ect-steps-row">';
		foreach ( $steps as $i => $st ) {
			if ( $i ) {
				$h .= '<div class="ect-step-arrow">→<small>' . ( $st['dropped'] ? esc_html( sprintf( /* translators: %s: number */ __( '%s left', 'ecomm-user-tracker' ), number_format_i18n( $st['dropped'] ) ) ) : '' ) . '</small></div>';
			}
			$h .= '<div class="ect-step"><strong>' . esc_html( number_format_i18n( $st['total'] ) ) . '</strong><span>' . esc_html( $names[ $i ] ) . '</span><small>' . esc_html( round( 100 * $st['total'] / $first ) . '%' ) . '</small></div>';
		}
		$h .= '</div>';

		// 2. The most common journeys, written out page by page.
		$h .= '<h4>' . esc_html__( 'Most common journeys', 'ecomm-user-tracker' ) . '</h4><ol class="ect-paths">';
		foreach ( $top['paths'] as $p ) {
			$chips = array();
			foreach ( $p['pages'] as $path ) {
				$chips[] = '<span class="ect-chip" title="' . esc_attr( $path ) . '">' . esc_html( self::page_name( $path ) ) . '</span>';
			}
			$end  = count( $p['pages'] ) < 4 ? '<span class="ect-chip ect-chip-exit">' . esc_html__( 'Left site', 'ecomm-user-tracker' ) . '</span>' : '<span class="ect-chip ect-chip-more">…</span>';
			$pct  = round( 100 * $p['c'] / max( 1, $top['total'] ) );
			/* translators: 1: number of visits, 2: percent */
			$h   .= '<li><div class="ect-path">' . implode( '<i>→</i>', $chips ) . '<i>→</i>' . $end . '</div><small>' . esc_html( sprintf( _n( '%1$s visit · %2$s%%', '%1$s visits · %2$s%%', $p['c'], 'ecomm-user-tracker' ), number_format_i18n( $p['c'] ), $pct ) ) . '</small></li>';
		}
		$h .= '</ol><p class="ect-flow-cta"><a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-recordings' ) ) . '">🎥 ' . esc_html__( 'Start Session Recordings', 'ecomm-user-tracker' ) . '</a></p>';
		return $h;
	}

	public static function forms_html() {
		$f    = self::rep()->forms();
		$rows = array();
		foreach ( array_slice( $f['forms'], 0, 30 ) as $r ) {
			$rows[] = array(
				'k' => esc_html( $r['label'] ),
				'v' => esc_html( number_format_i18n( $r['v'] ) ),
				's' => esc_html( number_format_i18n( $r['s'] ) ),
				'x' => '<b>' . esc_html( number_format_i18n( $r['x'] ) ) . '</b>',
			);
		}
		return '<div class="ect-grid ect-cols-3"><div class="ect-span-2">' . self::table(
			array(
				'k' => __( 'Form', 'ecomm-user-tracker' ),
				'v' => __( 'Form views', 'ecomm-user-tracker' ),
				's' => __( 'Submissions started', 'ecomm-user-tracker' ),
				'x' => __( 'Total submissions', 'ecomm-user-tracker' ),
			),
			$rows,
			__( 'When visitors use your contact, checkout, account or newsletter forms, you will see them here. Choose which forms to track in Settings.', 'ecomm-user-tracker' )
		) . '</div><div><h4>' . esc_html__( 'Traffic sources', 'ecomm-user-tracker' ) . '</h4>' . self::bars( $f['sources'], 'text', null, '—' ) . '<h4>' . esc_html__( 'Locations', 'ecomm-user-tracker' ) . '</h4>' . self::bars( $f['countries'], 'country', null, '—' ) . '</div></div>';
	}

	private static function insights_html( $list ) {
		if ( ! $list ) {
			return '<p class="ect-empty">' . esc_html__( 'Not enough data yet. Insights appear once your site has more visits.', 'ecomm-user-tracker' ) . '</p>';
		}
		$icons = array(
			'attention' => '🚩',
			'growth'    => '⭐',
			'trend'     => '📈',
		);
		$h = '<ul class="ect-insights">';
		foreach ( $list as $in ) {
			$h .= '<li class="ect-ins-' . esc_attr( $in[0] ) . '"><span>' . $icons[ $in[0] ] . '</span><div>' . wp_kses( $in[1], array( 'b' => array() ) ) . ( $in[2] ? '<small>' . esc_html( $in[2] ) . '</small>' : '' ) . '</div><a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-' . $in[3] ) ) . '">' . esc_html__( 'Details', 'ecomm-user-tracker' ) . '</a></li>';
		}
		return $h . '</ul>';
	}

	private static function page_marketing() {
		if ( ECT_License::has( 'proplus' ) ) {
			self::range_picker( self::SLUG . '-marketing' );
		}
		self::grid_open( 1 );
		self::section(
			__( 'Performance by channel', 'ecomm-user-tracker' ),
			'proplus',
			'chart',
			1,
			function () {
				$rows = array();
				foreach ( self::rep()->channels() as $c ) {
					$rows[] = array(
						'k' => esc_html( $c['k'] ),
						'c' => esc_html( number_format_i18n( $c['c'] ) ),
						'p' => esc_html( number_format_i18n( $c['p'] ) ),
						'r' => esc_html( $c['rate'] . '%' ),
						'm' => esc_html( self::money( $c['rev'] ) ),
					);
				}
				return self::chart( self::rep()->series() ) . self::table(
					array(
						'k' => __( 'Channel', 'ecomm-user-tracker' ),
						'c' => __( 'Sessions', 'ecomm-user-tracker' ),
						'p' => __( 'Orders', 'ecomm-user-tracker' ),
						'r' => __( 'Conversion', 'ecomm-user-tracker' ),
						'm' => __( 'Sales', 'ecomm-user-tracker' ),
					),
					$rows
				);
			}
		);
		self::grid_close();
		self::grid_open( 2 );
		self::section( __( 'Organic search', 'ecomm-user-tracker' ), 'proplus', 'bars', 1, function () { return self::bars( array_values( array_filter( self::rep()->sources( 20 ), function ( $r ) { return 'organic_search' === $r['channel']; } ) ), 'text', null, __( 'No visits from search engines in this period.', 'ecomm-user-tracker' ) ) . self::connect_soon( __( 'Connect Google Search Console to see search queries and positions.', 'ecomm-user-tracker' ) ); } );
		self::section(
			__( 'Email marketing', 'ecomm-user-tracker' ),
			'proplus',
			'cards',
			1,
			function () {
				$d    = self::rep()->channel_detail( 'email', 'campaign' );
				$rows = array();
				foreach ( $d['rows'] as $r ) {
					$rows[] = array(
						'k' => esc_html( $r['k'] ? $r['k'] : '—' ),
						'c' => esc_html( number_format_i18n( $r['c'] ) ),
						'p' => esc_html( number_format_i18n( $r['p'] ) ),
					);
				}
				return self::table(
					array(
						'k' => __( 'Email / campaign', 'ecomm-user-tracker' ),
						'c' => __( 'Visits', 'ecomm-user-tracker' ),
						'p' => __( 'Orders', 'ecomm-user-tracker' ),
					),
					$rows,
					__( 'Links in emails sent from your site (order emails, newsletters…) are tagged automatically. Clicks and sales will show here.', 'ecomm-user-tracker' )
				);
			}
		);
		self::grid_close();
		echo '<div id="ai-visibility"></div>';
		self::grid_open( 3 );
		self::section( __( 'AI visibility score', 'ecomm-user-tracker' ), 'proplus', 'donut', 1, array( __CLASS__, 'ai_score_html' ), array( 'ECT_Llms', 'form' ) );
		self::section(
			__( 'AI platforms', 'ecomm-user-tracker' ),
			'proplus',
			'bars',
			1,
			function () {
				$d = self::rep()->channel_detail( 'ai' );
				return self::bars(
					$d['rows'],
					'text',
					function ( $r ) {
						/* translators: 1: visits, 2: orders */
						return sprintf( __( '%1$s visits · %2$s orders', 'ecomm-user-tracker' ), number_format_i18n( $r['c'] ), number_format_i18n( $r['p'] ) );
					},
					__( 'No visits from ChatGPT, Claude, Gemini or other AI tools yet.', 'ecomm-user-tracker' )
				) . '<h4>' . esc_html__( 'Top pages AI sends visitors to', 'ecomm-user-tracker' ) . '</h4>' . self::bars( $d['pages'], 'text', null, '—' );
			}
		);
		self::section(
			__( 'AI bots reading your site', 'ecomm-user-tracker' ),
			'proplus',
			'bars',
			1,
			function () {
				return self::bars( self::rep()->bots(), 'text', null, __( 'No AI bot visits recorded yet.', 'ecomm-user-tracker' ) ) . '<h4>' . esc_html__( 'Pages read by AI bots', 'ecomm-user-tracker' ) . '</h4>' . self::bars( self::rep()->bot_pages( 6 ), 'text', null, '—' );
			}
		);
		self::grid_close();
	}

	public static function ai_score_html() {
		$a = self::rep()->ai_score();
		$h = '<div class="ect-score"><div class="ect-score-ring" style="--p:' . (int) $a['score'] . '"><span>' . (int) $a['score'] . '<small>/100</small></span></div><ul>';
		$h .= '<li>' . esc_html__( 'AI traffic', 'ecomm-user-tracker' ) . ' <b>' . (int) $a['traffic'] . '/40</b></li>';
		$h .= '<li>' . esc_html__( 'AI bot activity', 'ecomm-user-tracker' ) . ' <b>' . (int) $a['crawl'] . '/30</b></li>';
		$h .= '<li>' . esc_html__( 'AI readiness', 'ecomm-user-tracker' ) . ' <b>' . (int) $a['readiness'] . '/30</b></li></ul></div>';
		$h .= '<h4>' . esc_html__( 'Improve your score', 'ecomm-user-tracker' ) . '</h4><ul class="ect-checks">';
		foreach ( $a['checks'] as $c ) {
			$h .= '<li class="' . ( $c[1] ? 'ok' : 'no' ) . '">' . ( $c[1] ? '✅ ' : '⚠️ ' ) . esc_html( $c[0] ) . ( $c[1] ? '' : '<small>' . esc_html( $c[2] ) . '</small>' ) . '</li>';
		}
		return $h . '</ul>';
	}

	private static function page_recordings() {
		self::grid_open( 1 );
		if ( ! ECT_License::has( 'proplus' ) ) {
			self::locked( __( 'Session recordings', 'ecomm-user-tracker' ), 'proplus', 'cards', 1 );
			self::grid_close();
			return;
		}
		$o    = ECT_Recorder::opts();
		$u    = ECT_Recorder::usage();
		$pct  = min( 100, round( 100 * $u['b'] / ECT_Recorder::MONTHLY_CAP ) );
		$list = ECT_Recorder::list_recordings();

		if ( ECT_Recorder::space_warning() ) {
			echo '<div class="notice notice-warning inline"><p>⚠️ ' . esc_html__( 'Your space will fill up soon. Recordings are kept for 30 days and auto-delete is off — turn on auto-delete or delete old recordings.', 'ecomm-user-tracker' ) . '</p></div>';
		}
		if ( $u['b'] >= ECT_Recorder::MONTHLY_CAP ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html__( 'The 1 GB monthly recording limit is reached. Recording is paused until next month.', 'ecomm-user-tracker' ) . '</p></div>';
		}

		echo '<div class="ect-card"><div class="ect-card-head"><h3>' . esc_html__( 'Session recordings', 'ecomm-user-tracker' ) . '</h3>';
		if ( $list ) {
			echo '<a class="button-link-delete" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=ect_rec_delete&k=all' ), 'ect_rec_delete' ) ) . '" onclick="return confirm(this.dataset.q)" data-q="' . esc_attr__( 'Delete all recordings?', 'ecomm-user-tracker' ) . '">' . esc_html__( 'Delete all', 'ecomm-user-tracker' ) . '</a>';
		}
		echo '</div>';
		/* translators: 1: used MB, 2: percent */
		echo '<p class="ect-muted">' . esc_html( sprintf( __( 'This month: %1$s MB of 1 GB used (%2$s%%). Recordings are saved on your own hosting; form fields are always hidden.', 'ecomm-user-tracker' ), number_format_i18n( $u['b'] / 1048576, 1 ), $pct ) ) . '</p>';
		echo '<div class="ect-usage"><i style="width:' . (int) max( 1, $pct ) . '%"></i></div>';
		if ( ! $o['enabled'] ) {
			echo '<p class="ect-empty">' . esc_html__( 'Recording is switched off. Turn it on below.', 'ecomm-user-tracker' ) . '</p>';
		} elseif ( ! $list ) {
			echo '<p class="ect-empty">' . esc_html__( 'No recordings yet. New visits are recorded automatically and show here within a minute.', 'ecomm-user-tracker' ) . '</p>';
		} else {
			echo '<div class="ect-scroll ect-scroll-tall"><table class="ect-table"><thead><tr><th>' . esc_html__( 'When', 'ecomm-user-tracker' ) . '</th><th>' . esc_html__( 'Visitor', 'ecomm-user-tracker' ) . '</th><th>' . esc_html__( 'Country', 'ecomm-user-tracker' ) . '</th><th>' . esc_html__( 'Device', 'ecomm-user-tracker' ) . '</th><th>' . esc_html__( 'Source', 'ecomm-user-tracker' ) . '</th><th>' . esc_html__( 'Pages', 'ecomm-user-tracker' ) . '</th><th>' . esc_html__( 'Duration', 'ecomm-user-tracker' ) . '</th><th>' . esc_html__( 'Size', 'ecomm-user-tracker' ) . '</th><th></th></tr></thead><tbody>';
			foreach ( $list as $r ) {
				$se  = $r['session'];
				$del = wp_nonce_url( admin_url( 'admin-post.php?action=ect_rec_delete&k=' . $r['key'] ), 'ect_rec_delete' );
				echo '<tr><td>' . esc_html( human_time_diff( $se ? $se->started : $r['time'] ) ) . ' ' . esc_html__( 'ago', 'ecomm-user-tracker' ) . '</td>';
				echo '<td>' . ( $se ? '<a href="#" data-ect-visitor="' . (int) $se->id . '">#' . (int) $se->id . '</a>' . ( (int) $se->stage >= 4 ? ' ✅' : ( (int) $se->stage >= 2 ? ' 🛒' : '' ) ) : '—' ) . '</td>';
				echo '<td>' . ( $se && $se->country ? '<span data-ect-cc="' . esc_attr( $se->country ) . '">' . esc_html( $se->country ) . '</span>' : '—' ) . '</td>';
				echo '<td>' . esc_html( $se ? ucfirst( $se->device ) : '' ) . '</td><td>' . esc_html( $se ? $se->source : '' ) . '</td>';
				echo '<td>' . ( $se ? (int) $se->pageviews : '' ) . '</td><td>' . esc_html( $se ? self::duration( max( 0, $se->last_seen - $se->started ) ) : '' ) . '</td>';
				echo '<td>' . esc_html( size_format( $r['size'], 1 ) ) . '</td>';
				echo '<td class="ect-nowrap"><button type="button" class="button button-primary" data-ect-play="' . esc_attr( $r['key'] ) . '">▶ ' . esc_html__( 'Play', 'ecomm-user-tracker' ) . '</button> <a class="button-link-delete" href="' . esc_url( $del ) . '" aria-label="' . esc_attr__( 'Delete', 'ecomm-user-tracker' ) . '">🗑</a></td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '</div>';

		// Settings.
		echo '<div class="ect-card"><h3>' . esc_html__( 'Recording settings', 'ecomm-user-tracker' ) . '</h3><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ect_rec' );
		echo '<input type="hidden" name="action" value="ect_rec">';
		echo '<p><label><input type="checkbox" name="enabled" value="1"' . checked( $o['enabled'], 1, false ) . '> ' . esc_html__( 'Record visitor sessions', 'ecomm-user-tracker' ) . '</label></p>';
		if ( ECT_License::has( 'agency' ) ) {
			echo '<p><label>' . esc_html__( 'Keep recordings for', 'ecomm-user-tracker' ) . ' <select name="days">';
			foreach ( ECT_Recorder::DAYS_CHOICES as $d ) {
				/* translators: %d: days */
				echo '<option value="' . (int) $d . '"' . selected( $o['days'], $d, false ) . '>' . esc_html( sprintf( _n( '%d day', '%d days', $d, 'ecomm-user-tracker' ), $d ) ) . '</option>';
			}
			echo '</select></label></p>';
			echo '<p><label><input type="checkbox" name="autodelete" value="1"' . checked( $o['autodelete'], 1, false ) . '> ' . esc_html__( 'Delete old recordings automatically', 'ecomm-user-tracker' ) . '</label></p>';
		} else {
			echo '<input type="hidden" name="days" value="2"><input type="hidden" name="autodelete" value="1">';
			echo '<p class="ect-muted">' . esc_html__( 'Recordings are kept for 48 hours. Agency can keep them up to 30 days.', 'ecomm-user-tracker' ) . '</p>';
		}
		echo '<p><button class="button button-primary">' . esc_html__( 'Save', 'ecomm-user-tracker' ) . '</button></p></form></div>';

		// Microsoft Clarity (optional, heatmaps).
		$id = ECT_Integrations::clarity_id();
		echo '<div class="ect-card"><h3>' . esc_html__( 'Heatmaps with Microsoft Clarity (optional)', 'ecomm-user-tracker' ) . '</h3>';
		if ( $id ) {
			$base = 'https://clarity.microsoft.com/projects/view/' . rawurlencode( $id );
			echo '<p><a class="button" target="_blank" rel="noopener" href="' . esc_url( $base . '/heatmaps' ) . '">' . esc_html__( 'Heatmaps', 'ecomm-user-tracker' ) . '</a> <a class="button" target="_blank" rel="noopener" href="' . esc_url( $base . '/impressions' ) . '">' . esc_html__( 'Clarity recordings', 'ecomm-user-tracker' ) . '</a></p>';
		} else {
			echo '<p class="ect-muted"><a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-settings#ect-clarity' ) ) . '">' . esc_html__( 'Add a free Clarity Project ID in Settings', 'ecomm-user-tracker' ) . '</a> ' . esc_html__( 'to also get click and scroll heatmaps.', 'ecomm-user-tracker' ) . '</p>';
		}
		echo '</div>';
		self::grid_close();

		self::visitor_modal();
		echo '<div id="ect-player-modal" class="ect-modal" hidden><div class="ect-modal-box ect-modal-xl" role="dialog" aria-modal="true"><div class="ect-modal-head"><h2>' . esc_html__( 'Session recording', 'ecomm-user-tracker' ) . '</h2><button type="button" class="ect-modal-close" data-ect-close>×</button></div><div class="ect-modal-body" data-ect-player></div></div></div>';
	}

	private static function page_insights() {
		if ( ECT_License::has( 'agency' ) ) {
			self::range_picker( self::SLUG . '-insights' );
		}
		self::grid_open( 1 );
		self::section(
			__( 'Insights', 'ecomm-user-tracker' ),
			'agency',
			'cards',
			1,
			function () {
				$all  = self::rep()->insights();
				$tabs = array(
					'attention' => __( 'Attention required', 'ecomm-user-tracker' ),
					'growth'    => __( 'Growth opportunities', 'ecomm-user-tracker' ),
					'trend'     => __( 'Trends', 'ecomm-user-tracker' ),
				);
				/* translators: %d: count */
				$h = '<p class="ect-tabs-line"><b>' . esc_html( sprintf( __( 'All (%d)', 'ecomm-user-tracker' ), count( $all ) ) ) . '</b>';
				foreach ( $tabs as $k => $label ) {
					$n  = count( array_filter( $all, function ( $i ) use ( $k ) { return $i[0] === $k; } ) );
					$h .= ' · ' . esc_html( $label . ' (' . $n . ')' );
				}
				return $h . '</p>' . self::insights_html( $all );
			}
		);
		self::section( __( 'Benchmarks', 'ecomm-user-tracker' ), 'agency', 'donut', 1, array( __CLASS__, 'benchmarks_html' ) );
		self::grid_close();
		echo '<div class="ect-card ect-hire"><p>' . esc_html__( 'Need help driving more traffic to your site?', 'ecomm-user-tracker' ) . '</p>';
		echo '<a class="button" target="_blank" href="https://everon.digital/?utm_source=ecomm-tracker&utm_medium=plugin&utm_campaign=hire-pro">' . esc_html__( 'Hire a Professional', 'ecomm-user-tracker' ) . '</a></div>';
	}

	public static function benchmarks_html() {
		$t  = self::rep()->totals();
		if ( $t['visitors'] < 30 ) {
			return '<p><b>' . esc_html__( 'Not enough data yet', 'ecomm-user-tracker' ) . '</b><br>' . esc_html__( "You'll see benchmarks once you have 30 visitors in the selected period.", 'ecomm-user-tracker' ) . '</p>';
		}
		$b   = ECT_Reports::benchmarks();
		$nr  = self::rep()->new_returning();
		$ret = ( $nr[0]['c'] + $nr[1]['c'] ) ? 100 * $nr[1]['c'] / ( $nr[0]['c'] + $nr[1]['c'] ) : 0;
		$f   = self::rep()->funnel();
		$conv = $f[0]['c'] ? 100 * $f[4]['c'] / $f[0]['c'] : 0;
		$ab   = $f[2]['c'] ? 100 * ( $f[2]['c'] - $f[4]['c'] ) / $f[2]['c'] : 0;
		$ch   = array();
		foreach ( self::rep()->channels() as $c ) {
			$ch[ $c['channel'] ] = $c['c'];
		}
		$share = function ( $k ) use ( $ch, $t ) {
			return $t['sessions'] ? 100 * ( isset( $ch[ $k ] ) ? $ch[ $k ] : 0 ) / $t['sessions'] : 0;
		};
		$rows = array(
			array( __( 'Avg. session duration', 'ecomm-user-tracker' ), self::duration( $t['duration'] ), self::duration( $b['duration'] ), $t['duration'] >= $b['duration'] ),
			array( __( 'Pages per session', 'ecomm-user-tracker' ), number_format_i18n( $t['per_sess'], 1 ), $b['per_sess'], $t['per_sess'] >= $b['per_sess'] ),
			array( __( 'Bounce rate', 'ecomm-user-tracker' ), $t['bounce'] . '%', $b['bounce'] . '%', $t['bounce'] <= $b['bounce'] ),
			array( __( 'Returning visitors', 'ecomm-user-tracker' ), round( $ret ) . '%', $b['returning'] . '%', $ret >= $b['returning'] ),
			array( __( 'Conversion rate', 'ecomm-user-tracker' ), round( $conv, 1 ) . '%', $b['conversion'] . '%', $conv >= $b['conversion'] ),
			array( __( 'Cart abandonment', 'ecomm-user-tracker' ), round( $ab ) . '%', $b['abandon'] . '%', $ab <= $b['abandon'] ),
			array( __( 'Organic search', 'ecomm-user-tracker' ), round( $share( 'organic_search' ) ) . '%', $b['organic'] . '%', $share( 'organic_search' ) >= $b['organic'] ),
			array( __( 'Social', 'ecomm-user-tracker' ), round( $share( 'organic_social' ) + $share( 'paid_social' ) ) . '%', $b['social'] . '%', ( $share( 'organic_social' ) + $share( 'paid_social' ) ) >= $b['social'] ),
		);
		$out = array();
		foreach ( $rows as $r ) {
			$out[] = array(
				'k' => esc_html( $r[0] ),
				'y' => '<b>' . esc_html( $r[1] ) . '</b>',
				't' => esc_html( $r[2] ),
				'v' => $r[3] ? '<span class="ect-good">👍 ' . esc_html__( 'Better than typical stores', 'ecomm-user-tracker' ) . '</span>' : '<span class="ect-bad">🔧 ' . esc_html__( 'Can be improved', 'ecomm-user-tracker' ) . '</span>',
			);
		}
		return self::table(
			array(
				'k' => __( 'Metric', 'ecomm-user-tracker' ),
				'y' => __( 'Your stats', 'ecomm-user-tracker' ),
				't' => __( 'Typical store', 'ecomm-user-tracker' ),
				'v' => '',
			),
			$out
		) . '<p class="ect-muted">' . esc_html__( 'Compared with typical online-store averages.', 'ecomm-user-tracker' ) . '</p>';
	}

	/* ---------------- All Reports ---------------- */

	private static function report_defs() {
		$r = function ( $title, $plan, $cb, $cols ) {
			return array( $title, $plan, $cb, $cols );
		};
		$cnt  = array( 'k' => __( 'Name', 'ecomm-user-tracker' ), 'c' => __( 'Count', 'ecomm-user-tracker' ) );
		$rev  = array( 'k' => __( 'Name', 'ecomm-user-tracker' ), 'c' => __( 'Orders / qty', 'ecomm-user-tracker' ), 'rev' => __( 'Sales', 'ecomm-user-tracker' ) );
		$conv = array( 'k' => __( 'Name', 'ecomm-user-tracker' ), 'c' => __( 'Sessions', 'ecomm-user-tracker' ), 'p' => __( 'Orders', 'ecomm-user-tracker' ), 'rate' => __( 'Conversion %', 'ecomm-user-tracker' ) );
		$post = array( 'k' => __( 'Post', 'ecomm-user-tracker' ), 'page' => __( 'Page', 'ecomm-user-tracker' ), 'c' => __( 'Visits', 'ecomm-user-tracker' ) );
		$inv  = array( 'k' => __( 'Product', 'ecomm-user-tracker' ), 'sku' => __( 'SKU', 'ecomm-user-tracker' ), 'stock' => __( 'Stock', 'ecomm-user-tracker' ), 'rev' => __( 'Price', 'ecomm-user-tracker' ) );
		return array(
			__( 'Sales', 'ecomm-user-tracker' )      => array(
				'sales-items'     => $r( __( 'Sales by Item', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->sales()['items']; }, $rev ),
				'sales-source'    => $r( __( 'Sales by Traffic Source', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->sales()['sources']; }, $rev ),
				'sales-customers' => $r( __( 'Top Paying Customers', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->sales()['customers']; }, $rev ),
				'sales-channel'   => $r( __( 'Order Conversion by Channel', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->channels(); }, $conv + array( 'rev' => __( 'Sales', 'ecomm-user-tracker' ) ) ),
				'sales-device'    => $r( __( 'Sales by Device', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->conversion_by( 'device' ); }, $conv ),
				'sales-time'      => $r( __( 'Sales over Time', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->woo_daily(); }, array( 'k' => __( 'Date', 'ecomm-user-tracker' ), 'c' => __( 'Orders', 'ecomm-user-tracker' ), 'rev' => __( 'Sales', 'ecomm-user-tracker' ) ) ),
				'sales-aov'       => $r( __( 'Average Order Value over Time', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->woo_daily(); }, array( 'k' => __( 'Date', 'ecomm-user-tracker' ), 'c' => __( 'Orders', 'ecomm-user-tracker' ), 'aov' => __( 'Avg. order value', 'ecomm-user-tracker' ) ) ),
				'sales-coupons'   => $r( __( 'Coupons & Discounts', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->coupons(); }, array( 'k' => __( 'Coupon', 'ecomm-user-tracker' ), 'c' => __( 'Orders', 'ecomm-user-tracker' ), 'disc' => __( 'Discount', 'ecomm-user-tracker' ), 'rev' => __( 'Sales', 'ecomm-user-tracker' ) ) ),
				'sales-refunds'   => $r( __( 'Refunds', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->refunds(); }, array( 'k' => __( 'Order', 'ecomm-user-tracker' ), 'date' => __( 'Date', 'ecomm-user-tracker' ), 'reason' => __( 'Reason', 'ecomm-user-tracker' ), 'rev' => __( 'Amount', 'ecomm-user-tracker' ) ) ),
				'sales-subs'      => $r( __( 'Subscriptions', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->subscriptions(); }, $cnt ),
			),
			__( 'Customers', 'ecomm-user-tracker' )  => array(
				'cu-time'   => $r( __( 'New Customers over Time', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->customers()['daily']; }, array( 'k' => __( 'Date', 'ecomm-user-tracker' ), 'c' => __( 'New customers', 'ecomm-user-tracker' ) ) ),
				'cu-newret' => $r( __( 'New vs. Returning Customers', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->customers()['split']; }, $cnt ),
			),
			__( 'Inventory', 'ecomm-user-tracker' )  => array(
				'inv-low'    => $r( __( 'Low Stock', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->inventory( 'low' ); }, $inv ),
				'inv-out'    => $r( __( 'Out of Stock', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->inventory( 'out' ); }, $inv ),
				'inv-slow'   => $r( __( 'Slow-moving Products', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->inventory( 'slow' ); }, $inv ),
				'inv-viewed' => $r( __( 'Out-of-stock Products Viewed', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->out_of_stock_viewed(); }, $cnt ),
			),
			__( 'Accounting', 'ecomm-user-tracker' ) => array(
				'acc-methods'  => $r( __( 'Payments Summary', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->accounting()['methods']; }, $rev ),
				'acc-shipping' => $r( __( 'Sales by Shipping Method', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->accounting()['shipping_methods']; }, $rev ),
				'acc-summary'  => $r( __( 'Store Sales & Tax Summary', 'ecomm-user-tracker' ), 'proplus', array( __CLASS__, 'accounting_rows' ), array( 'k' => __( 'Item', 'ecomm-user-tracker' ), 'rev' => __( 'Amount', 'ecomm-user-tracker' ) ) ),
			),
			__( 'Traffic', 'ecomm-user-tracker' )    => array(
				'tr-sources'   => $r( __( 'Top Traffic Sources', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->sources( 50 ); }, $cnt ),
				'tr-countries' => $r( __( 'Traffic by Location', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->by( 'country', 100 ); }, $cnt ),
				'tr-entry'     => $r( __( 'Traffic by Entry Page', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->by( 'entry_page', 100 ); }, $cnt ),
				'tr-device'    => $r( __( 'Traffic by Device', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->by( 'device', 10 ); }, $cnt ),
				'tr-newret'    => $r( __( 'New vs. Returning Visitors', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->new_returning(); }, $cnt ),
				'tr-browsers'  => $r( __( 'Traffic by Browser', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->conversion_by( 'browser' ); }, $conv ),
				'tr-os'        => $r( __( 'Traffic by Operating System', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->conversion_by( 'os' ); }, $conv ),
			),
			__( 'Stores', 'ecomm-user-tracker' )     => array(
				'st-funnel'    => $r( __( 'Sales Funnel', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->funnel(); }, $cnt ),
				'st-abandoned' => $r( __( 'Most Abandoned Products', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->abandoned( 1 )['products']; }, $cnt ),
				'st-views'     => $r( __( 'Product Views', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->events_by( 'product_view', 100 ); }, $cnt ),
				'st-cart'      => $r( __( 'Products Added to Cart', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->events_by( 'add_to_cart', 100 ); }, $cnt ),
				'st-products'  => $r( __( 'Product Analytics', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->product_analytics(); }, array( 'k' => __( 'Product', 'ecomm-user-tracker' ), 'views' => __( 'Views', 'ecomm-user-tracker' ), 'cart' => __( 'Added to cart', 'ecomm-user-tracker' ), 'c' => __( 'Bought', 'ecomm-user-tracker' ), 'vc' => __( 'View → cart', 'ecomm-user-tracker' ), 'cb' => __( 'Cart → buy', 'ecomm-user-tracker' ) ) ),
			),
			__( 'Behavior', 'ecomm-user-tracker' )   => array(
				'bh-pages'  => $r( __( 'Page Visits', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->top_pages( 200 ); }, $cnt ),
				'bh-exit'   => $r( __( 'Exit Pages', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->exit_pages( 100 ); }, $cnt + array( 'rate' => __( 'Exit rate %', 'ecomm-user-tracker' ) ) ),
				'bh-clicks' => $r( __( 'Button Clicks', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->events_by( 'click', 200 ); }, $cnt ),
				'bh-clicks-page' => $r( __( 'Button Clicks by Page', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->clicks_by_page( 300 ); }, array( 'k' => __( 'Button / link', 'ecomm-user-tracker' ), 'page' => __( 'Page', 'ecomm-user-tracker' ), 'c' => __( 'Clicks', 'ecomm-user-tracker' ) ) ),
				'bh-time'        => $r( __( 'Avg. Time on Page', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return array_map( function ( $r ) { return array( 'k' => $r['k'], 'views' => $r['views'], 't' => self::duration( $r['c'] ) ); }, $x->time_on_page( 200 ) ); }, array( 'k' => __( 'Page', 'ecomm-user-tracker' ), 'views' => __( 'Views', 'ecomm-user-tracker' ), 't' => __( 'Avg. time', 'ecomm-user-tracker' ) ) ),
				'bh-forms'  => $r( __( 'Submissions by Form', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return array_map( function ( $r ) { return array( 'k' => $r['label'], 'v' => $r['v'], 's' => $r['s'], 'c' => $r['x'] ); }, $x->forms()['forms'] ); }, array( 'k' => __( 'Form', 'ecomm-user-tracker' ), 'v' => __( 'Views', 'ecomm-user-tracker' ), 's' => __( 'Started', 'ecomm-user-tracker' ), 'c' => __( 'Submitted', 'ecomm-user-tracker' ) ) ),
				'bh-search'   => $r( __( 'Top Site Searches', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->searches( false, 200 ); }, array( 'k' => __( 'Search term', 'ecomm-user-tracker' ), 'c' => __( 'Searches', 'ecomm-user-tracker' ), 'res' => __( 'Results', 'ecomm-user-tracker' ) ) ),
				'bh-noresult' => $r( __( 'Searches with No Results', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->searches( true, 200 ); }, $cnt ),
				'bh-contact'  => $r( __( 'Clicks to Contact', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->events_by( 'contact', 100 ); }, $cnt ),
				'bh-404'      => $r( __( '404 Errors', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->errors_404( 200 ); }, array( 'k' => __( 'Missing page', 'ecomm-user-tracker' ), 'c' => __( 'Hits', 'ecomm-user-tracker' ) ) ),
			),
			__( 'Blog', 'ecomm-user-tracker' )       => array(
				'blog-top'   => $r( __( 'Top Blog Posts', 'ecomm-user-tracker' ), 'pro', function ( $x ) { return $x->blog_posts( false, 100 ); }, $post ),
				'blog-sales' => $r( __( 'Posts that Lead to Sales', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->blog_posts( true, 100 ); }, $post ),
			),
			__( 'Marketing', 'ecomm-user-tracker' )  => array(
				'mk-channels' => $r( __( 'Traffic Categories', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->channels(); }, $conv ),
				'mk-ai'       => $r( __( 'AI Platforms Traffic', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->channel_detail( 'ai' )['rows']; }, $conv ),
				'mk-email'    => $r( __( 'Email Performance', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->channel_detail( 'email', 'campaign' )['rows']; }, $conv ),
			),
			__( 'SEO', 'ecomm-user-tracker' )        => array(
				'seo-bots'      => $r( __( 'Bot Traffic', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->bots( false ); }, $cnt ),
				'seo-bot-pages' => $r( __( 'AI Bot Visits by Page', 'ecomm-user-tracker' ), 'proplus', function ( $x ) { return $x->bot_pages( 100 ); }, $cnt ),
			),
		);
	}

	public static function accounting_rows( $x ) {
		$a = $x->accounting();
		return array(
			array( 'k' => __( 'Gross sales', 'ecomm-user-tracker' ), 'rev' => $a['gross'] ),
			array( 'k' => __( 'Discounts', 'ecomm-user-tracker' ), 'rev' => $a['discount'] ),
			array( 'k' => __( 'Refunds', 'ecomm-user-tracker' ), 'rev' => $a['refunds'] ),
			array( 'k' => __( 'Tax', 'ecomm-user-tracker' ), 'rev' => $a['tax'] ),
			array( 'k' => __( 'Shipping', 'ecomm-user-tracker' ), 'rev' => $a['shipping'] ),
			array( 'k' => __( 'Fees', 'ecomm-user-tracker' ), 'rev' => $a['fees'] ),
			array( 'k' => __( 'Net sales', 'ecomm-user-tracker' ), 'rev' => $a['net'] ),
		);
	}

	private static function find_report( $id ) {
		foreach ( self::report_defs() as $cat => $list ) {
			if ( isset( $list[ $id ] ) ) {
				return $list[ $id ];
			}
		}
		return null;
	}

	private static function report_rows( $def ) {
		$rows = self::cached( 'rep|' . $def[0] . '|' . implode( ',', array_keys( $def[3] ) ), function () use ( $def ) { return call_user_func( $def[2], self::rep() ); } );
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$line = array();
			foreach ( array_keys( $def[3] ) as $k ) {
				$v = isset( $r[ $k ] ) ? $r[ $k ] : '';
				if ( in_array( $k, array( 'rev', 'disc', 'aov' ), true ) ) {
					$v = self::money( (float) $v );
				} elseif ( is_numeric( $v ) && 'k' !== $k ) {
					$v = number_format_i18n( (float) $v, floor( (float) $v ) == $v ? 0 : 1 ); // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual
				}
				$line[ $k ] = (string) $v;
			}
			$out[] = $line;
		}
		return $out;
	}

	private static function page_reports() {
		$id = isset( $_GET['report'] ) ? sanitize_key( $_GET['report'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$def = $id ? self::find_report( $id ) : null;
		if ( $def ) {
			echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-reports' ) ) . '">← ' . esc_html__( 'All Reports', 'ecomm-user-tracker' ) . '</a></p>';
			if ( ! ECT_License::has( $def[1] ) ) {
				self::grid_open( 1 );
				self::locked( $def[0], $def[1], 'bars' );
				self::grid_close();
				return;
			}
			self::range_picker( self::SLUG . '-reports&report=' . $id );
			$rows = self::report_rows( $def );
			$csv  = wp_nonce_url( add_query_arg( array_merge( array( 'action' => 'ect_csv', 'report' => $id ), self::range_args() ), admin_url( 'admin-post.php' ) ), 'ect_csv' );
			$b     = ECT_Notify::brand();
			$range = self::rep();
			echo '<div class="ect-print-head" style="border-color:' . esc_attr( $b['color'] ) . '">' . ( $b['logo'] ? '<img src="' . esc_url( $b['logo'] ) . '" alt="">' : '' ) . '<div><strong>' . esc_html( $b['name'] ) . '</strong><span>' . esc_html( get_bloginfo( 'name' ) . ' · ' . $def[0] . ' · ' . wp_date( get_option( 'date_format' ), $range->from ) . ' – ' . wp_date( get_option( 'date_format' ), $range->to ) ) . '</span></div></div>';
			$print = ECT_License::has( 'agency' ) ? ' <button type="button" class="button" onclick="window.print()">' . esc_html__( 'Print / PDF', 'ecomm-user-tracker' ) . '</button>' : '';
			echo '<div class="ect-card"><div class="ect-card-head"><h3>' . esc_html( $def[0] ) . '</h3><span class="ect-noprint"><a class="button" href="' . esc_url( $csv ) . '">' . esc_html__( 'Export CSV', 'ecomm-user-tracker' ) . '</a>' . $print . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo self::table( $def[3], array_map( function ( $r ) { return array_map( 'esc_html', $r ); }, $rows ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';
			return;
		}
		self::grid_open( 2 );
		foreach ( self::report_defs() as $cat => $list ) {
			echo '<div class="ect-card"><h3>' . esc_html( $cat ) . '</h3><ul class="ect-report-list">';
			foreach ( $list as $rid => $d ) {
				$lock = ECT_License::has( $d[1] ) ? '' : ' <span class="ect-badge">' . esc_html( ECT_License::label( $d[1] ) ) . '</span>';
				echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-reports&report=' . $rid ) ) . '">' . esc_html( $d[0] ) . '</a>' . $lock . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</ul></div>';
		}
		self::grid_close();
	}

	public static function export_csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_csv' );
		$id  = isset( $_GET['report'] ) ? sanitize_key( $_GET['report'] ) : '';
		$def = self::find_report( $id );
		if ( ! $def || ! ECT_License::has( $def[1] ) ) {
			wp_die( esc_html__( 'Report not available.', 'ecomm-user-tracker' ) );
		}
		$rows = self::report_rows( $def );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $id . '-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array_values( $def[3] ) );
		foreach ( $rows as $r ) {
			// Neutralise spreadsheet formulas.
			fputcsv( $out, array_map( function ( $v ) { return preg_match( '/^[=+\-@]/', $v ) ? "'" . $v : $v; }, array_values( $r ) ) );
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}

	private static function recordings_banner() {
		echo '<div class="ect-banner"><span>🎥 ' . esc_html__( 'Start recording site sessions to improve your visitor experience.', 'ecomm-user-tracker' ) . '</span>';
		$url = ECT_License::has( 'proplus' ) ? admin_url( 'admin.php?page=' . self::SLUG . '-recordings' ) : ECT_UPGRADE_URL . '&utm_content=session-recordings';
		echo '<a class="button"' . ( ECT_License::has( 'proplus' ) ? '' : ' target="_blank"' ) . ' href="' . esc_url( $url ) . '">' . esc_html( ECT_License::has( 'proplus' ) ? __( 'Watch Session Recordings', 'ecomm-user-tracker' ) : __( 'Start Session Recordings', 'ecomm-user-tracker' ) ) . '</a></div>';
	}

	/* ------------------------------------------------------------------ */
	/* Settings                                                            */
	/* ------------------------------------------------------------------ */

	public static function register_settings() {
		register_setting(
			'ect_settings',
			'ect_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
			)
		);
	}

	public static function sanitize( $in ) {
		// Internal updates (Add Stats, migrations…) are already clean; only the Settings form is sanitised here.
		if ( ! is_array( $in ) || empty( $in['_form'] ) ) {
			return is_array( $in ) ? $in : array();
		}
		// Keep settings that live outside this form.
		$out = array_diff_key( (array) get_option( 'ect_settings', array() ), array_flip( array( 'tracking', 'exclude_admins', 'respect_dnt', 'delete_data', 'auto_update', 'email_utm', 'clarity_id', 'hide_names', 'form_types' ) ) );
		foreach ( array( 'tracking', 'exclude_admins', 'respect_dnt', 'delete_data', 'auto_update', 'email_utm' ) as $k ) {
			$out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
		}
		$clarity           = isset( $in['clarity_id'] ) ? strtolower( trim( sanitize_text_field( $in['clarity_id'] ) ) ) : '';
		$out['clarity_id'] = preg_match( '/^[a-z0-9]{6,20}$/', $clarity ) ? $clarity : '';
		if ( '' !== $clarity && '' === $out['clarity_id'] ) {
			add_settings_error( 'ect_settings', 'ect_clarity', __( 'That does not look like a Microsoft Clarity Project ID.', 'ecomm-user-tracker' ) );
		}
		// Customer names are shown only after the admin confirms their privacy policy covers it.
		$out['hide_names'] = 1;
		if ( empty( $in['hide_names'] ) ) {
			if ( ! empty( $in['privacy_ok'] ) || ! ect_get_option( 'hide_names' ) ) {
				$out['hide_names'] = 0;
				if ( ect_get_option( 'hide_names' ) ) {
					$out['privacy_ok_by'] = get_current_user_id();
					$out['privacy_ok_at'] = time();
				}
			} else {
				add_settings_error( 'ect_settings', 'ect_privacy', __( 'To show customer names, please confirm that you added the text to your Privacy Policy.', 'ecomm-user-tracker' ) );
			}
		}
		$allowed           = array( 'contact', 'checkout', 'account', 'newsletter', 'other' );
		$out['form_types'] = isset( $in['form_types'] ) && is_array( $in['form_types'] ) ? array_values( array_intersect( $allowed, array_map( 'sanitize_key', $in['form_types'] ) ) ) : array();
		$old = (array) get_option( 'ect_settings', array() );
		if ( ! ECT_License::has( 'proplus' ) ) {
			$out['form_types'] = isset( $old['form_types'] ) ? $old['form_types'] : array( 'contact', 'checkout', 'account', 'newsletter' );
			// Fields not shown on lower plans keep their saved value.
			$out['email_utm']  = isset( $old['email_utm'] ) ? (int) $old['email_utm'] : 1;
			$out['clarity_id'] = isset( $old['clarity_id'] ) ? $old['clarity_id'] : '';
		}
		foreach ( array( 'privacy_ok_by', 'privacy_ok_at' ) as $k ) {
			if ( ! isset( $out[ $k ] ) && isset( $old[ $k ] ) ) {
				$out[ $k ] = $old[ $k ];
			}
		}
		return $out;
	}

	private static function page_settings() {
		if ( isset( $_GET['ect_geo'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$ok = 'ok' === $_GET['ect_geo']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-' . ( $ok ? 'success' : 'error' ) . '"><p>' . esc_html( $ok ? __( 'Country database updated.', 'ecomm-user-tracker' ) : __( 'Country database download failed. Your host may block outgoing downloads.', 'ecomm-user-tracker' ) ) . '</p></div>';
		}
		$fields = array(
			'tracking'       => __( 'Enable visitor tracking', 'ecomm-user-tracker' ),
			'exclude_admins' => __( 'Do not track logged-in admins, editors and shop managers', 'ecomm-user-tracker' ),
			'respect_dnt'    => __( 'Respect browser "Do Not Track"', 'ecomm-user-tracker' ),
			'auto_update'    => __( 'Automatically install plugin updates', 'ecomm-user-tracker' ),
			'delete_data'    => __( 'Delete all plugin data when the plugin is deleted', 'ecomm-user-tracker' ),
		);
		echo '<div class="ect-card ect-settings"><form method="post" action="options.php">';
		settings_fields( 'ect_settings' );
		echo '<input type="hidden" name="ect_settings[_form]" value="1">';
		foreach ( $fields as $k => $label ) {
			echo '<p><label><input type="checkbox" name="ect_settings[' . esc_attr( $k ) . ']" value="1" ' . checked( (int) ect_get_option( $k ), 1, false ) . '> ' . esc_html( $label ) . '</label></p>';
		}
		if ( ECT_License::has( 'proplus' ) ) {
			echo '<p><label><input type="checkbox" name="ect_settings[email_utm]" value="1" ' . checked( (int) ect_get_option( 'email_utm' ), 1, false ) . '> ' . esc_html__( 'Track clicks and sales from emails sent by this site', 'ecomm-user-tracker' ) . '</label></p>';
			$ft    = ECT_Reports::form_types();
			$types = array(
				'contact'    => __( 'Contact forms (any form with a message box)', 'ecomm-user-tracker' ),
				'checkout'   => __( 'Checkout / place order (name, address, phone…)', 'ecomm-user-tracker' ),
				'account'    => __( 'Account forms (create account, login)', 'ecomm-user-tracker' ),
				'newsletter' => __( 'Newsletter / email signup', 'ecomm-user-tracker' ),
				'other'      => __( 'All other forms', 'ecomm-user-tracker' ),
			);
			echo '<fieldset class="ect-fieldset"><legend>' . esc_html__( 'Forms to track', 'ecomm-user-tracker' ) . '</legend><p class="ect-muted">' . esc_html__( 'Works with custom forms and form plugins. Product options, cart, search and coupon forms are never tracked.', 'ecomm-user-tracker' ) . '</p>';
			foreach ( $types as $k => $label ) {
				echo '<label class="ect-block"><input type="checkbox" name="ect_settings[form_types][]" value="' . esc_attr( $k ) . '" ' . checked( in_array( $k, $ft, true ), true, false ) . '> ' . esc_html( $label ) . '</label>';
			}
			echo '</fieldset>';
			echo '<p id="ect-clarity"><label>' . esc_html__( 'Microsoft Clarity Project ID (session recordings)', 'ecomm-user-tracker' ) . '<br><input type="text" class="regular-text" name="ect_settings[clarity_id]" value="' . esc_attr( ect_get_option( 'clarity_id', '' ) ) . '" placeholder="abcd1234ef"></label></p>';
		}
		if ( ECT_License::has( 'pro' ) ) {
			$hide = (int) ect_get_option( 'hide_names' );
			echo '<p><label><input type="checkbox" id="ect-hide-names" name="ect_settings[hide_names]" value="1" ' . checked( $hide, 1, false ) . '> ' . esc_html__( 'Hide customer names in reports', 'ecomm-user-tracker' ) . '</label></p>';
			echo '<div id="ect-privacy" class="ect-privacy"' . ( $hide ? ' hidden' : '' ) . '><p>' . esc_html__( 'To show customer names, add this to your Privacy Policy:', 'ecomm-user-tracker' ) . '</p>';
			echo '<textarea readonly rows="3" onclick="this.select()">' . esc_textarea( __( 'We use Ecomm User Tracker to understand how visitors use our store. When you place an order or log in, your name may be linked to the pages you visited on our site. This data stays on our website and is deleted automatically after the retention period.', 'ecomm-user-tracker' ) ) . '</textarea>';
			echo '<p><label><input type="checkbox" name="ect_settings[privacy_ok]" value="1" ' . checked( ! $hide, true, false ) . '> ' . esc_html__( 'I have added this text to my Privacy Policy.', 'ecomm-user-tracker' ) . '</label></p></div>';
			echo "<script>document.getElementById('ect-hide-names').addEventListener('change',function(){document.getElementById('ect-privacy').hidden=this.checked;});</script>";
		}
		submit_button();
		echo '</form></div>';

		self::license_card();
		ECT_Notify::settings_card();
		self::orders_check_card();

		echo '<div class="ect-card ect-settings"><h3>' . esc_html__( 'Country database', 'ecomm-user-tracker' ) . '</h3>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ect_geo_update' );
		echo '<input type="hidden" name="action" value="ect_geo_update">';
		submit_button( __( 'Update now', 'ecomm-user-tracker' ), 'secondary', 'submit', false );
		echo '</form></div>';
		echo '<p class="ect-footer">' . esc_html__( 'IP geolocation by DB-IP', 'ecomm-user-tracker' ) . '</p>';
	}

	/** Shows how the latest WooCommerce orders are counted, so numbers can be checked against WooCommerce. */
	private static function orders_check_card() {
		if ( ! ECT_License::has( 'pro' ) || ! ECT_Woo::active() ) {
			return;
		}
		$orders = wc_get_orders(
			array(
				'status' => ECT_Woo::all_statuses(),
				'limit'  => 10,
				'type'   => 'shop_order',
				'orderby' => 'date',
				'order'  => 'DESC',
			)
		);
		$rows  = array();
		$cache = array();
		foreach ( $orders as $o ) {
			$rows[] = array(
				'id' => '#' . esc_html( $o->get_order_number() ),
				'd'  => esc_html( $o->get_date_created() ? $o->get_date_created()->date_i18n( get_option( 'date_format' ) ) : '' ),
				's'  => esc_html( wc_get_order_status_name( $o->get_status() ) ),
				't'  => wp_kses_post( wc_price( $o->get_total() ) ),
				'c'  => ECT_Woo::is_paid( $o ) ? '✅' : '—',
				'src' => esc_html( ECT_Woo::order_source( $o, $cache ) ),
			);
		}
		echo '<div class="ect-card ect-settings"><h3>' . esc_html__( 'Order check', 'ecomm-user-tracker' ) . '</h3><p class="ect-muted">' . esc_html__( 'Your latest WooCommerce orders and how they are counted in sales.', 'ecomm-user-tracker' ) . '</p>';
		echo self::table( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			array(
				'id'  => __( 'Order', 'ecomm-user-tracker' ),
				'd'   => __( 'Date', 'ecomm-user-tracker' ),
				's'   => __( 'Status', 'ecomm-user-tracker' ),
				't'   => __( 'Total', 'ecomm-user-tracker' ),
				'c'   => __( 'Counted', 'ecomm-user-tracker' ),
				'src' => __( 'Source', 'ecomm-user-tracker' ),
			),
			$rows,
			__( 'No orders yet.', 'ecomm-user-tracker' )
		);
		echo '</div>';
	}

	private static function license_card() {
		if ( isset( $_GET['ect_lic'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$msg = get_transient( 'ect_license_msg' );
			delete_transient( 'ect_license_msg' );
			if ( $msg ) {
				echo '<div class="notice notice-' . esc_attr( $msg[0] ) . '"><p>' . esc_html( $msg[1] ) . '</p></div>';
			}
		}
		echo '<div class="ect-card ect-settings"><h3>' . esc_html__( 'License', 'ecomm-user-tracker' ) . '</h3>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ect_license' );
		echo '<input type="hidden" name="action" value="ect_license">';
		$key = ECT_License::key();
		if ( ECT_License::complimentary() ) {
			/* translators: %s: plan name */
			echo '<p>' . esc_html( sprintf( __( 'Active plan: %s — free forever for this site.', 'ecomm-user-tracker' ), ECT_License::label() ) ) . '</p>';
		} elseif ( $key ) {
			/* translators: %s: plan name */
			echo '<p>' . esc_html( sprintf( __( 'Active plan: %s', 'ecomm-user-tracker' ), ECT_License::label() ) ) . ' · <code>' . esc_html( substr( $key, 0, 4 ) . '••••' . substr( $key, -4 ) ) . '</code></p>';
			echo '<input type="hidden" name="do" value="deactivate">';
			submit_button( __( 'Deactivate license', 'ecomm-user-tracker' ), 'secondary', 'submit', false );
		} else {
			echo '<p><input type="text" name="key" class="regular-text" placeholder="XXXX-XXXX-XXXX-XXXX" autocomplete="off"> ';
			echo '<input type="hidden" name="do" value="activate">';
			submit_button( __( 'Activate', 'ecomm-user-tracker' ), 'primary', 'submit', false );
			echo '</p><p class="ect-muted"><a href="' . esc_url( ECT_UPGRADE_URL ) . '" target="_blank">' . esc_html__( 'Get a license key', 'ecomm-user-tracker' ) . '</a></p>';
		}
		echo '</form></div>';
	}

	public static function handle_license() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_license' );
		$do = isset( $_POST['do'] ) ? sanitize_key( $_POST['do'] ) : '';
		if ( 'deactivate' === $do ) {
			ECT_License::deactivate();
			$msg = array( 'success', __( 'License deactivated.', 'ecomm-user-tracker' ) );
		} else {
			$res = ECT_License::activate( isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '' );
			/* translators: %s: plan name */
			$msg = is_wp_error( $res ) ? array( 'error', $res->get_error_message() ) : array( 'success', sprintf( __( 'License activated: %s plan.', 'ecomm-user-tracker' ), ECT_License::label() ) );
		}
		set_transient( 'ect_license_msg', $msg, 60 );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '-settings&ect_lic=1' ) );
		exit;
	}

	public static function handle_geo_update() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_geo_update' );
		$res = ECT_Geo::update_db();
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '-settings&ect_geo=' . ( true === $res ? 'ok' : 'fail' ) ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Dashboard widget                                                    */
	/* ------------------------------------------------------------------ */

	public static function dashboard_widget() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		wp_add_dashboard_widget(
			'ect_live_widget',
			__( 'Ecomm User Tracker — Live', 'ecomm-user-tracker' ),
			function () {
				self::live_card( true );
				echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-realtime' ) ) . '">' . esc_html__( 'View Real-time Analytics', 'ecomm-user-tracker' ) . ' →</a></p>';
			}
		);
	}

	/* ------------------------------------------------------------------ */
	/* Deactivation feedback (optional)                                    */
	/* ------------------------------------------------------------------ */

	private static function feedback_reasons() {
		return array(
			'not_working'   => __( "It didn't work on my site", 'ecomm-user-tracker' ),
			'missing'       => __( "It's missing a feature I need", 'ecomm-user-tracker' ),
			'better'        => __( 'I found a better plugin', 'ecomm-user-tracker' ),
			'slow'          => __( 'It slowed down my site', 'ecomm-user-tracker' ),
			'temporary'     => __( "It's a temporary deactivation", 'ecomm-user-tracker' ),
			'other'         => __( 'Other', 'ecomm-user-tracker' ),
		);
	}

	public static function deactivate_modal() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		?>
		<div id="ect-deactivate" class="ect-modal" hidden>
			<div class="ect-modal-box" role="dialog" aria-modal="true" aria-labelledby="ect-deactivate-title">
				<h2 id="ect-deactivate-title"><?php esc_html_e( 'Quick feedback', 'ecomm-user-tracker' ); ?></h2>
				<p><?php esc_html_e( 'If you have a moment, please tell us why you are deactivating Ecomm User Tracker (optional):', 'ecomm-user-tracker' ); ?></p>
				<?php foreach ( self::feedback_reasons() as $key => $label ) : ?>
					<p><label><input type="radio" name="ect_reason" value="<?php echo esc_attr( $key ); ?>"> <?php echo esc_html( $label ); ?></label></p>
				<?php endforeach; ?>
				<textarea id="ect-reason-details" rows="3" placeholder="<?php esc_attr_e( 'Anything else? (optional)', 'ecomm-user-tracker' ); ?>"></textarea>
				<div class="ect-modal-actions">
					<button type="button" class="button-link" data-ect-skip><?php esc_html_e( 'Skip & Deactivate', 'ecomm-user-tracker' ); ?></button>
					<button type="button" class="button button-primary" data-ect-submit><?php esc_html_e( 'Submit & Deactivate', 'ecomm-user-tracker' ); ?></button>
				</div>
			</div>
		</div>
		<style>
			.ect-modal{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:100000;display:flex;align-items:center;justify-content:center}
			.ect-modal[hidden]{display:none}
			.ect-modal-box{background:#fff;border-radius:10px;padding:20px 24px;max-width:480px;width:calc(100% - 32px);box-shadow:0 10px 40px rgba(0,0,0,.25)}
			.ect-modal-box h2{margin-top:0}
			.ect-modal-box p{margin:6px 0}
			.ect-modal-box textarea{width:100%;margin-top:8px}
			.ect-modal-actions{display:flex;justify-content:space-between;align-items:center;margin-top:16px}
		</style>
		<script>
		(function () {
			var link = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( ECT_FILE ) ); ?>"] .deactivate a');
			var modal = document.getElementById('ect-deactivate');
			if (!link || !modal) return;
			var href = link.href;
			link.addEventListener('click', function (e) { e.preventDefault(); modal.hidden = false; });
			modal.addEventListener('click', function (e) { if (e.target === modal) modal.hidden = true; });
			document.addEventListener('keydown', function (e) { if (e.key === 'Escape') modal.hidden = true; });
			modal.querySelector('[data-ect-skip]').addEventListener('click', function () { location.href = href; });
			modal.querySelector('[data-ect-submit]').addEventListener('click', function () {
				var r = modal.querySelector('input[name="ect_reason"]:checked');
				var d = document.getElementById('ect-reason-details').value;
				if (!r && !d) { location.href = href; return; }
				var body = new URLSearchParams({
					action: 'ect_deactivate_feedback',
					_wpnonce: '<?php echo esc_js( wp_create_nonce( 'ect_feedback' ) ); ?>',
					reason: r ? r.value : '',
					details: d
				});
				this.disabled = true;
				fetch(ajaxurl, { method: 'POST', body: body, credentials: 'same-origin' })
					.finally(function () { location.href = href; });
				setTimeout(function () { location.href = href; }, 3000);
			});
		})();
		</script>
		<?php
	}

	public static function deactivate_feedback() {
		check_ajax_referer( 'ect_feedback' );
		if ( ! current_user_can( 'activate_plugins' ) ) {
			wp_send_json_error( null, 403 );
		}
		$reasons = self::feedback_reasons();
		$reason  = isset( $_POST['reason'] ) ? sanitize_key( wp_unslash( $_POST['reason'] ) ) : '';
		$details = isset( $_POST['details'] ) ? sanitize_textarea_field( wp_unslash( $_POST['details'] ) ) : '';
		if ( ECT_FEEDBACK_URL && ( isset( $reasons[ $reason ] ) || '' !== $details ) ) {
			wp_remote_post(
				ECT_FEEDBACK_URL,
				array(
					'timeout'  => 5,
					'blocking' => false,
					'headers'  => array( 'Content-Type' => 'application/json' ),
					'body'     => wp_json_encode(
						array(
							'plugin'      => 'ecomm-user-tracker',
							'version'     => ECT_VERSION,
							'reason'      => $reason,
							'details'     => substr( $details, 0, 1000 ),
							'wp_version'  => get_bloginfo( 'version' ),
							'php_version' => PHP_VERSION,
							'locale'      => get_locale(),
						)
					),
				)
			);
		}
		wp_send_json_success();
	}
}
