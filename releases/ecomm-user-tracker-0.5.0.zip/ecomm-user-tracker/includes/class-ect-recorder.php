<?php
/**
 * Session recordings V2 (rrweb), stored on the site's own hosting.
 *
 * Pro+: recordings are deleted after 48 hours.
 * Agency: keep 2 / 7 / 15 / 30 days, auto-delete can be switched off.
 * All plans: max 1 GB of new recordings per month; recording pauses when the limit is reached.
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Recorder {

	const MONTHLY_CAP  = 1073741824; // 1 GB.
	const MAX_CHUNK    = 4194304;    // 4 MB per request.
	const MAX_SESSION  = 52428800;   // 50 MB per recording.
	const DAYS_CHOICES = array( 2, 7, 15, 30 );

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'ect_cleanup', array( __CLASS__, 'cleanup' ) );
		add_action( 'admin_post_ect_rec', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_ect_rec_get', array( __CLASS__, 'download' ) );
		add_action( 'admin_post_ect_rec_delete', array( __CLASS__, 'delete' ) );
	}

	public static function opts() {
		$o = wp_parse_args( (array) get_option( 'ect_rec', array() ), array( 'enabled' => 1, 'days' => 7, 'autodelete' => 1 ) );
		if ( ! ECT_License::has( 'agency' ) ) {
			$o['days']       = 2;
			$o['autodelete'] = 1;
		}
		$o['days'] = in_array( (int) $o['days'], self::DAYS_CHOICES, true ) ? (int) $o['days'] : 7;
		return $o;
	}

	public static function dir() {
		$u = wp_upload_dir( null, false );
		return trailingslashit( $u['basedir'] ) . 'ect-recordings/';
	}

	private static function ensure_dir() {
		$d = self::dir();
		if ( ! is_dir( $d ) ) {
			wp_mkdir_p( $d );
		}
		if ( ! file_exists( $d . 'index.php' ) ) {
			file_put_contents( $d . 'index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			file_put_contents( $d . '.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
		return $d;
	}

	public static function usage() {
		$u = (array) get_option( 'ect_rec_usage', array() );
		if ( ! isset( $u['m'] ) || gmdate( 'Y-m' ) !== $u['m'] ) {
			$u = array( 'm' => gmdate( 'Y-m' ), 'b' => 0 );
		}
		return $u;
	}

	public static function active() {
		return ECT_License::has( 'proplus' ) && self::opts()['enabled'] && self::usage()['b'] < self::MONTHLY_CAP;
	}

	/** Shown when the admin keeps recordings for 30 days with auto-delete off. */
	public static function space_warning() {
		$o = self::opts();
		return ECT_License::has( 'agency' ) && 30 === $o['days'] && ! $o['autodelete'];
	}

	/** Front-end: rrweb recorder after the tracker. */
	public static function enqueue() {
		if ( ! self::active() ) {
			return;
		}
		wp_enqueue_script( 'ect-rrweb', ECT_URL . 'assets/vendor/rrweb/rrweb-record.min.js', array(), ECT_VERSION, true );
		wp_enqueue_script( 'ect-rec', ECT_URL . 'assets/js/ect-rec.js', array( 'ect-tracker', 'ect-rrweb' ), ECT_VERSION, true );
	}

	public static function cfg() {
		return self::active() ? array( 'url' => esc_url_raw( rest_url( 'ect/v1/rec' ) ) ) : false;
	}

	public static function routes() {
		register_rest_route(
			'ect/v1',
			'/rec',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'receive' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public static function receive( WP_REST_Request $req ) {
		$raw = (string) $req->get_body();
		if ( ! self::active() || strlen( $raw ) > self::MAX_CHUNK ) {
			return new WP_REST_Response( null, 204 );
		}
		$data = json_decode( $raw, true );
		$sid  = isset( $data['s'] ) ? (string) $data['s'] : '';
		if ( ! preg_match( '/^[a-zA-Z0-9]{16,40}$/', $sid ) || empty( $data['ev'] ) || ! is_array( $data['ev'] ) ) {
			return new WP_REST_Response( null, 204 );
		}
		global $wpdb;
		$skey = ECT_Tracker::session_key( $sid );
		$s    = ECT_DB::sessions();
		$ok   = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$s} WHERE skey = %s AND started > %d", $skey, time() - 6 * HOUR_IN_SECONDS ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $ok ) {
			return new WP_REST_Response( null, 204 );
		}
		$file = self::ensure_dir() . $skey . '.ndjson';
		if ( file_exists( $file ) && filesize( $file ) > self::MAX_SESSION ) {
			return new WP_REST_Response( null, 204 );
		}
		$line = wp_json_encode( array_values( $data['ev'] ) ) . "\n";
		file_put_contents( $file, $line, FILE_APPEND | LOCK_EX ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		$u      = self::usage();
		$u['b'] += strlen( $line );
		update_option( 'ect_rec_usage', $u, false );
		return new WP_REST_Response( null, 204 );
	}

	public static function cleanup() {
		$d = self::dir();
		if ( ! is_dir( $d ) ) {
			return;
		}
		$o = self::opts();
		if ( ! ECT_License::has( 'proplus' ) ) {
			$cut = time(); // Plan ended: remove everything.
		} elseif ( $o['autodelete'] ) {
			$cut = time() - $o['days'] * DAY_IN_SECONDS;
		} else {
			return;
		}
		foreach ( (array) glob( $d . '*.ndjson' ) as $f ) {
			if ( filemtime( $f ) < $cut ) {
				wp_delete_file( $f );
			}
		}
	}

	/** Recordings, newest first, joined with their visit. */
	public static function list_recordings( $limit = 200 ) {
		$d     = self::dir();
		$files = is_dir( $d ) ? (array) glob( $d . '*.ndjson' ) : array();
		usort( $files, function ( $a, $b ) { return filemtime( $b ) <=> filemtime( $a ); } );
		$files = array_slice( $files, 0, $limit );
		if ( ! $files ) {
			return array();
		}
		global $wpdb;
		$keys = array_map( function ( $f ) { return basename( $f, '.ndjson' ); }, $files );
		$s    = ECT_DB::sessions();
		$in   = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT skey, id, visitor, started, last_seen, pageviews, entry_page, country, device, source, stage FROM {$s} WHERE skey IN ($in)", $keys ), OBJECT_K ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$out  = array();
		foreach ( $files as $f ) {
			$k     = basename( $f, '.ndjson' );
			$out[] = array(
				'key'     => $k,
				'size'    => filesize( $f ),
				'time'    => filemtime( $f ),
				'session' => isset( $rows[ $k ] ) ? $rows[ $k ] : null,
			);
		}
		return $out;
	}

	public static function has_recording( $skey ) {
		return preg_match( '/^[a-f0-9]{32}$/', $skey ) && file_exists( self::dir() . $skey . '.ndjson' );
	}

	/** Admin: events of one recording as a JSON array of chunks. */
	public static function download() {
		if ( ! current_user_can( 'manage_options' ) || ! ECT_License::has( 'proplus' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_rec_get' );
		$k = isset( $_GET['k'] ) ? sanitize_key( $_GET['k'] ) : '';
		if ( ! self::has_recording( $k ) ) {
			status_header( 404 );
			exit;
		}
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		$lines = array_filter( array_map( 'trim', (array) file( self::dir() . $k . '.ndjson' ) ) );
		echo '[' . implode( ',', $lines ) . ']'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	public static function delete() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_rec_delete' );
		$k = isset( $_GET['k'] ) ? sanitize_key( $_GET['k'] ) : '';
		if ( 'all' === $k ) {
			foreach ( (array) glob( self::dir() . '*.ndjson' ) as $f ) {
				wp_delete_file( $f );
			}
		} elseif ( self::has_recording( $k ) ) {
			wp_delete_file( self::dir() . $k . '.ndjson' );
		}
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url() );
		exit;
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_rec' );
		$days = isset( $_POST['days'] ) ? (int) $_POST['days'] : 7;
		update_option(
			'ect_rec',
			array(
				'enabled'    => empty( $_POST['enabled'] ) ? 0 : 1,
				'days'       => in_array( $days, self::DAYS_CHOICES, true ) ? $days : 7,
				'autodelete' => empty( $_POST['autodelete'] ) ? 0 : 1,
			),
			false
		);
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url() );
		exit;
	}
}
