/* Ecomm User Tracker — admin live widget. */
(function () {
	var cfg = window.ectAdmin;
	var boxes = document.querySelectorAll('[data-ect-live]');
	if (!cfg) return;

	var names = null;
	try { names = new Intl.DisplayNames([cfg.locale, 'en'], { type: 'region' }); } catch (e) {}

	function flag(code) {
		if (!/^[A-Z]{2}$/.test(code) || code === 'XX') return '🌐';
		return String.fromCodePoint.apply(null, code.split('').map(function (c) { return 127397 + c.charCodeAt(0); }));
	}
	function countryName(code) {
		if (code === 'XX' || !code) return cfg.i18n.unknown;
		try { return names ? names.of(code) : code; } catch (e) { return code; }
	}

	// World map: country shapes coloured by visitor count.
	function drawMap(el, counts) {
		if (!window.ectWorld) return;
		if (!el._ectPaths) {
			var ns = 'http://www.w3.org/2000/svg';
			var svg = document.createElementNS(ns, 'svg');
			svg.setAttribute('viewBox', '0 0 1000 500');
			svg.setAttribute('role', 'img');
			el._ectPaths = {};
			Object.keys(window.ectWorld).forEach(function (cc) {
				var p = document.createElementNS(ns, 'path');
				p.setAttribute('d', window.ectWorld[cc]);
				p.appendChild(document.createElementNS(ns, 'title'));
				svg.appendChild(p);
				el._ectPaths[cc] = p;
			});
			el.appendChild(svg);
		}
		var max = 0;
		Object.keys(counts).forEach(function (cc) { max = Math.max(max, counts[cc]); });
		Object.keys(el._ectPaths).forEach(function (cc) {
			var p = el._ectPaths[cc], n = counts[cc] || 0;
			p.setAttribute('class', n ? 'on' : '');
			p.style.fillOpacity = n ? (0.35 + 0.65 * n / max).toFixed(2) : '';
			p.firstChild.textContent = countryName(cc) + (n ? ': ' + n : '');
		});
	}
	document.querySelectorAll('[data-ect-map]').forEach(function (el) {
		var v = el.getAttribute('data-ect-map');
		if (v !== 'live') { try { drawMap(el, JSON.parse(v)); } catch (e) {} }
	});

	function render(data) {
		document.querySelectorAll('[data-ect-map="live"]').forEach(function (el) {
			var m = {};
			data.countries.forEach(function (c) { m[c.code] = c.count; });
			drawMap(el, m);
		});
		boxes.forEach(function (box) {
			box.querySelector('[data-ect-count]').textContent = data.live;
			var list = box.querySelector('[data-ect-countries]');
			var empty = box.querySelector('[data-ect-empty]');
			if (list) {
				list.innerHTML = '';
				var max = data.countries.length ? data.countries[0].count : 1;
				data.countries.forEach(function (c) {
					var li = document.createElement('li');
					var label = document.createElement('span');
					label.className = 'ect-c-name';
					label.textContent = flag(c.code) + ' ' + countryName(c.code);
					var num = document.createElement('strong');
					num.textContent = c.count;
					var bar = document.createElement('i');
					bar.style.width = Math.max(4, Math.round((c.count / max) * 100)) + '%';
					li.appendChild(label);
					li.appendChild(num);
					li.appendChild(bar);
					list.appendChild(li);
				});
			}
			if (empty) empty.style.display = data.live ? 'none' : '';
			var upd = box.querySelector('[data-ect-updated]');
			if (upd) upd.textContent = cfg.i18n.updated + ' ' + new Date().toLocaleTimeString();
		});
	}

	var secs = document.querySelectorAll('[data-ect-sec]');
	var busy = false;

	function load() {
		if (document.hidden || busy) return;
		busy = true;
		var modal = document.querySelector('.ect-modal:not([hidden]) [data-ect-lazy]');
		var url = cfg.endpoint + (secs.length ? (cfg.endpoint.indexOf('?') === -1 ? '?' : '&') + 'sections=1' + (modal ? '&full=1' : '') : '');
		fetch(url, { headers: { 'X-WP-Nonce': cfg.nonce }, credentials: 'same-origin', cache: 'no-store' })
			.then(function (r) { return r.ok ? r.json() : null; })
			.then(function (d) {
				if (!d) return;
				if (boxes.length) render(d);
				if (d.sections) {
					secs.forEach(function (el) {
						var html = d.sections[el.getAttribute('data-ect-sec')];
						if (typeof html === 'string' && el._ectHtml !== html) { el._ectHtml = html; el.innerHTML = html; countries(el); }
					});
				}
			})
			.catch(function () {})
			.finally(function () { busy = false; });
	}

	// Country codes in server-rendered reports → flag + name.
	function countries(root) {
		root.querySelectorAll('[data-ect-cc]').forEach(function (el) {
			var c = el.getAttribute('data-ect-cc');
			el.textContent = el.hasAttribute('data-ect-flag-only') ? flag(c) : flag(c) + ' ' + countryName(c);
		});
	}
	countries(document);

	// Cards scroll inside (mouse wheel / touch, no visible scrollbar). A soft fade shows there is more.
	function fades() {
		document.querySelectorAll('.ect-scroll').forEach(function (el) {
			var more = el.scrollHeight - el.clientHeight - el.scrollTop > 4;
			el.classList.toggle('has-more', more);
			el.classList.toggle('is-scrolled', el.scrollTop > 4);
		});
	}
	document.addEventListener('scroll', function (e) { if (e.target.classList && e.target.classList.contains('ect-scroll')) fades(); }, true);
	window.addEventListener('resize', fades);
	fades();
	setInterval(fades, 1000);

	// Visitor history popup.
	function openVisitor(id) {
		var m = document.getElementById('ect-visitor-modal');
		if (!m || !cfg.visitor) return;
		var body = m.querySelector('[data-ect-visitor-body]');
		m.querySelector('[data-ect-visitor-title]').textContent = cfg.i18n.visitor + ' #' + id;
		body.innerHTML = '<p class="ect-muted">…</p>';
		m.hidden = false;
		document.body.classList.add('ect-modal-open');
		fetch(cfg.visitor + (cfg.visitor.indexOf('?') === -1 ? '?' : '&') + 'id=' + encodeURIComponent(id), { headers: { 'X-WP-Nonce': cfg.nonce }, credentials: 'same-origin' })
			.then(function (r) { return r.ok ? r.json() : null; })
			.then(function (d) { body.innerHTML = d ? d.html : ''; countries(body); body.scrollTop = 0; });
	}

	// Session recording player (rrweb).
	function openPlayer(key) {
		var m = document.getElementById('ect-player-modal');
		if (!m || !cfg.recording || !window.rrwebPlayer) return;
		var body = m.querySelector('[data-ect-player]');
		body.innerHTML = '<p class="ect-muted">…</p>';
		m.hidden = false;
		document.body.classList.add('ect-modal-open');
		fetch(cfg.recording + '&k=' + encodeURIComponent(key), { credentials: 'same-origin' })
			.then(function (r) { return r.ok ? r.json() : null; })
			.then(function (chunks) {
				var events = [];
				(chunks || []).forEach(function (c) { events = events.concat(c); });
				events.sort(function (a, b) { return a.timestamp - b.timestamp; });
				body.innerHTML = '';
				if (events.length < 2) { body.innerHTML = '<p class="ect-empty">' + cfg.i18n.norec + '</p>'; return; }
				var h = Math.max(240, Math.min(Math.round((body.clientWidth || 1000) * 0.56), window.innerHeight - 220));
				var w = Math.min(body.clientWidth || 1000, Math.round(h / 0.56));
				m._player = new window.rrwebPlayer({ target: body, props: { events: events, width: w, height: h, autoPlay: true, skipInactive: true, showController: true, speedOption: [1, 2, 4, 8] } });
			})
			.catch(function () { body.innerHTML = '<p class="ect-empty">' + cfg.i18n.norec + '</p>'; });
	}
	function closePlayer() {
		var m = document.getElementById('ect-player-modal');
		if (m && m._player) { try { m._player.pause(); } catch (e) {} m._player = null; m.querySelector('[data-ect-player]').innerHTML = ''; }
	}

	// "View more" popups (content keeps updating while open; the popup scrolls, not the page).
	document.addEventListener('click', function (e) {
		var pl = e.target.closest && e.target.closest('[data-ect-play]');
		if (pl) { e.preventDefault(); openPlayer(pl.getAttribute('data-ect-play')); return; }
		var v = e.target.closest && e.target.closest('[data-ect-visitor]');
		if (v) {
			e.preventDefault();
			document.querySelectorAll('.ect-modal').forEach(function (m) { if (m.id !== 'ect-visitor-modal') m.hidden = true; });
			openVisitor(v.getAttribute('data-ect-visitor'));
			return;
		}
		var open = e.target.closest && e.target.closest('[data-ect-open]');
		if (open) {
			var m = document.getElementById(open.getAttribute('data-ect-open'));
			if (m) { m.hidden = false; document.body.classList.add('ect-modal-open'); load(); }
			return;
		}
		var m2 = e.target.closest && e.target.closest('.ect-modal');
		if (m2 && (e.target === m2 || e.target.closest('[data-ect-close]'))) { m2.hidden = true; document.body.classList.remove('ect-modal-open'); if (m2.id === 'ect-player-modal') closePlayer(); }
	});
	document.addEventListener('keydown', function (e) {
		if (e.key !== 'Escape') return;
		document.querySelectorAll('.ect-modal').forEach(function (m) { m.hidden = true; });
		document.body.classList.remove('ect-modal-open');
		closePlayer();
	});

	load();
	// Live views refresh every second (only while the tab is visible).
	if (boxes.length || secs.length) setInterval(load, 1000);
	document.addEventListener('visibilitychange', load);
})();
