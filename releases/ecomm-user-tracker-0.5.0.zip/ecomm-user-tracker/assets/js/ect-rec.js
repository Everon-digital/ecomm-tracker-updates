/* Ecomm User Tracker — session recordings (rrweb). Inputs are always masked. */
(function () {
	var cfg = window.ectCfg;
	if (!cfg || !cfg.rec || !window.rrwebRecord || navigator.webdriver) return;
	var buf = [];
	function sid() { try { return localStorage.getItem('ect_sid'); } catch (e) { return null; } }
	function flush(beacon) {
		var s = sid();
		if (!buf.length || !s) return;
		var body = JSON.stringify({ s: s, ev: buf });
		buf = [];
		if (beacon && navigator.sendBeacon && body.length < 60000 && navigator.sendBeacon(cfg.rec.url, new Blob([body], { type: 'application/json' }))) return;
		try {
			fetch(cfg.rec.url, { method: 'POST', body: body, headers: { 'Content-Type': 'application/json' }, credentials: 'omit', keepalive: body.length < 60000 });
		} catch (e) {}
	}
	window.rrwebRecord({
		emit: function (e) { buf.push(e); if (buf.length >= 400) flush(); },
		maskAllInputs: true,
		blockClass: 'ect-block',
		maskTextClass: 'ect-mask',
		slimDOMOptions: 'all',
		sampling: { mousemove: 50, scroll: 150, media: 800, input: 'last' }
	});
	setInterval(flush, 5000);
	addEventListener('pagehide', function () { flush(true); });
	document.addEventListener('visibilitychange', function () { if (document.hidden) flush(true); });
})();
