<?php
/**
 * Admin menu, pages, dashboard widget and settings.
 *
 * Free plan: Live visitors + countries are real data. Everything else is shown
 * blurred with dummy data and an Upgrade button (no real data is sent to the browser).
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Admin {

	const SLUG = 'ecomm-user-tracker';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'dashboard_widget' ) );
		add_action( 'admin_post_ect_geo_update', array( __CLASS__, 'handle_geo_update' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( ECT_FILE ), array( __CLASS__, 'action_links' ) );
		add_action( 'admin_footer-plugins.php', array( __CLASS__, 'deactivate_modal' ) );
		add_action( 'wp_ajax_ect_deactivate_feedback', array( __CLASS__, 'deactivate_feedback' ) );
	}

	public static function pages() {
		return array(
			self::SLUG                    => __( 'Highlights', 'ecomm-user-tracker' ),
			self::SLUG . '-realtime'      => __( 'Real-time', 'ecomm-user-tracker' ),
			self::SLUG . '-traffic'       => __( 'Traffic', 'ecomm-user-tracker' ),
			self::SLUG . '-behavior'      => __( 'Behavior', 'ecomm-user-tracker' ),
			self::SLUG . '-marketing'     => __( 'Marketing', 'ecomm-user-tracker' ),
			self::SLUG . '-recordings'    => __( 'Session Recordings', 'ecomm-user-tracker' ),
			self::SLUG . '-insights'      => __( 'Insights & Benchmarks', 'ecomm-user-tracker' ),
			self::SLUG . '-reports'       => __( 'All Reports', 'ecomm-user-tracker' ),
			self::SLUG . '-settings'      => __( 'Settings', 'ecomm-user-tracker' ),
		);
	}

	public static function menu() {
		add_menu_page(
			__( 'Ecomm User Tracker', 'ecomm-user-tracker' ),
			__( 'Ecomm User Tracker', 'ecomm-user-tracker' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-chart-area',
			3
		);
		foreach ( self::pages() as $slug => $title ) {
			add_submenu_page( self::SLUG, $title, $title, 'manage_options', $slug, array( __CLASS__, 'render' ) );
		}
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">' . esc_html__( 'Dashboard', 'ecomm-user-tracker' ) . '</a>' );
		$links[] = '<a href="' . esc_url( ECT_UPGRADE_URL ) . '" target="_blank" style="font-weight:600">' . esc_html__( 'Upgrade', 'ecomm-user-tracker' ) . '</a>';
		return $links;
	}

	public static function assets( $hook ) {
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 'index.php' !== $hook && ! isset( self::pages()[ $page ] ) ) {
			return;
		}
		wp_enqueue_style( 'ect-admin', ECT_URL . 'assets/css/admin.css', array(), ECT_VERSION );
		wp_enqueue_script( 'ect-admin', ECT_URL . 'assets/js/admin.js', array(), ECT_VERSION, true );
		wp_localize_script(
			'ect-admin',
			'ectAdmin',
			array(
				'endpoint' => esc_url_raw( rest_url( 'ect/v1/live' ) ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'locale'   => str_replace( '_', '-', get_user_locale() ),
				'i18n'     => array(
					'unknown'  => __( 'Unknown', 'ecomm-user-tracker' ),
					'empty'    => __( 'No visitors at the moment', 'ecomm-user-tracker' ),
					'updated'  => __( 'Updated', 'ecomm-user-tracker' ),
				),
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* Page rendering                                                      */
	/* ------------------------------------------------------------------ */

	public static function render() {
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : self::SLUG; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$titles = self::pages();
		echo '<div class="wrap ect-wrap">';
		echo '<div class="ect-header"><div><h1>' . esc_html( isset( $titles[ $page ] ) ? $titles[ $page ] : '' ) . '</h1>';
		echo '<p class="ect-sub">' . esc_html( self::subtitle( $page ) ) . '</p></div>';
		echo '<span class="ect-plan">' . esc_html__( 'Free plan', 'ecomm-user-tracker' ) . ' · <a href="' . esc_url( ECT_UPGRADE_URL ) . '" target="_blank">' . esc_html__( 'Upgrade', 'ecomm-user-tracker' ) . '</a></span></div>';

		switch ( $page ) {
			case self::SLUG:
				self::page_highlights();
				break;
			case self::SLUG . '-realtime':
				self::page_realtime();
				break;
			case self::SLUG . '-traffic':
				self::page_traffic();
				break;
			case self::SLUG . '-behavior':
				self::page_behavior();
				break;
			case self::SLUG . '-marketing':
				self::page_marketing();
				break;
			case self::SLUG . '-recordings':
				self::page_recordings();
				break;
			case self::SLUG . '-insights':
				self::page_insights();
				break;
			case self::SLUG . '-reports':
				self::page_reports();
				break;
			case self::SLUG . '-settings':
				self::page_settings();
				break;
		}
		echo '</div>';
	}

	private static function subtitle( $page ) {
		$map = array(
			self::SLUG                 => __( "Get a complete overview of your site's activity across all areas.", 'ecomm-user-tracker' ),
			self::SLUG . '-realtime'   => __( 'See how visitors interact with your site in real time.', 'ecomm-user-tracker' ),
			self::SLUG . '-traffic'    => __( "Track your site's traffic trends and get to know your visitors.", 'ecomm-user-tracker' ),
			self::SLUG . '-behavior'   => __( 'Learn how people navigate your site.', 'ecomm-user-tracker' ),
			self::SLUG . '-marketing'  => __( 'See which channels bring visitors, leads and sales.', 'ecomm-user-tracker' ),
			self::SLUG . '-recordings' => __( 'Watch how visitors use your site.', 'ecomm-user-tracker' ),
			self::SLUG . '-insights'   => __( 'Automatic insights and how you compare to similar stores.', 'ecomm-user-tracker' ),
			self::SLUG . '-reports'    => __( 'All reports in one place.', 'ecomm-user-tracker' ),
			self::SLUG . '-settings'   => __( 'Tracking and privacy settings.', 'ecomm-user-tracker' ),
		);
		return isset( $map[ $page ] ) ? $map[ $page ] : '';
	}

	/** Live visitors card — real data (Free). */
	private static function live_card( $with_countries = true ) {
		?>
		<div class="ect-card ect-live" data-ect-live>
			<div class="ect-live-head">
				<span class="ect-dot"></span>
				<span class="ect-live-count" data-ect-count>0</span>
				<span class="ect-live-label"><?php esc_html_e( 'live visitors', 'ecomm-user-tracker' ); ?></span>
			</div>
			<?php if ( $with_countries ) : ?>
				<h3><?php esc_html_e( 'Live visitors by country', 'ecomm-user-tracker' ); ?></h3>
				<ul class="ect-countries" data-ect-countries></ul>
				<p class="ect-empty" data-ect-empty><?php esc_html_e( "No visitors at the moment. Once you have real-time visitors, you'll see where they come from here.", 'ecomm-user-tracker' ); ?></p>
			<?php endif; ?>
			<p class="ect-muted" data-ect-updated></p>
		</div>
		<?php
	}

	/** Blurred locked section with dummy content + Upgrade. */
	private static function locked( $title, $plan, $kind = 'bars', $cols = 1 ) {
		$plan_label = array(
			'pro'     => 'Pro',
			'proplus' => 'Pro+',
			'agency'  => 'Agency',
		)[ $plan ];
		echo '<div class="ect-card ect-locked ect-span-' . (int) $cols . '">';
		echo '<h3>' . esc_html( $title ) . '</h3>';
		echo '<div class="ect-blur" aria-hidden="true">' . self::dummy( $kind ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="ect-lock-overlay"><span class="ect-badge">' . esc_html( $plan_label ) . '</span>';
		echo '<a class="button button-primary" href="' . esc_url( ECT_UPGRADE_URL . '&utm_content=' . rawurlencode( sanitize_title( $title ) ) ) . '" target="_blank">';
		/* translators: %s: plan name */
		echo esc_html( sprintf( __( 'Upgrade to %s', 'ecomm-user-tracker' ), $plan_label ) ) . '</a></div>';
		echo '</div>';
	}

	/** Static fake content — never real data. */
	private static function dummy( $kind ) {
		switch ( $kind ) {
			case 'kpis':
				$h = '<div class="ect-kpis">';
				foreach ( array( array( 'Site sessions', '1,284', '+12%' ), array( 'Total sales', '$4,920', '+8%' ), array( 'Total orders', '96', '+5%' ), array( 'Unique visitors', '842', '+9%' ) ) as $k ) {
					$h .= '<div class="ect-kpi"><span>' . $k[0] . '</span><strong>' . $k[1] . '</strong><em>' . $k[2] . '</em></div>';
				}
				return $h . '</div>';
			case 'chart':
				$h = '<svg viewBox="0 0 300 90" class="ect-fake-chart"><polyline fill="none" stroke="currentColor" stroke-width="3" points="0,70 30,55 60,62 90,40 120,48 150,25 180,35 210,20 240,30 270,12 300,22"/></svg>';
				return $h;
			case 'donut':
				return '<svg viewBox="0 0 42 42" class="ect-fake-donut"><circle cx="21" cy="21" r="15.9" fill="none" stroke="#c7d7fe" stroke-width="6"/><circle cx="21" cy="21" r="15.9" fill="none" stroke="currentColor" stroke-width="6" stroke-dasharray="70 30" stroke-dashoffset="25"/></svg>';
			case 'funnel':
				$h = '<div class="ect-fake-funnel">';
				foreach ( array( 100, 62, 30, 18, 9 ) as $v ) {
					$h .= '<span style="height:' . $v . '%"></span>';
				}
				return $h . '</div>';
			case 'cards':
				return '<div class="ect-fake-row"></div><div class="ect-fake-row"></div><div class="ect-fake-row short"></div>';
			default:
				$h = '<ul class="ect-fake-bars">';
				foreach ( array( array( '/homepage', 90 ), array( '/shop', 64 ), array( '/product/shoes', 41 ), array( '/cart', 22 ) ) as $b ) {
					$h .= '<li><span>' . $b[0] . '</span><i style="width:' . $b[1] . '%"></i></li>';
				}
				return $h . '</ul>';
		}
	}

	private static function grid_open( $cols = 3 ) {
		echo '<div class="ect-grid ect-cols-' . (int) $cols . '">';
	}

	private static function grid_close() {
		echo '</div>';
	}

	private static function page_highlights() {
		self::grid_open( 3 );
		self::live_card( true );
		self::locked( __( 'Key stats', 'ecomm-user-tracker' ), 'pro', 'kpis', 2 );
		self::grid_close();

		echo '<h2 class="ect-section">' . esc_html__( 'Get to know your visitors', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::locked( __( 'Sessions over time', 'ecomm-user-tracker' ), 'pro', 'chart' );
		self::locked( __( 'Top traffic sources', 'ecomm-user-tracker' ), 'pro', 'bars' );
		self::locked( __( 'Sessions by location', 'ecomm-user-tracker' ), 'pro', 'bars' );
		self::grid_close();

		echo '<h2 class="ect-section">' . esc_html__( 'Explore visitor engagement', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::locked( __( 'Most visited pages', 'ecomm-user-tracker' ), 'pro', 'bars' );
		self::locked( __( 'Engagement stats', 'ecomm-user-tracker' ), 'pro', 'kpis' );
		self::locked( __( 'Top button clicks', 'ecomm-user-tracker' ), 'pro', 'bars' );
		self::grid_close();
		self::recordings_banner();

		echo '<h2 class="ect-section">' . esc_html__( 'Analyze marketing performance', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::locked( __( 'Google Search Console', 'ecomm-user-tracker' ), 'proplus', 'cards' );
		self::locked( __( 'Email tools', 'ecomm-user-tracker' ), 'proplus', 'cards' );
		self::locked( __( 'Ad accounts', 'ecomm-user-tracker' ), 'proplus', 'cards' );
		self::grid_close();

		echo '<h2 class="ect-section">' . esc_html__( 'Track your sales', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::locked( __( 'Top selling items', 'ecomm-user-tracker' ), 'pro', 'bars' );
		self::locked( __( 'Sales by source', 'ecomm-user-tracker' ), 'pro', 'bars' );
		self::locked( __( 'Top paying customers', 'ecomm-user-tracker' ), 'pro', 'bars' );
		self::grid_close();

		echo '<h2 class="ect-section">' . esc_html__( 'Monitor store performance', 'ecomm-user-tracker' ) . '</h2>';
		self::grid_open( 3 );
		self::locked( __( 'Top store products', 'ecomm-user-tracker' ), 'pro', 'bars' );
		self::locked( __( 'Conversion funnel', 'ecomm-user-tracker' ), 'proplus', 'funnel', 2 );
		self::grid_close();
	}

	private static function page_realtime() {
		self::grid_open( 3 );
		echo '<div class="ect-span-2">';
		self::live_card( true );
		echo '</div>';
		self::locked( __( 'Recent visitors', 'ecomm-user-tracker' ), 'pro', 'cards' );
		self::grid_close();
		self::grid_open( 3 );
		self::locked( __( 'Visitors in the last 30 minutes', 'ecomm-user-tracker' ), 'pro', 'chart' );
		self::locked( __( 'Live activity', 'ecomm-user-tracker' ), 'pro', 'cards' );
		self::locked( __( 'Pages, sources & devices', 'ecomm-user-tracker' ), 'pro', 'donut' );
		self::grid_close();
		self::grid_open( 1 );
		self::locked( __( 'Visitor snapshot', 'ecomm-user-tracker' ), 'proplus', 'funnel' );
		self::grid_close();
	}

	private static function page_traffic() {
		self::grid_open( 3 );
		self::locked( __( 'Site sessions & unique visitors', 'ecomm-user-tracker' ), 'pro', 'kpis', 2 );
		self::locked( __( 'Sessions by source and category', 'ecomm-user-tracker' ), 'pro', 'bars' );
		self::locked( __( 'Sessions over time', 'ecomm-user-tracker' ), 'pro', 'chart', 2 );
		self::locked( __( 'Avg. sessions by day', 'ecomm-user-tracker' ), 'pro', 'funnel' );
		self::locked( __( 'New vs returning visitors', 'ecomm-user-tracker' ), 'pro', 'donut' );
		self::locked( __( 'Sessions by device', 'ecomm-user-tracker' ), 'pro', 'donut' );
		self::locked( __( 'Traffic insights', 'ecomm-user-tracker' ), 'agency', 'cards' );
		self::locked( __( 'Sessions by country', 'ecomm-user-tracker' ), 'pro', 'bars', 3 );
		self::grid_close();
	}

	private static function page_behavior() {
		self::grid_open( 3 );
		self::locked( __( 'Session duration, pages per session, bounce rate', 'ecomm-user-tracker' ), 'pro', 'kpis', 2 );
		self::locked( __( 'Top clicks', 'ecomm-user-tracker' ), 'pro', 'bars' );
		self::locked( __( 'Top pages', 'ecomm-user-tracker' ), 'pro', 'bars', 2 );
		self::locked( __( 'Entry pages', 'ecomm-user-tracker' ), 'pro', 'bars' );
		self::locked( __( 'Top navigation flows', 'ecomm-user-tracker' ), 'proplus', 'funnel', 3 );
		self::locked( __( 'Form submissions', 'ecomm-user-tracker' ), 'proplus', 'cards', 3 );
		self::grid_close();
		self::recordings_banner();
	}

	private static function page_marketing() {
		self::grid_open( 1 );
		self::locked( __( 'Performance by channel', 'ecomm-user-tracker' ), 'proplus', 'chart' );
		self::locked( __( 'Organic search', 'ecomm-user-tracker' ), 'proplus', 'bars' );
		self::locked( __( 'AI platforms', 'ecomm-user-tracker' ), 'proplus', 'bars' );
		self::locked( __( 'Email marketing', 'ecomm-user-tracker' ), 'proplus', 'cards' );
		self::grid_close();
	}

	private static function page_recordings() {
		self::grid_open( 1 );
		self::locked( __( 'Session recordings (Microsoft Clarity)', 'ecomm-user-tracker' ), 'proplus', 'cards' );
		self::grid_close();
	}

	private static function page_insights() {
		self::grid_open( 2 );
		self::locked( __( 'Insights', 'ecomm-user-tracker' ), 'agency', 'cards' );
		self::locked( __( 'Benchmarks', 'ecomm-user-tracker' ), 'agency', 'donut' );
		self::grid_close();
		echo '<div class="ect-card ect-hire"><p>' . esc_html__( 'Need help driving more traffic to your site?', 'ecomm-user-tracker' ) . '</p>';
		echo '<a class="button" target="_blank" href="https://everon.digital/?utm_source=ecomm-tracker&utm_medium=plugin&utm_campaign=hire-pro">' . esc_html__( 'Hire a Professional', 'ecomm-user-tracker' ) . '</a></div>';
	}

	private static function page_reports() {
		$cats = array(
			array( __( 'Sales', 'ecomm-user-tracker' ), 'pro' ),
			array( __( 'Accounting', 'ecomm-user-tracker' ), 'proplus' ),
			array( __( 'Traffic', 'ecomm-user-tracker' ), 'pro' ),
			array( __( 'Stores', 'ecomm-user-tracker' ), 'pro' ),
			array( __( 'Behavior', 'ecomm-user-tracker' ), 'pro' ),
			array( __( 'Marketing', 'ecomm-user-tracker' ), 'proplus' ),
			array( __( 'SEO', 'ecomm-user-tracker' ), 'proplus' ),
			array( __( 'People', 'ecomm-user-tracker' ), 'pro' ),
		);
		self::grid_open( 2 );
		foreach ( $cats as $c ) {
			self::locked( $c[0], $c[1], 'bars' );
		}
		self::grid_close();
	}

	private static function recordings_banner() {
		echo '<div class="ect-banner"><span>🎥 ' . esc_html__( 'Start recording site sessions to improve your visitor experience.', 'ecomm-user-tracker' ) . '</span>';
		echo '<a class="button" target="_blank" href="' . esc_url( ECT_UPGRADE_URL . '&utm_content=session-recordings' ) . '">' . esc_html__( 'Start Session Recordings', 'ecomm-user-tracker' ) . '</a></div>';
	}

	/* ------------------------------------------------------------------ */
	/* Settings                                                            */
	/* ------------------------------------------------------------------ */

	public static function register_settings() {
		register_setting(
			'ect_settings',
			'ect_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
			)
		);
	}

	public static function sanitize( $in ) {
		$out = array();
		foreach ( array( 'tracking', 'exclude_admins', 'respect_dnt', 'delete_data', 'auto_update' ) as $k ) {
			$out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
		}
		return $out;
	}

	private static function page_settings() {
		if ( isset( $_GET['ect_geo'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$ok = 'ok' === $_GET['ect_geo']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-' . ( $ok ? 'success' : 'error' ) . '"><p>' . esc_html( $ok ? __( 'Country database updated.', 'ecomm-user-tracker' ) : __( 'Country database download failed. Your host may block outgoing downloads.', 'ecomm-user-tracker' ) ) . '</p></div>';
		}
		$fields = array(
			'tracking'       => __( 'Enable visitor tracking', 'ecomm-user-tracker' ),
			'exclude_admins' => __( 'Do not track logged-in admins, editors and shop managers', 'ecomm-user-tracker' ),
			'respect_dnt'    => __( 'Respect browser "Do Not Track"', 'ecomm-user-tracker' ),
			'auto_update'    => __( 'Automatically install plugin updates', 'ecomm-user-tracker' ),
			'delete_data'    => __( 'Delete all plugin data when the plugin is deleted', 'ecomm-user-tracker' ),
		);
		echo '<div class="ect-card ect-settings"><form method="post" action="options.php">';
		settings_fields( 'ect_settings' );
		foreach ( $fields as $k => $label ) {
			echo '<p><label><input type="checkbox" name="ect_settings[' . esc_attr( $k ) . ']" value="1" ' . checked( (int) ect_get_option( $k ), 1, false ) . '> ' . esc_html( $label ) . '</label></p>';
		}
		submit_button();
		echo '</form></div>';

		echo '<div class="ect-card ect-settings"><h3>' . esc_html__( 'Country database', 'ecomm-user-tracker' ) . '</h3>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ect_geo_update' );
		echo '<input type="hidden" name="action" value="ect_geo_update">';
		submit_button( __( 'Update now', 'ecomm-user-tracker' ), 'secondary', 'submit', false );
		echo '</form></div>';
		echo '<p class="ect-footer">' . esc_html__( 'IP geolocation by DB-IP', 'ecomm-user-tracker' ) . '</p>';
	}

	public static function handle_geo_update() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_geo_update' );
		$res = ECT_Geo::update_db();
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '-settings&ect_geo=' . ( true === $res ? 'ok' : 'fail' ) ) );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Dashboard widget                                                    */
	/* ------------------------------------------------------------------ */

	public static function dashboard_widget() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		wp_add_dashboard_widget(
			'ect_live_widget',
			__( 'Ecomm User Tracker — Live', 'ecomm-user-tracker' ),
			function () {
				self::live_card( true );
				echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-realtime' ) ) . '">' . esc_html__( 'View Real-time Analytics', 'ecomm-user-tracker' ) . ' →</a></p>';
			}
		);
	}

	/* ------------------------------------------------------------------ */
	/* Deactivation feedback (optional)                                    */
	/* ------------------------------------------------------------------ */

	private static function feedback_reasons() {
		return array(
			'not_working'   => __( "It didn't work on my site", 'ecomm-user-tracker' ),
			'missing'       => __( "It's missing a feature I need", 'ecomm-user-tracker' ),
			'better'        => __( 'I found a better plugin', 'ecomm-user-tracker' ),
			'slow'          => __( 'It slowed down my site', 'ecomm-user-tracker' ),
			'temporary'     => __( "It's a temporary deactivation", 'ecomm-user-tracker' ),
			'other'         => __( 'Other', 'ecomm-user-tracker' ),
		);
	}

	public static function deactivate_modal() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		?>
		<div id="ect-deactivate" class="ect-modal" hidden>
			<div class="ect-modal-box" role="dialog" aria-modal="true" aria-labelledby="ect-deactivate-title">
				<h2 id="ect-deactivate-title"><?php esc_html_e( 'Quick feedback', 'ecomm-user-tracker' ); ?></h2>
				<p><?php esc_html_e( 'If you have a moment, please tell us why you are deactivating Ecomm User Tracker (optional):', 'ecomm-user-tracker' ); ?></p>
				<?php foreach ( self::feedback_reasons() as $key => $label ) : ?>
					<p><label><input type="radio" name="ect_reason" value="<?php echo esc_attr( $key ); ?>"> <?php echo esc_html( $label ); ?></label></p>
				<?php endforeach; ?>
				<textarea id="ect-reason-details" rows="3" placeholder="<?php esc_attr_e( 'Anything else? (optional)', 'ecomm-user-tracker' ); ?>"></textarea>
				<div class="ect-modal-actions">
					<button type="button" class="button-link" data-ect-skip><?php esc_html_e( 'Skip & Deactivate', 'ecomm-user-tracker' ); ?></button>
					<button type="button" class="button button-primary" data-ect-submit><?php esc_html_e( 'Submit & Deactivate', 'ecomm-user-tracker' ); ?></button>
				</div>
			</div>
		</div>
		<style>
			.ect-modal{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:100000;display:flex;align-items:center;justify-content:center}
			.ect-modal[hidden]{display:none}
			.ect-modal-box{background:#fff;border-radius:10px;padding:20px 24px;max-width:480px;width:calc(100% - 32px);box-shadow:0 10px 40px rgba(0,0,0,.25)}
			.ect-modal-box h2{margin-top:0}
			.ect-modal-box p{margin:6px 0}
			.ect-modal-box textarea{width:100%;margin-top:8px}
			.ect-modal-actions{display:flex;justify-content:space-between;align-items:center;margin-top:16px}
		</style>
		<script>
		(function () {
			var link = document.querySelector('tr[data-plugin="<?php echo esc_js( plugin_basename( ECT_FILE ) ); ?>"] .deactivate a');
			var modal = document.getElementById('ect-deactivate');
			if (!link || !modal) return;
			var href = link.href;
			link.addEventListener('click', function (e) { e.preventDefault(); modal.hidden = false; });
			modal.addEventListener('click', function (e) { if (e.target === modal) modal.hidden = true; });
			document.addEventListener('keydown', function (e) { if (e.key === 'Escape') modal.hidden = true; });
			modal.querySelector('[data-ect-skip]').addEventListener('click', function () { location.href = href; });
			modal.querySelector('[data-ect-submit]').addEventListener('click', function () {
				var r = modal.querySelector('input[name="ect_reason"]:checked');
				var d = document.getElementById('ect-reason-details').value;
				if (!r && !d) { location.href = href; return; }
				var body = new URLSearchParams({
					action: 'ect_deactivate_feedback',
					_wpnonce: '<?php echo esc_js( wp_create_nonce( 'ect_feedback' ) ); ?>',
					reason: r ? r.value : '',
					details: d
				});
				this.disabled = true;
				fetch(ajaxurl, { method: 'POST', body: body, credentials: 'same-origin' })
					.finally(function () { location.href = href; });
				setTimeout(function () { location.href = href; }, 3000);
			});
		})();
		</script>
		<?php
	}

	public static function deactivate_feedback() {
		check_ajax_referer( 'ect_feedback' );
		if ( ! current_user_can( 'activate_plugins' ) ) {
			wp_send_json_error( null, 403 );
		}
		$reasons = self::feedback_reasons();
		$reason  = isset( $_POST['reason'] ) ? sanitize_key( wp_unslash( $_POST['reason'] ) ) : '';
		$details = isset( $_POST['details'] ) ? sanitize_textarea_field( wp_unslash( $_POST['details'] ) ) : '';
		if ( ECT_FEEDBACK_URL && ( isset( $reasons[ $reason ] ) || '' !== $details ) ) {
			wp_remote_post(
				ECT_FEEDBACK_URL,
				array(
					'timeout'  => 5,
					'blocking' => false,
					'headers'  => array( 'Content-Type' => 'application/json' ),
					'body'     => wp_json_encode(
						array(
							'plugin'      => 'ecomm-user-tracker',
							'version'     => ECT_VERSION,
							'reason'      => $reason,
							'details'     => substr( $details, 0, 1000 ),
							'wp_version'  => get_bloginfo( 'version' ),
							'php_version' => PHP_VERSION,
							'locale'      => get_locale(),
						)
					),
				)
			);
		}
		wp_send_json_success();
	}
}
