<?php
/**
 * Plugin Name:       Ecomm User Tracker
 * Plugin URI:        https://everon.digital/
 * Description:       Live visitors and their countries for WordPress & WooCommerce stores. Lightweight, privacy-friendly, data stays on your site.
 * Version:           0.1.4
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Everon Digital
 * Author URI:        https://everon.digital/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ecomm-user-tracker
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

define( 'ECT_VERSION', '0.1.4' );
define( 'ECT_FILE', __FILE__ );
define( 'ECT_DIR', plugin_dir_path( __FILE__ ) );
define( 'ECT_URL', plugin_dir_url( __FILE__ ) );
define( 'ECT_LIVE_WINDOW', 5 * MINUTE_IN_SECONDS );
define( 'ECT_RETENTION', DAY_IN_SECONDS );

if ( ! defined( 'ECT_UPGRADE_URL' ) ) {
	define( 'ECT_UPGRADE_URL', 'https://everon.digital/?utm_source=ecomm-tracker&utm_medium=plugin&utm_campaign=upgrade' );
}
if ( ! defined( 'ECT_FEEDBACK_URL' ) ) {
	// Deactivation feedback endpoint (control plane). Empty = feedback is not sent anywhere.
	define( 'ECT_FEEDBACK_URL', '' );
}
if ( ! defined( 'ECT_UPDATE_URL' ) ) {
	// JSON file with the latest version info, see docs/UPDATES.md.
	define( 'ECT_UPDATE_URL', 'https://raw.githubusercontent.com/Everon-digital/ecomm-tracker-updates/main/update.json' );
}

require_once ECT_DIR . 'includes/class-ect-mmdb-reader.php';
require_once ECT_DIR . 'includes/class-ect-geo.php';
require_once ECT_DIR . 'includes/class-ect-db.php';
require_once ECT_DIR . 'includes/class-ect-tracker.php';
require_once ECT_DIR . 'includes/class-ect-admin.php';
require_once ECT_DIR . 'includes/class-ect-updater.php';

register_activation_hook( __FILE__, array( 'ECT_DB', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'ECT_DB', 'deactivate' ) );

add_action( 'plugins_loaded', 'ect_init' );
function ect_init() {
	ECT_DB::maybe_upgrade();
	// 0.1.4: "Delete all plugin data" is now on by default — apply once to existing installs.
	if ( ! get_option( 'ect_mig_014' ) ) {
		$opts                = (array) get_option( 'ect_settings', array() );
		$opts['delete_data'] = 1;
		update_option( 'ect_settings', $opts );
		update_option( 'ect_mig_014', 1, false );
	}
	ECT_Tracker::init();
	ECT_Updater::init();
	if ( is_admin() ) {
		ECT_Admin::init();
	}
	add_action( 'ect_cleanup', array( 'ECT_DB', 'cleanup' ) );
	add_action( 'ect_geo_update', array( 'ECT_Geo', 'maybe_update' ) );
}

function ect_get_option( $key, $default = null ) {
	$opts = get_option( 'ect_settings', array() );
	$defaults = array(
		'tracking'       => 1,
		'exclude_admins' => 1,
		'respect_dnt'    => 0,
		'delete_data'    => 1,
		'auto_update'    => 1,
	);
	if ( isset( $opts[ $key ] ) ) {
		return $opts[ $key ];
	}
	return isset( $defaults[ $key ] ) ? $defaults[ $key ] : $default;
}
