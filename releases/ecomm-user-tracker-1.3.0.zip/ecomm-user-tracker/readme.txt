=== StorePinger ===
Contributors: everondigital
Tags: analytics, live visitors, woocommerce, real-time, statistics
Requires at least: 7.1
Tested up to: 7.2
Requires PHP: 8.3
Stable tag: 1.3.0
License: GPLv2 or later

Live visitors, traffic sources, sales and store analytics for WordPress & WooCommerce. Lightweight and privacy-friendly.

== Description ==

* Live visitors count (last 5 minutes)
* Live visitors by country (with flags)
* Dashboard widget
* Pro / Pro+ / Agency unlock traffic sources (incl. AI tools), pages, orders, funnels, reports and more

IP geolocation by DB-IP (https://db-ip.com), CC BY 4.0.

== Changelog ==

= 1.3.0 =
* New: AI Assistant preview: ask questions about your store in plain words (coming soon).
* New: Pro now includes every feature, with extra sites available as an add-on.
* Improved: Clearer plan names across the dashboard.

= 1.2.1 =
* Improved: Cleaner dashboard that uses the WordPress menu.
* Improved: Plugin name and branding shown the same everywhere.

= 1.2.0 =
* New: Redesigned dashboard: bigger numbers, a live card and cleaner reports.
* Improved: Settings arranged in three columns you can drag and drop.
* Fixed: Buttons in the mobile app settings no longer overlap.

= 1.1.0 =
* New: Email marketing: templates, contact lists, safe sending and orders per campaign.
* New: Areas inside cities, with Top areas and Traffic by Area.
* New: New plugin features now appear in the mobile app automatically.

= 1.0.9 =
* New: Mobile app for iPhone and Android: connect with a QR code.
* New: Notifications for visitors, orders, carts, stock and checkout problems.
* New: Choose the time of your email report.
* Improved: Real-time: last 30 minutes next to recent visitors.

= 1.0.8 =
* New: City and region for every visit, and Sales by City for ad targeting.
* New: Month-start reminder for carts left last month.

= 1.0.7 =
* New: Abandoned cart recovery: three reminder emails with a coupon on the last one.
* New: Payment links for pending and draft orders.
* Improved: Store emails use your store name and colors.

= 1.0.6 =
* New: Session recordings stored on your own site, with a new player.
* Improved: Recordings load after the page has finished loading.
* Improved: More reliable automatic updates.

= 1.0.5 =
* New: Custom date ranges, email reports, alerts and white-label reports.
* New: Store, customer, inventory, search, 404 and blog reports.
* Fixed: Sales now include orders with custom statuses such as Shipped.

= 1.0.4 =
* New: Conversion funnel, button clicks, forms and new vs returning visitors.
* Improved: Real-time pages update every second without refreshing.

= 1.0.3 =
* New: Store sales, orders, top products and sales by source.
* Fixed: Visitors now appear right away on sites with caching plugins.

= 1.0.2 =
* New: Traffic sources: ads vs organic, email and AI tools like ChatGPT.
* New: Pages, entry and exit pages, devices and time on site.
* Fixed: Visitors blocked by ad blockers are counted again.

= 1.0.1 =
* New: Beta release: live visitors, world map and today’s visitors in your WordPress dashboard.

