<?php
/**
 * Works out where a session came from (channel + source) and the device type.
 *
 * Channels: direct, organic_search, paid_search, organic_social, paid_social, ai, email, referral.
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Source {

	/** Host suffix => AI tool name. Checked before search engines (gemini.google.com etc.). */
	const AI = array(
		'chatgpt.com'           => 'ChatGPT',
		'chat.openai.com'       => 'ChatGPT',
		'openai.com'            => 'ChatGPT',
		'claude.ai'             => 'Claude',
		'gemini.google.com'     => 'Gemini',
		'bard.google.com'       => 'Gemini',
		'perplexity.ai'         => 'Perplexity',
		'copilot.microsoft.com' => 'Copilot',
		'copilot.cloud.microsoft' => 'Copilot',
		'chat.deepseek.com'     => 'DeepSeek',
		'deepseek.com'          => 'DeepSeek',
		'grok.com'              => 'Grok',
		'meta.ai'               => 'Meta AI',
		'chat.mistral.ai'       => 'Mistral',
		'you.com'               => 'You.com',
		'poe.com'               => 'Poe',
		'phind.com'             => 'Phind',
	);

	const SEARCH = array(
		'google'     => 'Google',
		'bing'       => 'Bing',
		'yahoo'      => 'Yahoo',
		'duckduckgo' => 'DuckDuckGo',
		'yandex'     => 'Yandex',
		'baidu'      => 'Baidu',
		'ecosia'     => 'Ecosia',
		'brave'      => 'Brave Search',
	);

	const SOCIAL = array(
		'facebook.com'  => 'Facebook',
		'fb.com'        => 'Facebook',
		'fb.me'         => 'Facebook',
		'messenger.com' => 'Facebook',
		'instagram.com' => 'Instagram',
		'threads.net'   => 'Threads',
		't.co'          => 'X (Twitter)',
		'x.com'         => 'X (Twitter)',
		'twitter.com'   => 'X (Twitter)',
		'linkedin.com'  => 'LinkedIn',
		'lnkd.in'       => 'LinkedIn',
		'youtube.com'   => 'YouTube',
		'youtu.be'      => 'YouTube',
		'tiktok.com'    => 'TikTok',
		'pinterest.com' => 'Pinterest',
		'pin.it'        => 'Pinterest',
		'reddit.com'    => 'Reddit',
		'wa.me'         => 'WhatsApp',
		'whatsapp.com'  => 'WhatsApp',
		'snapchat.com'  => 'Snapchat',
		'telegram.org'  => 'Telegram',
		't.me'          => 'Telegram',
	);

	/**
	 * @param string $referrer Full referrer URL.
	 * @param array  $q        Allowed query params from the landing URL.
	 * @return array [ channel, source ]
	 */
	public static function classify( $referrer, $q ) {
		$q      = is_array( $q ) ? array_change_key_case( $q, CASE_LOWER ) : array();
		$medium = isset( $q['utm_medium'] ) ? strtolower( $q['utm_medium'] ) : '';
		$usrc   = isset( $q['utm_source'] ) ? strtolower( $q['utm_source'] ) : '';
		$host   = strtolower( (string) wp_parse_url( $referrer, PHP_URL_HOST ) );
		$host   = preg_replace( '/^(www|m|l|lm|mobile)\./', '', $host );
		$own    = preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
		if ( $host === $own ) {
			$host = '';
		}

		// 1. Paid clicks (ad click IDs or paid UTM medium).
		if ( ! empty( $q['gclid'] ) || ! empty( $q['gbraid'] ) || ! empty( $q['wbraid'] ) ) {
			return array( 'paid_search', 'Google' );
		}
		if ( ! empty( $q['msclkid'] ) ) {
			return array( 'paid_search', 'Bing' );
		}
		if ( preg_match( '/(^|\.)(doubleclick\.net|googlesyndication\.com|googleadservices\.com)$/', $host ) ) {
			return array( 'paid_search', 'Google' );
		}
		$is_paid = (bool) preg_match( '/cpc|ppc|paid|cpm|display|ads?$/', $medium );
		$social  = self::match( $usrc ? $usrc : $host, self::SOCIAL, true );
		if ( $is_paid || ( ! empty( $q['fbclid'] ) && $is_paid ) || ! empty( $q['ttclid'] ) ) {
			if ( ! empty( $q['ttclid'] ) ) {
				return array( 'paid_social', 'TikTok' );
			}
			if ( $social || ! empty( $q['fbclid'] ) || false !== strpos( $medium, 'social' ) ) {
				return array( 'paid_social', $social ? $social : 'Facebook' );
			}
			$search = self::match( $usrc ? $usrc : $host, self::SEARCH, false );
			return array( 'paid_search', $search ? $search : ( $usrc ? ucfirst( $usrc ) : 'Other' ) );
		}

		// 2. AI tools.
		$ai = self::match( $host, self::AI, true );
		if ( ! $ai && $usrc ) {
			$ai = self::match( $usrc, self::AI, true );
		}
		if ( $ai ) {
			return array( 'ai', $ai );
		}

		// 3. Email.
		if ( false !== strpos( $medium, 'email' ) || false !== strpos( $medium, 'newsletter' ) ) {
			return array( 'email', $usrc ? ucfirst( $usrc ) : 'Email' );
		}

		// 4. Search engines and social networks.
		if ( $host ) {
			$search = self::match( $host, self::SEARCH, false );
			if ( $search ) {
				return array( 'organic_search', $search );
			}
			if ( $social ) {
				return array( 'organic_social', $social );
			}
			return array( 'referral', substr( $host, 0, 100 ) );
		}
		if ( ! empty( $q['fbclid'] ) ) {
			return array( 'organic_social', 'Facebook' );
		}
		if ( $social ) {
			return array( 'organic_social', $social );
		}
		if ( $usrc ) {
			return array( 'referral', substr( $usrc, 0, 100 ) );
		}
		return array( 'direct', 'Direct' );
	}

	/** Match a host/utm_source against a map. $suffix = match by domain suffix, else by keyword. */
	private static function match( $value, $map, $suffix ) {
		if ( '' === $value ) {
			return '';
		}
		foreach ( $map as $needle => $name ) {
			if ( $suffix ) {
				if ( $value === $needle || substr( $value, -strlen( '.' . $needle ) ) === '.' . $needle || ( false === strpos( $value, '.' ) && 0 === strpos( $needle, $value . '.' ) ) ) {
					return $name;
				}
			} elseif ( preg_match( '/(^|\.)' . preg_quote( $needle, '/' ) . '\./', $value . '.' ) ) {
				return $name;
			}
		}
		return '';
	}

	/** Human label, e.g. "Google (Organic)", "ChatGPT (AI)". */
	public static function label( $channel, $source ) {
		switch ( $channel ) {
			case 'direct':
				return __( 'Direct', 'ecomm-user-tracker' );
			case 'organic_search':
			case 'organic_social':
				/* translators: %s: source name */
				return sprintf( __( '%s (Organic)', 'ecomm-user-tracker' ), $source );
			case 'paid_search':
			case 'paid_social':
				/* translators: %s: source name */
				return sprintf( __( '%s (Ads)', 'ecomm-user-tracker' ), $source );
			case 'ai':
				/* translators: %s: AI tool name */
				return sprintf( __( '%s (AI)', 'ecomm-user-tracker' ), $source );
			case 'email':
				/* translators: %s: source name */
				return sprintf( __( 'Email · %s', 'ecomm-user-tracker' ), $source );
			default:
				return $source;
		}
	}

	public static function device( $ua ) {
		if ( preg_match( '/iPad|Tablet|PlayBook|Silk|Kindle|(Android(?!.*Mobile))/i', $ua ) ) {
			return 'tablet';
		}
		if ( preg_match( '/Mobi|iPhone|iPod|Android|BlackBerry|Opera Mini|IEMobile/i', $ua ) ) {
			return 'mobile';
		}
		return 'desktop';
	}

	public static function browser( $ua ) {
		$map = array(
			'Edge'             => '/Edg(e|A|iOS)?\//',
			'Opera'            => '/OPR\/|Opera/',
			'Samsung Internet' => '/SamsungBrowser/',
			'Facebook app'     => '/FBAN|FBAV/',
			'Instagram app'    => '/Instagram/',
			'Firefox'          => '/Firefox|FxiOS/',
			'Chrome'           => '/Chrome|CriOS/',
			'Safari'           => '/Safari/',
		);
		foreach ( $map as $name => $re ) {
			if ( preg_match( $re, $ua ) ) {
				return $name;
			}
		}
		return 'Other';
	}

	public static function os( $ua ) {
		$map = array(
			'iOS'       => '/iPhone|iPad|iPod/',
			'Android'   => '/Android/',
			'Windows'   => '/Windows/',
			'macOS'     => '/Mac OS X|Macintosh/',
			'Chrome OS' => '/CrOS/',
			'Linux'     => '/Linux/',
		);
		foreach ( $map as $name => $re ) {
			if ( preg_match( $re, $ua ) ) {
				return $name;
			}
		}
		return 'Other';
	}

	/** AI / search crawler names, used for AI visibility. */
	const BOTS = array(
		'ChatGPT-User'       => 'ChatGPT-User',
		'OAI-SearchBot'      => 'OAI-SearchBot',
		'GPTBot'             => 'GPTBot',
		'Claude-User'        => 'Claude-User',
		'Claude-SearchBot'   => 'Claude-SearchBot',
		'ClaudeBot'          => 'ClaudeBot',
		'Perplexity-User'    => 'Perplexity-User',
		'PerplexityBot'      => 'PerplexityBot',
		'Google-Extended'    => 'Google-Extended',
		'Applebot-Extended'  => 'Applebot-Extended',
		'CCBot'              => 'CCBot',
		'Bytespider'         => 'Bytespider',
		'meta-externalagent' => 'Meta AI',
		'DuckAssistBot'      => 'DuckAssistBot',
		'MistralAI-User'     => 'MistralAI-User',
		'Googlebot'          => 'Googlebot',
		'bingbot'            => 'Bingbot',
	);

	/** AI fetchers that load a page because a person asked the AI something right now. */
	const AI_USER_BOTS = array( 'ChatGPT-User', 'Claude-User', 'Perplexity-User', 'MistralAI-User', 'DuckAssistBot' );

	public static function bot( $ua ) {
		foreach ( self::BOTS as $needle => $name ) {
			if ( false !== stripos( $ua, $needle ) ) {
				return $name;
			}
		}
		return '';
	}
}
