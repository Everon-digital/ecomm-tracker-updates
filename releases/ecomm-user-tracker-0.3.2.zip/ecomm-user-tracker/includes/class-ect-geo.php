<?php
/**
 * Country lookup. Uses the CDN country header when present (Cloudflare etc.),
 * otherwise a local DB-IP Lite database stored in uploads (no external API calls per visitor).
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Geo {

	const DB_FILE = 'dbip-country.mmdb';

	/** @var ECT_MMDB_Reader|null|false */
	private static $reader = null;

	public static function dir() {
		$up = wp_upload_dir( null, false );
		return trailingslashit( $up['basedir'] ) . 'ecomm-user-tracker/';
	}

	public static function db_path() {
		return self::dir() . self::DB_FILE;
	}

	public static function has_db() {
		return file_exists( self::db_path() );
	}

	/**
	 * @return string Two-letter country code or '' if unknown.
	 */
	public static function country() {
		foreach ( array( 'HTTP_CF_IPCOUNTRY', 'HTTP_X_COUNTRY_CODE', 'HTTP_CLOUDFRONT_VIEWER_COUNTRY', 'GEOIP_COUNTRY_CODE' ) as $h ) {
			if ( ! empty( $_SERVER[ $h ] ) ) {
				$cc = strtoupper( substr( sanitize_text_field( wp_unslash( $_SERVER[ $h ] ) ), 0, 2 ) );
				if ( preg_match( '/^[A-Z]{2}$/', $cc ) && ! in_array( $cc, array( 'XX', 'T1' ), true ) ) {
					return $cc;
				}
			}
		}
		return self::lookup( self::client_ip() );
	}

	public static function lookup( $ip ) {
		if ( ! $ip ) {
			return '';
		}
		if ( null === self::$reader ) {
			self::$reader = false;
			if ( self::has_db() ) {
				try {
					self::$reader = new ECT_MMDB_Reader( self::db_path() );
				} catch ( Exception $e ) {
					self::$reader = false;
				}
			}
		}
		if ( ! self::$reader ) {
			return '';
		}
		try {
			$rec = self::$reader->get( $ip );
		} catch ( Exception $e ) {
			return '';
		}
		if ( isset( $rec['country']['iso_code'] ) ) {
			return strtoupper( $rec['country']['iso_code'] );
		}
		if ( isset( $rec['country_code'] ) ) {
			return strtoupper( $rec['country_code'] );
		}
		return '';
	}

	/**
	 * Visitor IP. Only trusts forwarding headers when the direct peer is a private/proxy address.
	 * The IP is used for the lookup only and is never stored.
	 */
	public static function client_ip() {
		$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$is_public = filter_var( $remote, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
		if ( $is_public && ! isset( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			return $remote;
		}
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR' ) as $h ) {
			if ( empty( $_SERVER[ $h ] ) ) {
				continue;
			}
			$candidate = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $h ] ) ) )[0] );
			if ( filter_var( $candidate, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				return $candidate;
			}
		}
		return $remote;
	}

	/**
	 * Download / refresh the DB-IP Lite country database (CC BY 4.0, monthly).
	 *
	 * @return true|WP_Error
	 */
	public static function update_db() {
		require_once ABSPATH . 'wp-admin/includes/file.php';

		$dir = self::dir();
		if ( ! wp_mkdir_p( $dir ) ) {
			return new WP_Error( 'ect_dir', __( 'Could not create uploads folder.', 'ecomm-user-tracker' ) );
		}
		if ( ! file_exists( $dir . 'index.php' ) ) {
			file_put_contents( $dir . 'index.php', "<?php // Silence is golden.\n" );
			file_put_contents( $dir . '.htaccess', "Deny from all\n" );
		}

		$urls = array();
		foreach ( array( 0, 1 ) as $months_back ) {
			$ym     = gmdate( 'Y-m', strtotime( "first day of -{$months_back} month" ) );
			$urls[] = "https://download.db-ip.com/free/dbip-country-lite-{$ym}.mmdb.gz";
		}
		$urls[] = 'https://cdn.jsdelivr.net/npm/@ip-location-db/dbip-country-mmdb/dbip-country.mmdb';

		$last_error = null;
		foreach ( $urls as $url ) {
			$tmp = download_url( $url, 120 );
			if ( is_wp_error( $tmp ) ) {
				$last_error = $tmp;
				continue;
			}
			$data = file_get_contents( $tmp );
			wp_delete_file( $tmp );
			if ( '.gz' === substr( $url, -3 ) ) {
				$data = function_exists( 'gzdecode' ) ? @gzdecode( $data ) : false;
			}
			if ( ! $data || false === strpos( substr( $data, -131072 ), ECT_MMDB_Reader::METADATA_MARKER ) ) {
				$last_error = new WP_Error( 'ect_db', __( 'Downloaded database is invalid.', 'ecomm-user-tracker' ) );
				continue;
			}
			$tmp_path = $dir . self::DB_FILE . '.tmp';
			file_put_contents( $tmp_path, $data );
			try {
				$test = new ECT_MMDB_Reader( $tmp_path );
				unset( $test );
			} catch ( Exception $e ) {
				wp_delete_file( $tmp_path );
				$last_error = new WP_Error( 'ect_db', $e->getMessage() );
				continue;
			}
			rename( $tmp_path, self::db_path() );
			update_option( 'ect_geo_updated', time(), false );
			return true;
		}
		return $last_error ? $last_error : new WP_Error( 'ect_db', __( 'Download failed.', 'ecomm-user-tracker' ) );
	}

	public static function maybe_update() {
		$updated = (int) get_option( 'ect_geo_updated', 0 );
		if ( ! self::has_db() || $updated < time() - 35 * DAY_IN_SECONDS ) {
			self::update_db();
		}
	}
}
