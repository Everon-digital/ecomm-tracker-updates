<?php
/**
 * License / plan. The plan decides which sections show real data and how long data is kept.
 *
 * Keys are validated against the licensing API (control plane). Until that API exists,
 * a site owner can test paid features with: define( 'ECT_DEV_PLAN', 'pro' ); in wp-config.php
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_License {

	const PLANS = array(
		'free'    => 0,
		'pro'     => 1,
		'proplus' => 2,
		'agency'  => 3,
	);

	public static function init() {
		add_action( 'ect_license_check', array( __CLASS__, 'recheck' ) );
		if ( ! wp_next_scheduled( 'ect_license_check' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'ect_license_check' );
		}
	}

	/** Everon Digital's own sites: full plan, free forever (no license key needed). */
	const COMPLIMENTARY = array(
		'pinnaclelifesciences.com' => 'agency',
	);

	public static function complimentary() {
		$host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$host = preg_replace( '/^www\./', '', $host );
		return isset( self::COMPLIMENTARY[ $host ] ) ? self::COMPLIMENTARY[ $host ] : '';
	}

	public static function plan() {
		if ( defined( 'ECT_DEV_PLAN' ) && isset( self::PLANS[ ECT_DEV_PLAN ] ) ) {
			return ECT_DEV_PLAN;
		}
		$comp = self::complimentary();
		if ( $comp ) {
			return $comp;
		}
		$lic = get_option( 'ect_license', array() );
		if ( ! empty( $lic['plan'] ) && isset( self::PLANS[ $lic['plan'] ] ) && ( empty( $lic['expires'] ) || $lic['expires'] > time() ) ) {
			return $lic['plan'];
		}
		return 'free';
	}

	/** True if the current plan is at least $plan. */
	public static function has( $plan ) {
		return self::PLANS[ self::plan() ] >= self::PLANS[ $plan ];
	}

	public static function label( $plan = null ) {
		$labels = array(
			'free'    => __( 'Free', 'ecomm-user-tracker' ),
			'pro'     => 'Pro',
			'proplus' => 'Pro+',
			'agency'  => 'Agency',
		);
		return $labels[ $plan ? $plan : self::plan() ];
	}

	/** How long analytics data is kept, in days. */
	public static function retention_days() {
		switch ( self::plan() ) {
			case 'agency':
			case 'proplus':
				return 365;
			case 'pro':
				return 30;
			default:
				return 1;
		}
	}

	public static function key() {
		$lic = get_option( 'ect_license', array() );
		return isset( $lic['key'] ) ? $lic['key'] : '';
	}

	/**
	 * @return true|WP_Error
	 */
	public static function activate( $key ) {
		$key = strtoupper( preg_replace( '/[^A-Za-z0-9-]/', '', (string) $key ) );
		if ( strlen( $key ) < 8 ) {
			return new WP_Error( 'ect_key', __( 'Please enter a valid license key.', 'ecomm-user-tracker' ) );
		}
		$res = self::remote( 'activate', $key );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		update_option(
			'ect_license',
			array(
				'key'     => $key,
				'plan'    => $res['plan'],
				'expires' => isset( $res['expires'] ) ? (int) $res['expires'] : 0,
				'checked' => time(),
			)
		);
		return true;
	}

	public static function deactivate() {
		$key = self::key();
		if ( $key ) {
			self::remote( 'deactivate', $key );
		}
		delete_option( 'ect_license' );
	}

	public static function recheck() {
		$key = self::key();
		if ( ! $key ) {
			return;
		}
		$res = self::remote( 'check', $key );
		if ( is_wp_error( $res ) ) {
			// Network problems never downgrade a paying site; an explicit "invalid" does.
			if ( 'ect_invalid' === $res->get_error_code() ) {
				delete_option( 'ect_license' );
			}
			return;
		}
		$lic            = get_option( 'ect_license', array() );
		$lic['plan']    = $res['plan'];
		$lic['expires'] = isset( $res['expires'] ) ? (int) $res['expires'] : 0;
		$lic['checked'] = time();
		update_option( 'ect_license', $lic );
	}

	private static function remote( $action, $key ) {
		if ( ! ECT_LICENSE_API ) {
			return new WP_Error( 'ect_api', __( 'License activation will be available soon.', 'ecomm-user-tracker' ) );
		}
		$res = wp_remote_post(
			trailingslashit( ECT_LICENSE_API ) . $action,
			array(
				'timeout' => 15,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode(
					array(
						'key'     => $key,
						'site'    => home_url(),
						'version' => ECT_VERSION,
					)
				),
			)
		);
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( empty( $body['valid'] ) ) {
			$msg = ! empty( $body['message'] ) ? sanitize_text_field( $body['message'] ) : __( 'This license key is not valid.', 'ecomm-user-tracker' );
			return new WP_Error( 'ect_invalid', $msg );
		}
		if ( empty( $body['plan'] ) || ! isset( self::PLANS[ $body['plan'] ] ) ) {
			return new WP_Error( 'ect_api', __( 'Unexpected response from the license server.', 'ecomm-user-tracker' ) );
		}
		return $body;
	}
}
