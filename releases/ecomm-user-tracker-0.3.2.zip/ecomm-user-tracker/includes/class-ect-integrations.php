<?php
/**
 * Pro+ integrations that need no external account from us:
 * - Email link tagging (UTM) so email clicks and sales show up under "Email".
 * - Microsoft Clarity session recordings (free; user pastes their project ID).
 * - AI readiness checks for the AI visibility score.
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Integrations {

	public static function init() {
		if ( ! ECT_License::has( 'proplus' ) ) {
			return;
		}
		if ( ect_get_option( 'email_utm' ) ) {
			add_filter( 'wp_mail', array( __CLASS__, 'tag_email' ), 99 );
		}
		if ( self::clarity_id() ) {
			add_action( 'wp_head', array( __CLASS__, 'clarity' ), 1 );
		}
	}

	/* ---------------- Email tagging ---------------- */

	public static function tag_email( $args ) {
		if ( empty( $args['message'] ) || ! is_string( $args['message'] ) ) {
			return $args;
		}
		$host     = wp_parse_url( home_url(), PHP_URL_HOST );
		$campaign = sanitize_title( wp_strip_all_tags( (string) $args['subject'] ) );
		$campaign = substr( preg_replace( '/-?\d+-?/', '-', $campaign ), 0, 60 );
		$campaign = trim( $campaign, '-' );
		$args['message'] = preg_replace_callback(
			'#https?://[^\s"\'<>]+#i',
			function ( $m ) use ( $host, $campaign ) {
				$url = html_entity_decode( $m[0] );
				$h   = wp_parse_url( $url, PHP_URL_HOST );
				// Only our own store links; never login / password / unsubscribe links.
				if ( $h !== $host || preg_match( '#wp-login\.php|wp-admin|action=rp|key=|unsubscribe|\.(png|jpe?g|gif|webp|svg)$#i', $url ) || false !== strpos( $url, 'utm_' ) ) {
					return $m[0];
				}
				$tagged = add_query_arg(
					array(
						'utm_source'   => 'wordpress',
						'utm_medium'   => 'email',
						'utm_campaign' => $campaign ? $campaign : 'email',
					),
					$url
				);
				return false !== strpos( $m[0], '&amp;' ) ? str_replace( '&', '&amp;', $tagged ) : $tagged;
			},
			$args['message']
		);
		return $args;
	}

	/* ---------------- Microsoft Clarity ---------------- */

	public static function clarity_id() {
		$id = (string) ect_get_option( 'clarity_id', '' );
		return preg_match( '/^[a-z0-9]{6,20}$/i', $id ) ? $id : '';
	}

	public static function clarity() {
		if ( ! ECT_Tracker::should_track() ) {
			return;
		}
		$id = self::clarity_id();
		?>
		<script data-no-optimize="1" data-cfasync="false">
		(function(c,l,a,r,i,t,y){c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);})(window,document,"clarity","script",<?php echo wp_json_encode( $id ); ?>);
		try { var v = localStorage.getItem('ect_vid'); if (v) clarity('set', 'ect_visitor', v.slice(0, 12)); } catch (e) {}
		</script>
		<?php
	}

	/* ---------------- AI readiness (for the AI visibility score) ---------------- */

	public static function readiness() {
		$cached = get_transient( 'ect_ai_readiness' );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$checks = array();

		$robots = wp_remote_get( home_url( '/robots.txt' ), array( 'timeout' => 8 ) );
		$body   = is_wp_error( $robots ) ? '' : (string) wp_remote_retrieve_body( $robots );
		$blocks = (bool) preg_match( '/User-agent:\s*(GPTBot|ClaudeBot|PerplexityBot|OAI-SearchBot|ChatGPT-User|\*)\s*[\r\n]+(?:[^\r\n]*[\r\n]+)*?\s*Disallow:\s*\/\s*$/mi', $body );
		$checks['robots'] = array( __( 'robots.txt does not block AI bots', 'ecomm-user-tracker' ), ! $blocks, __( 'Remove "Disallow: /" for GPTBot, ClaudeBot, PerplexityBot and OAI-SearchBot in robots.txt.', 'ecomm-user-tracker' ) );

		$llms = wp_remote_head( home_url( '/llms.txt' ), array( 'timeout' => 8 ) );
		$checks['llms'] = array( __( 'llms.txt file', 'ecomm-user-tracker' ), file_exists( ABSPATH . 'llms.txt' ) || ( ! is_wp_error( $llms ) && 200 === wp_remote_retrieve_response_code( $llms ) ), __( 'Add an llms.txt file that summarises your store and links to key pages.', 'ecomm-user-tracker' ) );

		$checks['sitemap'] = array( __( 'XML sitemap', 'ecomm-user-tracker' ), (bool) get_option( 'blog_public' ) && ( function_exists( 'wp_sitemaps_get_server' ) || defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) ), __( 'Enable your sitemap (Settings → Reading → allow search engines, or your SEO plugin).', 'ecomm-user-tracker' ) );

		$checks['https'] = array( __( 'HTTPS', 'ecomm-user-tracker' ), 'https' === wp_parse_url( home_url(), PHP_URL_SCHEME ), __( 'Install an SSL certificate and use https:// for your site address.', 'ecomm-user-tracker' ) );

		$checks['schema'] = array( __( 'Product structured data', 'ecomm-user-tracker' ), ECT_Woo::active(), __( 'Use WooCommerce (adds Product schema) or an SEO plugin with product schema.', 'ecomm-user-tracker' ) );

		$checks['seo'] = array( __( 'Titles & meta descriptions (SEO plugin)', 'ecomm-user-tracker' ), defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || class_exists( 'The_SEO_Framework\Load' ), __( 'Install an SEO plugin (Yoast, Rank Math, AIOSEO) and add meta descriptions.', 'ecomm-user-tracker' ) );

		set_transient( 'ect_ai_readiness', $checks, DAY_IN_SECONDS );
		return $checks;
	}
}
