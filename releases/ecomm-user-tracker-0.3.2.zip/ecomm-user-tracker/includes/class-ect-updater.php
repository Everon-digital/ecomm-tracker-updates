<?php
/**
 * Self-hosted updates: WordPress checks a small JSON file (ECT_UPDATE_URL) and
 * installs new versions like any wordpress.org plugin. Auto-update is on by default.
 *
 * JSON format: see docs/UPDATES.md in the project repo.
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Updater {

	const CACHE_KEY = 'ect_update_info';

	public static function init() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'check' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'info' ), 20, 3 );
		add_filter( 'auto_update_plugin', array( __CLASS__, 'auto_update' ), 10, 2 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'clear' ), 10, 0 );
		// Dashboard → Updates → "Check again" should fetch fresh info.
		add_action( 'load-update-core.php', array( __CLASS__, 'maybe_force_check' ) );
	}

	private static function basename() {
		return plugin_basename( ECT_FILE );
	}

	private static function remote() {
		$info = get_transient( self::CACHE_KEY );
		if ( false !== $info ) {
			return $info ? $info : null;
		}
		$res  = wp_remote_get( ECT_UPDATE_URL, array( 'timeout' => 10, 'headers' => array( 'Accept' => 'application/json' ) ) );
		$info = null;
		if ( ! is_wp_error( $res ) && 200 === wp_remote_retrieve_response_code( $res ) ) {
			$json = json_decode( wp_remote_retrieve_body( $res ), true );
			if ( is_array( $json ) && ! empty( $json['version'] ) && ! empty( $json['download_url'] ) ) {
				$info = $json;
			}
		}
		set_transient( self::CACHE_KEY, $info ? $info : 0, $info ? 6 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
		return $info;
	}

	public static function check( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$info = self::remote();
		if ( ! $info ) {
			return $transient;
		}
		$item = (object) array(
			'id'           => self::basename(),
			'slug'         => 'ecomm-user-tracker',
			'plugin'       => self::basename(),
			'new_version'  => $info['version'],
			'url'          => 'https://everon.digital/',
			'package'      => $info['download_url'],
			'tested'       => isset( $info['tested'] ) ? $info['tested'] : '',
			'requires'     => isset( $info['requires'] ) ? $info['requires'] : '',
			'requires_php' => isset( $info['requires_php'] ) ? $info['requires_php'] : '',
			'icons'        => array(),
		);
		if ( version_compare( $info['version'], ECT_VERSION, '>' ) ) {
			$transient->response[ self::basename() ] = $item;
		} else {
			$transient->no_update[ self::basename() ] = $item;
		}
		return $transient;
	}

	public static function info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || 'ecomm-user-tracker' !== $args->slug ) {
			return $result;
		}
		$info = self::remote();
		if ( ! $info ) {
			return $result;
		}
		return (object) array(
			'name'          => 'Ecomm User Tracker',
			'slug'          => 'ecomm-user-tracker',
			'version'       => $info['version'],
			'author'        => '<a href="https://everon.digital/">Everon Digital</a>',
			'homepage'      => 'https://everon.digital/',
			'requires'      => isset( $info['requires'] ) ? $info['requires'] : '',
			'tested'        => isset( $info['tested'] ) ? $info['tested'] : '',
			'requires_php'  => isset( $info['requires_php'] ) ? $info['requires_php'] : '',
			'download_link' => $info['download_url'],
			'sections'      => array(
				'description' => 'Live visitors and countries for WordPress & WooCommerce.',
				'changelog'   => isset( $info['changelog'] ) ? wp_kses_post( $info['changelog'] ) : '',
			),
		);
	}

	public static function auto_update( $update, $item ) {
		if ( isset( $item->plugin ) && self::basename() === $item->plugin ) {
			return (bool) ect_get_option( 'auto_update' );
		}
		return $update;
	}

	public static function maybe_force_check() {
		if ( isset( $_GET['force-check'] ) && current_user_can( 'update_plugins' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			self::clear();
		}
	}

	public static function clear() {
		delete_transient( self::CACHE_KEY );
	}
}
