<?php
/**
 * Removes plugin data only if the admin enabled "Delete all plugin data".
 *
 * @package EcommUserTracker
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$ect_opts = get_option( 'ect_settings', array() );
if ( isset( $ect_opts['delete_data'] ) && ! $ect_opts['delete_data'] ) {
	return;
}

global $wpdb;
foreach ( array( 'ect_visitors', 'ect_sessions', 'ect_pageviews', 'ect_events', 'ect_bots' ) as $ect_table ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$ect_table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}
$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_ect_session'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}wc_orders_meta'" ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$wpdb->query( "DELETE FROM {$wpdb->prefix}wc_orders_meta WHERE meta_key = '_ect_session'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}
foreach ( array( 'ect_settings', 'ect_db_version', 'ect_geo_updated', 'ect_mig_014', 'ect_license' ) as $ect_opt ) {
	delete_option( $ect_opt );
}
delete_transient( 'ect_update_info' );
delete_transient( 'ect_ai_readiness' );

$ect_up  = wp_upload_dir( null, false );
$ect_dir = trailingslashit( $ect_up['basedir'] ) . 'ecomm-user-tracker/';
foreach ( (array) glob( $ect_dir . '{*,.htaccess}', GLOB_BRACE ) as $ect_file ) {
	if ( is_file( $ect_file ) ) {
		@unlink( $ect_file ); // phpcs:ignore
	}
}
@rmdir( $ect_dir ); // phpcs:ignore
