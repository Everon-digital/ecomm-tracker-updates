<?php
/**
 * Database table, cron jobs and queries.
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_DB {

	const DB_VERSION = '1';

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'ect_visitors';
	}

	public static function activate() {
		self::create_table();
		if ( ! wp_next_scheduled( 'ect_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'ect_cleanup' );
		}
		if ( ! wp_next_scheduled( 'ect_geo_update' ) ) {
			wp_schedule_event( time() + 60, 'daily', 'ect_geo_update' );
		}
		// First geo download happens shortly after activation so activation itself stays fast.
		wp_schedule_single_event( time() + 5, 'ect_geo_update' );
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'ect_cleanup' );
		wp_clear_scheduled_hook( 'ect_geo_update' );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'ect_db_version' ) !== self::DB_VERSION ) {
			self::activate();
		}
	}

	private static function create_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		// One row per visitor (hashed, rotates daily). No IP, no personal data.
		dbDelta(
			"CREATE TABLE {$table} (
				visitor CHAR(32) NOT NULL,
				country CHAR(2) NOT NULL DEFAULT '',
				page VARCHAR(255) NOT NULL DEFAULT '',
				first_seen INT UNSIGNED NOT NULL,
				last_seen INT UNSIGNED NOT NULL,
				hits INT UNSIGNED NOT NULL DEFAULT 1,
				PRIMARY KEY  (visitor),
				KEY last_seen (last_seen)
			) {$charset};"
		);
		update_option( 'ect_db_version', self::DB_VERSION );
	}

	public static function cleanup() {
		global $wpdb;
		$table = self::table();
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE last_seen < %d", time() - ECT_RETENTION ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * @return bool True if a new visitor row was created.
	 */
	public static function touch( $visitor, $page, $country_cb ) {
		global $wpdb;
		$table = self::table();
		$now   = time();

		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET last_seen = %d, page = %s, hits = hits + 1 WHERE visitor = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$now,
				$page,
				$visitor
			)
		);
		if ( $updated ) {
			return false;
		}
		$wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$table} (visitor, country, page, first_seen, last_seen) VALUES (%s, %s, %s, %d, %d)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$visitor,
				call_user_func( $country_cb ),
				$page,
				$now,
				$now
			)
		);
		return true;
	}

	public static function live_stats() {
		global $wpdb;
		$table = self::table();
		$since = time() - ECT_LIVE_WINDOW;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT country, COUNT(*) AS c FROM {$table} WHERE last_seen >= %d GROUP BY country ORDER BY c DESC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$since
			),
			ARRAY_A
		);
		$total     = 0;
		$countries = array();
		foreach ( (array) $rows as $r ) {
			$total      += (int) $r['c'];
			$countries[] = array(
				'code'  => $r['country'] ? $r['country'] : 'XX',
				'count' => (int) $r['c'],
			);
		}
		return array(
			'live'      => $total,
			'countries' => $countries,
			'time'      => time(),
		);
	}
}
