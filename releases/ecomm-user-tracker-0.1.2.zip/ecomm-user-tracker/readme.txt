=== Ecomm User Tracker ===
Contributors: everondigital
Tags: analytics, live visitors, woocommerce, real-time, statistics
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.1.2
License: GPLv2 or later

Live visitors and their countries for WordPress & WooCommerce. Lightweight and privacy-friendly — data stays on your own site.

== Description ==

* Live visitors count (last 5 minutes)
* Live visitors by country (with flags)
* Dashboard widget
* No cookies, no IP storage, data auto-deleted after 24 hours
* Pro / Pro+ / Agency unlock traffic sources (incl. AI tools), pages, orders, funnels, reports and more

IP geolocation by DB-IP (https://db-ip.com), CC BY 4.0.

== Changelog ==

= 0.1.2 =
* Dashboard → Updates → "Check again" now fetches the latest plugin version immediately.

= 0.1.1 =
* Live visitors appear right away on sites using LiteSpeed Cache, WP Rocket, Autoptimize and similar (tracker excluded from JS delay/defer).
* Admin live view refreshes every 10 seconds.

= 0.1.0 =
* First release: live visitors + countries, admin menu, dashboard widget, self-hosted auto-updates.
