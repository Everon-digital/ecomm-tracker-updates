/* Ecomm User Tracker — tiny heartbeat tracker. No cookies; random ID in localStorage. */
(function () {
	var cfg = window.ectCfg;
	if (!cfg || !window.fetch) return;
	if (cfg.dnt && (navigator.doNotTrack === '1' || window.doNotTrack === '1')) return;
	if (navigator.webdriver) return;

	function id() {
		var k = 'ect_vid', v;
		try { v = localStorage.getItem(k); } catch (e) {}
		if (!v || !/^[a-zA-Z0-9]{16,40}$/.test(v)) {
			var a = new Uint8Array(16);
			(window.crypto || window.msCrypto).getRandomValues(a);
			v = Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
			try { localStorage.setItem(k, v); } catch (e) {}
		}
		return v;
	}

	var vid = id();
	var timer = null;

	function send() {
		var body = JSON.stringify({ v: vid, p: location.pathname });
		if (navigator.sendBeacon) {
			if (navigator.sendBeacon(cfg.endpoint, new Blob([body], { type: 'application/json' }))) return;
		}
		fetch(cfg.endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body, keepalive: true, credentials: 'omit' }).catch(function () {});
	}

	function start() {
		if (timer) return;
		send();
		timer = setInterval(send, (cfg.interval || 30) * 1000);
	}
	function stop() {
		clearInterval(timer);
		timer = null;
	}

	document.addEventListener('visibilitychange', function () {
		document.hidden ? stop() : start();
	});
	if (!document.hidden) start();
})();
