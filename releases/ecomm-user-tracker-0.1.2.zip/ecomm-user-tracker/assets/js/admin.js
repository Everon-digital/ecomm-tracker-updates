/* Ecomm User Tracker — admin live widget. */
(function () {
	var cfg = window.ectAdmin;
	var boxes = document.querySelectorAll('[data-ect-live]');
	if (!cfg || !boxes.length) return;

	var names = null;
	try { names = new Intl.DisplayNames([cfg.locale, 'en'], { type: 'region' }); } catch (e) {}

	function flag(code) {
		if (!/^[A-Z]{2}$/.test(code) || code === 'XX') return '🌐';
		return String.fromCodePoint.apply(null, code.split('').map(function (c) { return 127397 + c.charCodeAt(0); }));
	}
	function countryName(code) {
		if (code === 'XX' || !code) return cfg.i18n.unknown;
		try { return names ? names.of(code) : code; } catch (e) { return code; }
	}

	function render(data) {
		boxes.forEach(function (box) {
			box.querySelector('[data-ect-count]').textContent = data.live;
			var list = box.querySelector('[data-ect-countries]');
			var empty = box.querySelector('[data-ect-empty]');
			if (list) {
				list.innerHTML = '';
				var max = data.countries.length ? data.countries[0].count : 1;
				data.countries.forEach(function (c) {
					var li = document.createElement('li');
					var label = document.createElement('span');
					label.className = 'ect-c-name';
					label.textContent = flag(c.code) + ' ' + countryName(c.code);
					var num = document.createElement('strong');
					num.textContent = c.count;
					var bar = document.createElement('i');
					bar.style.width = Math.max(4, Math.round((c.count / max) * 100)) + '%';
					li.appendChild(label);
					li.appendChild(num);
					li.appendChild(bar);
					list.appendChild(li);
				});
			}
			if (empty) empty.style.display = data.live ? 'none' : '';
			var upd = box.querySelector('[data-ect-updated]');
			if (upd) upd.textContent = cfg.i18n.updated + ' ' + new Date().toLocaleTimeString();
		});
	}

	function load() {
		if (document.hidden) return;
		fetch(cfg.endpoint, { headers: { 'X-WP-Nonce': cfg.nonce }, credentials: 'same-origin', cache: 'no-store' })
			.then(function (r) { return r.ok ? r.json() : null; })
			.then(function (d) { if (d) render(d); })
			.catch(function () {});
	}

	load();
	setInterval(load, 10000);
	document.addEventListener('visibilitychange', load);
})();
