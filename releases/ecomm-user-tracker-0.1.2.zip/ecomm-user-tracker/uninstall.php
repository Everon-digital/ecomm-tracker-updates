<?php
/**
 * Removes plugin data only if the admin enabled "Delete all plugin data".
 *
 * @package EcommUserTracker
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$ect_opts = get_option( 'ect_settings', array() );
if ( empty( $ect_opts['delete_data'] ) ) {
	return;
}

global $wpdb;
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ect_visitors" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
foreach ( array( 'ect_settings', 'ect_db_version', 'ect_geo_updated' ) as $ect_opt ) {
	delete_option( $ect_opt );
}
delete_transient( 'ect_update_info' );

$ect_up  = wp_upload_dir( null, false );
$ect_dir = trailingslashit( $ect_up['basedir'] ) . 'ecomm-user-tracker/';
foreach ( (array) glob( $ect_dir . '{*,.htaccess}', GLOB_BRACE ) as $ect_file ) {
	if ( is_file( $ect_file ) ) {
		@unlink( $ect_file ); // phpcs:ignore
	}
}
@rmdir( $ect_dir ); // phpcs:ignore
