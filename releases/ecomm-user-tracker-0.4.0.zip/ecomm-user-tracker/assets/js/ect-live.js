/* Ecomm User Tracker — lightweight visit tracker. */
(function () {
	var cfg = window.ectCfg;
	if (!cfg || !window.fetch) return;
	if (cfg.dnt && (navigator.doNotTrack === '1' || window.doNotTrack === '1')) return;
	if (navigator.webdriver) return;

	var ID_RE = /^[a-zA-Z0-9]{16,40}$/;
	function rnd() {
		var a = new Uint8Array(16);
		(window.crypto || window.msCrypto).getRandomValues(a);
		return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
	}
	function get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
	function set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

	var vid = get('ect_vid');
	if (!vid || !ID_RE.test(vid)) { vid = rnd(); set('ect_vid', vid); }

	// A visit (session) ends after 30 minutes without activity.
	var sid = null;
	function session() {
		var now = Date.now(), cur = get('ect_sid'), last = +get('ect_sid_t') || 0;
		if (!cur || !ID_RE.test(cur) || now - last > 30 * 60 * 1000) cur = rnd();
		set('ect_sid', cur);
		set('ect_sid_t', String(now));
		if (cfg.pro) document.cookie = 'ect_sid=' + cur + ';path=/;SameSite=Lax' + (location.protocol === 'https:' ? ';Secure' : '');
		return cur;
	}

	function params() {
		var out = {}, keys = ['utm_source', 'utm_medium', 'utm_campaign', 'gclid', 'gbraid', 'wbraid', 'msclkid', 'fbclid', 'ttclid'];
		try {
			var sp = new URLSearchParams(location.search);
			keys.forEach(function (k) { if (sp.get(k)) out[k] = sp.get(k).slice(0, 100); });
		} catch (e) {}
		return out;
	}

	// Pro+: forms are recognised by type (contact, checkout, account, newsletter…).
	function formType(f) {
		if (!f || f.tagName !== 'FORM') return '';
		var id = ((f.id || '') + ' ' + (f.className || '') + ' ' + (f.getAttribute('name') || '') + ' ' + (f.getAttribute('action') || '')).toLowerCase();
		if (f.matches('[role=search],.search-form,.searchform,#adminbarsearch') || f.querySelector('input[type=search],input[name=s]')) return '';
		if (f.matches('form.cart,.variations_form,.woocommerce-cart-form,.checkout_coupon,.woocommerce-form-coupon,.woocommerce-ordering') || /(^|\s)v?form-\d/.test(id) && f.querySelector('[name^=attribute_],[name=add-to-cart],[name=quantity]')) return '';
		if (f.querySelector('[name=add-to-cart],[name^=attribute_]')) return '';
		if (f.matches('form.checkout,.woocommerce-checkout') || f.querySelector('[name^=billing_],[name^=shipping_first]')) return 'checkout';
		if (f.querySelector('input[type=password]')) {
			return /regist|signup|sign-up|create|join/.test(id) || f.querySelectorAll('input[type=password]').length > 1 ? 'signup' : 'login';
		}
		if (/newsletter|subscri|mailchimp|mc4wp|klaviyo/.test(id)) return 'newsletter';
		if (f.querySelector('textarea') || /contact|enquir|inquir|message|support/.test(id)) return 'contact';
		var fields = f.querySelectorAll('input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=checkbox])');
		if (fields.length <= 2 && f.querySelector('input[type=email],[name*=email]')) return 'newsletter';
		return 'other';
	}
	function trackable(f) {
		var t = formType(f);
		return t && (cfg.forms || []).indexOf(t === 'signup' || t === 'login' ? 'account' : t) !== -1;
	}
	function formKey(f) {
		var t = formType(f);
		return t === 'checkout' ? 'checkout' : (t + ' · ' + location.pathname).slice(0, 180);
	}
	function forms() {
		var seen = [];
		Array.prototype.forEach.call(document.forms, function (f) {
			if (trackable(f) && seen.indexOf(formKey(f)) === -1) seen.push(formKey(f));
		});
		return seen.slice(0, 5);
	}

	function send(e, extra) {
		sid = session();
		var data = { v: vid, s: sid, e: e, p: location.pathname };
		if (e === 'pv') {
			data.r = document.referrer || '';
			data.q = params();
			if (cfg.events) {
				data.pt = cfg.pt || '';
				if (cfg.pt === 'product') data.l = (document.querySelector('.product_title, h1') || {}).textContent || document.title;
				data.f = forms();
			}
		}
		if (extra) for (var k in extra) data[k] = extra[k];
		var body = JSON.stringify(data);
		if (navigator.sendBeacon && navigator.sendBeacon(cfg.endpoint, new Blob([body], { type: 'application/json' }))) return;
		fetch(cfg.endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body, keepalive: true, credentials: 'omit' }).catch(function () {});
	}

	var timer = null, sentPv = false;
	function start() {
		if (timer) return;
		send(sentPv ? 'hb' : 'pv');
		sentPv = true;
		timer = setInterval(function () { send('hb'); }, (cfg.interval || 30) * 1000);
	}
	function stop() { clearInterval(timer); timer = null; }

	document.addEventListener('visibilitychange', function () { document.hidden ? stop() : start(); });

	if (cfg.events) {
		// Button / link clicks.
		document.addEventListener('click', function (ev) {
			var el = ev.target && ev.target.closest && ev.target.closest('a,button,[role=button],input[type=submit],input[type=button]');
			if (!el) return;
			var href = (el.getAttribute('href') || '').toLowerCase();
			var ct = href.indexOf('tel:') === 0 ? 'Phone' : href.indexOf('mailto:') === 0 ? 'Email' : /wa\.me\/|whatsapp\.com\/|^whatsapp:/.test(href) ? 'WhatsApp' : /^sms:/.test(href) ? 'SMS' : /t\.me\/|^viber:|^skype:/.test(href) ? 'Messenger' : '';
			if (ct) send('ct', { l: ct });
			var label = (el.getAttribute('aria-label') || el.innerText || el.value || el.title || '').replace(/\s+/g, ' ').trim().slice(0, 60);
			if (label) send('ck', { l: label });
		}, true);
		// Forms: started (first field focused) and submitted.
		var started = [];
		document.addEventListener('focusin', function (ev) {
			var f = ev.target && ev.target.form;
			if (!trackable(f) || started.indexOf(f) !== -1) return;
			started.push(f);
			send('fs', { l: formKey(f) });
		}, true);
		document.addEventListener('submit', function (ev) {
			if (trackable(ev.target) && formType(ev.target) !== 'checkout') send('fx', { l: formKey(ev.target) });
		}, true);
	}
	if (!document.hidden) start();
})();
