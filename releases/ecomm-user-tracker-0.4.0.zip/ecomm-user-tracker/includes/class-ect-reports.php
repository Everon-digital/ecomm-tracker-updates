<?php
/**
 * Report queries for the admin pages (Pro and up).
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

class ECT_Reports {

	/** @var int */
	public $from;
	/** @var int */
	public $to;
	/** @var int */
	public $days;

	public function __construct( $days ) {
		$this->days = max( 1, (int) $days );
		$this->to   = time();
		$this->from = 1 === $this->days ? ( new DateTime( 'today', wp_timezone() ) )->getTimestamp() : $this->to - $this->days * DAY_IN_SECONDS;
	}

	/** Custom period between two timestamps (inclusive). */
	public static function between( $from, $to ) {
		$r       = new self( 1 );
		$r->from = (int) $from;
		$r->to   = (int) $to;
		$r->days = max( 1, (int) ceil( ( $r->to - $r->from ) / DAY_IN_SECONDS ) );
		return $r;
	}

	private function range_sql( $col = 'started' ) {
		global $wpdb;
		return $wpdb->prepare( "{$col} BETWEEN %d AND %d", $this->from, $this->to );
	}

	/** Same-length period right before this one, for "% change". */
	public function previous() {
		$p       = clone $this;
		$len     = $this->to - $this->from;
		$p->to   = $this->from - 1;
		$p->from = $this->from - $len;
		return $p;
	}

	public function totals() {
		global $wpdb;
		$t   = ECT_DB::sessions();
		$row = $wpdb->get_row(
			"SELECT COUNT(*) AS sessions, COUNT(DISTINCT visitor) AS visitors, COALESCE(SUM(pageviews),0) AS pageviews,
				COALESCE(AVG(last_seen - started),0) AS duration,
				COALESCE(SUM(CASE WHEN pageviews <= 1 AND last_seen - started < 10 THEN 1 ELSE 0 END),0) AS bounces
			FROM {$t} WHERE " . $this->range_sql(),
			ARRAY_A
		);
		$row             = array_map( 'floatval', (array) $row );
		$row['bounce']   = $row['sessions'] ? round( 100 * $row['bounces'] / $row['sessions'], 1 ) : 0;
		$row['per_sess'] = $row['sessions'] ? round( $row['pageviews'] / $row['sessions'], 1 ) : 0;
		return $row;
	}

	/** Sessions per day (or per hour for "Today"). */
	public function series() {
		global $wpdb;
		$t      = ECT_DB::sessions();
		$offset = (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
		$bucket = 1 === $this->days ? HOUR_IN_SECONDS : DAY_IN_SECONDS;
		$rows   = $wpdb->get_results(
			$wpdb->prepare( "SELECT FLOOR((started + %d) / %d) AS b, COUNT(*) AS c FROM {$t} WHERE " . $this->range_sql() . ' GROUP BY b', $offset, $bucket ),
			ARRAY_A
		);
		$map = array();
		foreach ( (array) $rows as $r ) {
			$map[ (int) $r['b'] ] = (int) $r['c'];
		}
		$out   = array();
		$start = (int) floor( ( $this->from + $offset ) / $bucket );
		$end   = (int) floor( ( $this->to + $offset ) / $bucket );
		for ( $b = $start; $b <= $end; $b++ ) {
			$ts    = $b * $bucket - $offset;
			$out[] = array(
				'label' => 1 === $this->days ? wp_date( 'H:00', $ts ) : wp_date( 'M j', $ts ),
				'value' => isset( $map[ $b ] ) ? $map[ $b ] : 0,
			);
		}
		return $out;
	}

	public function by( $column, $limit = 10 ) {
		global $wpdb;
		$allowed = array( 'country', 'device', 'entry_page', 'exit_page', 'browser', 'os' );
		if ( ! in_array( $column, $allowed, true ) ) {
			return array();
		}
		$t = ECT_DB::sessions();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT {$column} AS k, COUNT(*) AS c FROM {$t} WHERE " . $this->range_sql() . " GROUP BY {$column} ORDER BY c DESC LIMIT %d", $limit ),
			ARRAY_A
		);
	}

	public function sources( $limit = 10 ) {
		global $wpdb;
		$t    = ECT_DB::sessions();
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT channel, source, COUNT(*) AS c FROM {$t} WHERE " . $this->range_sql() . ' GROUP BY channel, source ORDER BY c DESC LIMIT %d', $limit ),
			ARRAY_A
		);
		foreach ( $rows as &$r ) {
			$r['k'] = ECT_Source::label( $r['channel'], $r['source'] );
		}
		return $rows;
	}

	public function top_pages( $limit = 10 ) {
		global $wpdb;
		$p = ECT_DB::pageviews();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT path AS k, COUNT(*) AS c FROM {$p} WHERE " . $this->range_sql( 'ts' ) . ' GROUP BY path ORDER BY c DESC LIMIT %d', $limit ),
			ARRAY_A
		);
	}

	/** Exit rate per page = sessions that ended on the page / page views of the page. */
	public function exit_pages( $limit = 10 ) {
		global $wpdb;
		$s     = ECT_DB::sessions();
		$p     = ECT_DB::pageviews();
		$exits = $this->by( 'exit_page', $limit );
		foreach ( $exits as &$r ) {
			$views     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p} WHERE path = %s AND " . $this->range_sql( 'ts' ), $r['k'] ) );
			$r['rate'] = $views ? min( 100, round( 100 * $r['c'] / $views ) ) : 0;
		}
		unset( $s );
		return $exits;
	}

	/** Average sessions per weekday (0 = Sunday). */
	public function weekdays() {
		global $wpdb;
		$t      = ECT_DB::sessions();
		$offset = (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
		$rows   = (array) $wpdb->get_results( "SELECT started FROM {$t} WHERE " . $this->range_sql() );
		$counts = array_fill( 0, 7, 0 );
		foreach ( $rows as $r ) {
			$counts[ (int) gmdate( 'w', $r->started + $offset ) ]++;
		}
		$weeks = max( 1, $this->days / 7 );
		return array_map(
			function ( $c ) use ( $weeks ) {
				return round( $c / $weeks, 1 );
			},
			$counts
		);
	}

	/* ---------------- Real-time ---------------- */

	public static function recent_sessions( $limit = 10 ) {
		global $wpdb;
		$t = ECT_DB::sessions();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT id, started, last_seen, pageviews, exit_page, channel, source, device, country, stage FROM {$t} WHERE last_seen >= %d ORDER BY last_seen DESC LIMIT %d", time() - 30 * MINUTE_IN_SECONDS, $limit ),
			ARRAY_A
		);
	}

	public static function recent_pageviews( $limit = 15 ) {
		global $wpdb;
		$s = ECT_DB::sessions();
		$p = ECT_DB::pageviews();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT p.path, p.ts, s.id AS sid, s.country, s.device FROM {$p} p JOIN {$s} s ON s.id = p.session_id WHERE p.ts >= %d ORDER BY p.ts DESC LIMIT %d", time() - DAY_IN_SECONDS, $limit ),
			ARRAY_A
		);
	}

	/** Page views plus store events (add to cart, checkout, purchase), newest first. */
	public static function recent_activity( $limit = 12 ) {
		global $wpdb;
		$s     = ECT_DB::sessions();
		$p     = ECT_DB::pageviews();
		$e     = ECT_DB::events();
		$since = time() - DAY_IN_SECONDS;
		$rows  = (array) $wpdb->get_results( $wpdb->prepare( "SELECT 'pv' AS type, p.path AS label, p.ts, s.id AS sid, s.country FROM {$p} p JOIN {$s} s ON s.id = p.session_id WHERE p.ts >= %d ORDER BY p.ts DESC LIMIT %d", $since, $limit ), ARRAY_A );
		$ev    = ! ECT_License::has( 'proplus' ) ? array() : (array) $wpdb->get_results( $wpdb->prepare( "SELECT ev.type, ev.label, ev.page, ev.ts, s.id AS sid, s.country, ev.value FROM {$e} ev JOIN {$s} s ON s.id = ev.session_id WHERE ev.ts >= %d AND ev.type IN ('click','add_to_cart','checkout','purchase','form_submit') ORDER BY ev.ts DESC LIMIT %d", $since, $limit ), ARRAY_A );
		$rows  = array_merge( $rows, $ev );
		usort(
			$rows,
			function ( $a, $b ) {
				return $b['ts'] <=> $a['ts'];
			}
		);
		$rows = array_slice( $rows, 0, $limit );
		foreach ( $rows as &$r ) {
			/* translators: %d: visitor number */
			$who = sprintf( __( 'Visitor #%d', 'ecomm-user-tracker' ), $r['sid'] );
			switch ( $r['type'] ) {
				case 'click':
					/* translators: 1: visitor, 2: button text, 3: page */
					$r['text'] = sprintf( __( '🖱 %1$s clicked “%2$s” on %3$s', 'ecomm-user-tracker' ), $who, $r['label'], $r['page'] );
					break;
				case 'add_to_cart':
					/* translators: 1: visitor, 2: product */
					$r['text'] = sprintf( __( '🛒 %1$s added %2$s to cart', 'ecomm-user-tracker' ), $who, $r['label'] );
					break;
				case 'checkout':
					/* translators: %s: visitor */
					$r['text'] = sprintf( __( '💳 %s reached checkout', 'ecomm-user-tracker' ), $who );
					break;
				case 'purchase':
					/* translators: 1: visitor, 2: amount */
					$r['text'] = sprintf( __( '✅ %1$s purchased %2$s', 'ecomm-user-tracker' ), $who, function_exists( 'wc_price' ) ? html_entity_decode( wp_strip_all_tags( wc_price( $r['value'] ) ) ) : $r['value'] );
					break;
				case 'form_submit':
					/* translators: %s: visitor */
					$r['text'] = sprintf( __( '📝 %s submitted a form', 'ecomm-user-tracker' ), $who );
					break;
				default:
					/* translators: 1: visitor, 2: page */
					$r['text'] = sprintf( __( '%1$s viewed %2$s', 'ecomm-user-tracker' ), $who, $r['label'] );
			}
		}
		return $rows;
	}

	/** One visit with every page and action, plus the visitor's earlier visits. */
	public static function visit( $id ) {
		global $wpdb;
		$s   = ECT_DB::sessions();
		$p   = ECT_DB::pageviews();
		$e   = ECT_DB::events();
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$s} WHERE id = %d", $id ), ARRAY_A );
		if ( ! $row ) {
			return null;
		}
		$steps = (array) $wpdb->get_results( $wpdb->prepare( "SELECT 'pv' AS type, path AS label, path AS page, ts, dur, 0 AS value FROM {$p} WHERE session_id = %d", $id ), ARRAY_A );
		if ( ECT_License::has( 'proplus' ) ) {
			$steps = array_merge( $steps, (array) $wpdb->get_results( $wpdb->prepare( "SELECT type, label, page, ts, 0 AS dur, value FROM {$e} WHERE session_id = %d AND type <> 'form_view' AND type <> 'product_view'", $id ), ARRAY_A ) );
		}
		usort(
			$steps,
			function ( $a, $b ) {
				return $a['ts'] <=> $b['ts'] ?: ( 'pv' === $a['type'] ? -1 : 1 );
			}
		);
		$past = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, started, pageviews, channel, source, stage FROM {$s} WHERE visitor = %s AND id <> %d ORDER BY started DESC LIMIT 10", $row['visitor'], $id ), ARRAY_A );
		return array(
			'session' => $row,
			'steps'   => $steps,
			'past'    => $past,
		);
	}

	public static function last30() {
		global $wpdb;
		$t = ECT_DB::sessions();
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE last_seen >= %d", time() - 30 * MINUTE_IN_SECONDS ) );
	}

	public static function live_breakdown( $column ) {
		global $wpdb;
		if ( ! in_array( $column, array( 'device', 'exit_page' ), true ) ) {
			return array();
		}
		$t = ECT_DB::sessions();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT {$column} AS k, COUNT(*) AS c FROM {$t} WHERE last_seen >= %d GROUP BY {$column} ORDER BY c DESC LIMIT 8", time() - ECT_LIVE_WINDOW ),
			ARRAY_A
		);
	}

	public static function live_sources() {
		global $wpdb;
		$t    = ECT_DB::sessions();
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT channel, source, COUNT(*) AS c FROM {$t} WHERE last_seen >= %d GROUP BY channel, source ORDER BY c DESC LIMIT 8", time() - ECT_LIVE_WINDOW ),
			ARRAY_A
		);
		foreach ( $rows as &$r ) {
			$r['k'] = ECT_Source::label( $r['channel'], $r['source'] );
		}
		return $rows;
	}

	public function new_returning() {
		global $wpdb;
		$t   = ECT_DB::sessions();
		$row = $wpdb->get_row( "SELECT COUNT(DISTINCT CASE WHEN is_new = 1 THEN visitor END) AS n, COUNT(DISTINCT CASE WHEN is_new = 0 THEN visitor END) AS r FROM {$t} WHERE " . $this->range_sql(), ARRAY_A );
		return array(
			array( 'k' => __( 'New', 'ecomm-user-tracker' ), 'c' => (int) $row['n'] ),
			array( 'k' => __( 'Returning', 'ecomm-user-tracker' ), 'c' => (int) $row['r'] ),
		);
	}

	public function time_on_page( $limit = 10 ) {
		global $wpdb;
		$p = ECT_DB::pageviews();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT path AS k, AVG(dur) AS c, COUNT(*) AS views FROM {$p} WHERE dur > 0 AND " . $this->range_sql( 'ts' ) . ' GROUP BY path HAVING views >= 1 ORDER BY views DESC LIMIT %d', $limit ),
			ARRAY_A
		);
	}

	public function events_by( $type, $limit = 10 ) {
		global $wpdb;
		$e = ECT_DB::events();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT label AS k, COUNT(*) AS c FROM {$e} WHERE type = %s AND " . $this->range_sql( 'ts' ) . ' GROUP BY label ORDER BY c DESC LIMIT %d', $type, $limit ),
			ARRAY_A
		);
	}

	public function clicks_by_page( $limit = 20 ) {
		global $wpdb;
		$e = ECT_DB::events();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT label AS k, page, COUNT(*) AS c FROM {$e} WHERE type = 'click' AND " . $this->range_sql( 'ts' ) . ' GROUP BY label, page ORDER BY c DESC LIMIT %d', $limit ),
			ARRAY_A
		);
	}

	/** Store funnel: sessions → viewed product → added to cart → reached checkout → purchased. */
	public function funnel() {
		global $wpdb;
		$t   = ECT_DB::sessions();
		$row = $wpdb->get_row(
			"SELECT COUNT(*) AS s, SUM(stage >= 1) AS v, SUM(stage >= 2) AS a, SUM(stage >= 3) AS c, SUM(stage >= 4) AS p FROM {$t} WHERE " . $this->range_sql(),
			ARRAY_A
		);
		return array(
			array( 'k' => __( 'Site sessions', 'ecomm-user-tracker' ), 'c' => (int) $row['s'] ),
			array( 'k' => __( 'Viewed product', 'ecomm-user-tracker' ), 'c' => (int) $row['v'] ),
			array( 'k' => __( 'Added to cart', 'ecomm-user-tracker' ), 'c' => (int) $row['a'] ),
			array( 'k' => __( 'Reached checkout', 'ecomm-user-tracker' ), 'c' => (int) $row['c'] ),
			array( 'k' => __( 'Purchased', 'ecomm-user-tracker' ), 'c' => (int) $row['p'] ),
		);
	}

	public function abandoned( $limit = 10 ) {
		global $wpdb;
		$t     = ECT_DB::sessions();
		$e     = ECT_DB::events();
		$cond  = function ( $a ) {
			return "{$a}stage IN (2,3) AND {$a}last_seen < " . (int) ( time() - HOUR_IN_SECONDS ) . " AND {$a}" . $this->range_sql();
		};
		$where = $cond( '' );
		$sum   = $wpdb->get_row( "SELECT COUNT(*) AS n, COALESCE(SUM(cart_value),0) AS v FROM {$t} WHERE {$where}", ARRAY_A );
		$list  = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, last_seen, cart_value, channel, source, country, device FROM {$t} WHERE {$where} ORDER BY last_seen DESC LIMIT %d", $limit ), ARRAY_A );
		$prods = (array) $wpdb->get_results( "SELECT ev.label AS k, COUNT(*) AS c FROM {$e} ev JOIN {$t} s ON s.id = ev.session_id WHERE ev.type = 'add_to_cart' AND " . $cond( 's.' ) . " GROUP BY ev.label ORDER BY c DESC LIMIT 8", ARRAY_A );
		return array(
			'count'    => (int) $sum['n'],
			'value'    => (float) $sum['v'],
			'list'     => $list,
			'products' => $prods,
		);
	}

	/** Sessions and conversion rate per device / browser / OS. */
	public function conversion_by( $column ) {
		global $wpdb;
		if ( ! in_array( $column, array( 'device', 'browser', 'os', 'country' ), true ) ) {
			return array();
		}
		$t    = ECT_DB::sessions();
		$rows = (array) $wpdb->get_results( "SELECT {$column} AS k, COUNT(*) AS c, SUM(stage >= 4) AS p FROM {$t} WHERE " . $this->range_sql() . " GROUP BY {$column} ORDER BY c DESC LIMIT 10", ARRAY_A );
		foreach ( $rows as &$r ) {
			$r['rate'] = $r['c'] ? round( 100 * $r['p'] / $r['c'], 1 ) : 0;
		}
		return $rows;
	}

	/** First 4 pages of each visit: top pages per step and how many dropped off. */
	public function flows() {
		global $wpdb;
		$t     = ECT_DB::sessions();
		$p     = ECT_DB::pageviews();
		$rows  = (array) $wpdb->get_results( "SELECT session_id, path FROM {$p} WHERE session_id IN (SELECT id FROM (SELECT id FROM {$t} WHERE " . $this->range_sql() . ' ORDER BY id DESC LIMIT 3000) x) ORDER BY session_id, id', ARRAY_A );
		$paths = array();
		foreach ( $rows as $r ) {
			$list = isset( $paths[ $r['session_id'] ] ) ? $paths[ $r['session_id'] ] : array();
			if ( count( $list ) < 4 && end( $list ) !== $r['path'] ) {
				$list[] = $r['path'];
			}
			$paths[ $r['session_id'] ] = $list;
		}
		$steps = array();
		for ( $i = 0; $i < 4; $i++ ) {
			$counts = array();
			$total  = 0;
			foreach ( $paths as $list ) {
				if ( isset( $list[ $i ] ) ) {
					$counts[ $list[ $i ] ] = ( isset( $counts[ $list[ $i ] ] ) ? $counts[ $list[ $i ] ] : 0 ) + 1;
					$total++;
				}
			}
			arsort( $counts );
			$prev    = $i ? $steps[ $i - 1 ]['total'] : $total;
			$steps[] = array(
				'total'   => $total,
				'pages'   => array_slice( $counts, 0, 5, true ),
				'dropped' => $i ? max( 0, $prev - $total ) : 0,
				'prev'    => $prev,
			);
		}
		return $steps;
	}

	/** Most common journeys (first 4 pages of a visit), e.g. Home → Shop → Product. */
	public function top_paths( $limit = 8 ) {
		global $wpdb;
		$t     = ECT_DB::sessions();
		$p     = ECT_DB::pageviews();
		$rows  = (array) $wpdb->get_results( "SELECT session_id, path FROM {$p} WHERE session_id IN (SELECT id FROM (SELECT id FROM {$t} WHERE " . $this->range_sql() . ' ORDER BY id DESC LIMIT 3000) x) ORDER BY session_id, id', ARRAY_A );
		$paths = array();
		foreach ( $rows as $r ) {
			$list = isset( $paths[ $r['session_id'] ] ) ? $paths[ $r['session_id'] ] : array();
			// Reloads of the same page are one step.
			if ( count( $list ) < 4 && end( $list ) !== $r['path'] ) {
				$list[] = $r['path'];
			}
			$paths[ $r['session_id'] ] = $list;
		}
		$counts = array();
		foreach ( $paths as $list ) {
			$key            = implode( "\n", $list );
			$counts[ $key ] = ( isset( $counts[ $key ] ) ? $counts[ $key ] : 0 ) + 1;
		}
		arsort( $counts );
		$out = array();
		foreach ( array_slice( $counts, 0, $limit, true ) as $key => $c ) {
			$out[] = array(
				'pages' => explode( "\n", $key ),
				'c'     => $c,
			);
		}
		return array(
			'paths' => $out,
			'total' => count( $paths ),
		);
	}

	/** Form types the site owner chose to track (Settings). */
	public static function form_types() {
		$t = ect_get_option( 'form_types' );
		return is_array( $t ) ? $t : array( 'contact', 'checkout', 'account', 'newsletter' );
	}

	public function forms() {
		global $wpdb;
		$e    = ECT_DB::events();
		$rows = (array) $wpdb->get_results(
			"SELECT label, SUM(type = 'form_view') AS v, SUM(type = 'form_start') AS s, SUM(type = 'form_submit') AS x FROM {$e} WHERE type IN ('form_view','form_start','form_submit') AND " . $this->range_sql( 'ts' ) . ' GROUP BY label ORDER BY x DESC, v DESC LIMIT 200',
			ARRAY_A
		);
		// Only the form types chosen in Settings (labels are "type · /page/").
		$types = self::form_types();
		if ( in_array( 'account', $types, true ) ) {
			$types[] = 'signup';
			$types[] = 'login';
		}
		$rows = array_values(
			array_filter(
				$rows,
				function ( $r ) use ( $types ) {
					$type = strtok( $r['label'], ' ' );
					return in_array( $type, $types, true );
				}
			)
		);
		foreach ( $rows as &$r ) {
			$r['label'] = self::form_label( $r['label'] );
		}
		unset( $r );
		$t       = ECT_DB::sessions();
		$sources = (array) $wpdb->get_results( "SELECT s.channel, s.source, COUNT(*) AS c FROM {$e} ev JOIN {$t} s ON s.id = ev.session_id WHERE ev.type = 'form_submit' AND ev." . $this->range_sql( 'ts' ) . ' GROUP BY s.channel, s.source ORDER BY c DESC LIMIT 8', ARRAY_A );
		foreach ( $sources as &$r ) {
			$r['k'] = ECT_Source::label( $r['channel'], $r['source'] );
		}
		$countries = (array) $wpdb->get_results( "SELECT s.country AS k, COUNT(*) AS c FROM {$e} ev JOIN {$t} s ON s.id = ev.session_id WHERE ev.type = 'form_submit' AND ev." . $this->range_sql( 'ts' ) . ' GROUP BY s.country ORDER BY c DESC LIMIT 8', ARRAY_A );
		return array(
			'forms'     => $rows,
			'sources'   => $sources,
			'countries' => $countries,
		);
	}

	public static function form_label( $raw ) {
		$names = array(
			'contact'    => __( 'Contact form', 'ecomm-user-tracker' ),
			'checkout'   => __( 'Checkout (place order)', 'ecomm-user-tracker' ),
			'signup'     => __( 'Create account', 'ecomm-user-tracker' ),
			'login'      => __( 'Login', 'ecomm-user-tracker' ),
			'newsletter' => __( 'Newsletter signup', 'ecomm-user-tracker' ),
			'other'      => __( 'Other form', 'ecomm-user-tracker' ),
		);
		$parts = explode( ' · ', $raw, 2 );
		$name  = isset( $names[ $parts[0] ] ) ? $names[ $parts[0] ] : $parts[0];
		return isset( $parts[1] ) && '' !== $parts[1] ? $name . ' · ' . $parts[1] : $name;
	}

	/** Sessions, purchases and revenue per channel. */
	public function channels() {
		global $wpdb;
		$t    = ECT_DB::sessions();
		$e    = ECT_DB::events();
		$rows = (array) $wpdb->get_results(
			"SELECT s.channel, COUNT(*) AS c, SUM(s.stage >= 4) AS p, COALESCE(SUM((SELECT SUM(value) FROM {$e} ev WHERE ev.session_id = s.id AND ev.type = 'purchase')),0) AS rev FROM {$t} s WHERE s." . $this->range_sql() . ' GROUP BY s.channel ORDER BY c DESC',
			ARRAY_A
		);
		$names = self::channel_names();
		foreach ( $rows as &$r ) {
			$r['k']    = isset( $names[ $r['channel'] ] ) ? $names[ $r['channel'] ] : $r['channel'];
			$r['rate'] = $r['c'] ? round( 100 * $r['p'] / $r['c'], 1 ) : 0;
		}
		return $rows;
	}

	public static function channel_names() {
		return array(
			'direct'         => __( 'Direct', 'ecomm-user-tracker' ),
			'organic_search' => __( 'Organic search', 'ecomm-user-tracker' ),
			'paid_search'    => __( 'Paid search', 'ecomm-user-tracker' ),
			'organic_social' => __( 'Organic social', 'ecomm-user-tracker' ),
			'paid_social'    => __( 'Paid social', 'ecomm-user-tracker' ),
			'ai'             => __( 'AI platforms', 'ecomm-user-tracker' ),
			'email'          => __( 'Email marketing', 'ecomm-user-tracker' ),
			'referral'       => __( 'Referral', 'ecomm-user-tracker' ),
		);
	}

	public function channel_series( $channel ) {
		global $wpdb;
		$t      = ECT_DB::sessions();
		$offset = (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
		$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT FLOOR((started + %d) / 86400) AS b, COUNT(*) AS c FROM {$t} WHERE channel = %s AND " . $this->range_sql() . ' GROUP BY b', $offset, $channel ), ARRAY_A );
		$map    = array();
		foreach ( (array) $rows as $r ) {
			$map[ (int) $r['b'] ] = (int) $r['c'];
		}
		$out = array();
		for ( $b = (int) floor( ( $this->from + $offset ) / 86400 ); $b <= (int) floor( ( $this->to + $offset ) / 86400 ); $b++ ) {
			$out[] = array(
				'label' => wp_date( 'M j', $b * 86400 - $offset ),
				'value' => isset( $map[ $b ] ) ? $map[ $b ] : 0,
			);
		}
		return $out;
	}

	/** Per AI tool, or per email campaign: sessions, purchases, top landing pages. */
	public function channel_detail( $channel, $group = 'source' ) {
		global $wpdb;
		$col  = 'campaign' === $group ? 'campaign' : 'source';
		$t    = ECT_DB::sessions();
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT {$col} AS k, COUNT(*) AS c, SUM(stage >= 4) AS p FROM {$t} WHERE channel = %s AND " . $this->range_sql() . " GROUP BY {$col} ORDER BY c DESC LIMIT 10", $channel ), ARRAY_A );
		$top  = (array) $wpdb->get_results( $wpdb->prepare( "SELECT entry_page AS k, COUNT(*) AS c FROM {$t} WHERE channel = %s AND " . $this->range_sql() . ' GROUP BY entry_page ORDER BY c DESC LIMIT 8', $channel ), ARRAY_A );
		return array(
			'rows'  => $rows,
			'pages' => $top,
		);
	}

	public function bots( $ai_only = true ) {
		global $wpdb;
		$b    = ECT_DB::bots();
		$from = wp_date( 'Y-m-d', $this->from, new DateTimeZone( 'UTC' ) );
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT bot AS k, SUM(hits) AS c, MAX(day) AS last FROM {$b} WHERE day >= %s AND bot <> '404' GROUP BY bot ORDER BY c DESC", $from ), ARRAY_A );
		if ( $ai_only ) {
			$rows = array_values(
				array_filter(
					$rows,
					function ( $r ) {
						return ! in_array( $r['k'], array( 'Googlebot', 'Bingbot', '404' ), true );
					}
				)
			);
		}
		return $rows;
	}

	public function bot_pages( $limit = 10 ) {
		global $wpdb;
		$b    = ECT_DB::bots();
		$from = wp_date( 'Y-m-d', $this->from, new DateTimeZone( 'UTC' ) );
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT path AS k, SUM(hits) AS c FROM {$b} WHERE day >= %s AND bot NOT IN ('Googlebot','Bingbot','404') GROUP BY path ORDER BY c DESC LIMIT %d", $from, $limit ), ARRAY_A );
	}

	/** AI visibility score 0–100 without any AI API: traffic 40 + crawlers 30 + readiness 30. */
	public function ai_score() {
		$t        = $this->totals();
		$ai       = 0;
		$tools    = 0;
		foreach ( $this->channels() as $c ) {
			if ( 'ai' === $c['channel'] ) {
				$ai = (int) $c['c'];
			}
		}
		$tools    = count( $this->channel_detail( 'ai' )['rows'] );
		$share    = $t['sessions'] ? $ai / $t['sessions'] : 0;
		$traffic  = min( 30, (int) round( $share * 600 ) ) + min( 10, $tools * 3 );
		$bots     = $this->bots();
		$names    = wp_list_pluck( $bots, 'k' );
		$crawl    = min( 18, count( $bots ) * 4 ) + ( array_intersect( $names, ECT_Source::AI_USER_BOTS ) ? 12 : 0 );
		$checks   = ECT_Integrations::readiness();
		$ok       = count( array_filter( wp_list_pluck( $checks, 1 ) ) );
		$ready    = (int) round( 30 * $ok / max( 1, count( $checks ) ) );
		return array(
			'score'     => $traffic + $crawl + $ready,
			'traffic'   => $traffic,
			'crawl'     => $crawl,
			'readiness' => $ready,
			'checks'    => $checks,
			'share'     => round( 100 * $share, 1 ),
		);
	}

	/* ---------------- Live (Pro+) ---------------- */

	public static function snapshot() {
		global $wpdb;
		$t   = ECT_DB::sessions();
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT SUM(stage < 2 AND last_seen >= %d) AS browsing, SUM(stage = 2 AND last_seen >= %d) AS cart, SUM(stage = 3 AND last_seen >= %d) AS checkout, SUM(stage = 4 AND last_seen >= %d) AS bought FROM {$t} WHERE last_seen >= %d", time() - ECT_LIVE_WINDOW, time() - ECT_LIVE_WINDOW, time() - ECT_LIVE_WINDOW, time() - 30 * MINUTE_IN_SECONDS, time() - 30 * MINUTE_IN_SECONDS ),
			ARRAY_A
		);
		return array_map( 'intval', (array) $row );
	}

	/* ---------------- Insights (Agency) ---------------- */

	public function insights() {
		$out  = array();
		$t    = $this->totals();
		$prev = $this->previous()->totals();
		if ( $t['sessions'] < 10 ) {
			return $out;
		}
		foreach ( $this->exit_pages( 5 ) as $p ) {
			if ( $p['c'] >= 5 && $p['rate'] >= 70 ) {
				/* translators: %s: page */
				$out[] = array( 'attention', sprintf( __( 'Many visitors leave your site from %s.', 'ecomm-user-tracker' ), '<b>' . esc_html( $p['k'] ) . '</b>' ), $p['rate'] . '% exit rate', 'behavior' );
				break;
			}
		}
		if ( $prev['sessions'] >= 10 ) {
			$chg = round( 100 * ( $t['sessions'] - $prev['sessions'] ) / $prev['sessions'] );
			if ( $chg <= -25 ) {
				/* translators: %d: percent */
				$out[] = array( 'attention', sprintf( __( 'Sessions dropped by %d%% compared to the previous period.', 'ecomm-user-tracker' ), abs( $chg ) ), '', 'traffic' );
			} elseif ( $chg >= 25 ) {
				/* translators: %d: percent */
				$out[] = array( 'trend', sprintf( __( 'Sessions grew by %d%% compared to the previous period.', 'ecomm-user-tracker' ), $chg ), '', 'traffic' );
			}
		}
		$dev = array();
		foreach ( $this->conversion_by( 'device' ) as $d ) {
			$dev[ $d['k'] ] = $d;
		}
		if ( isset( $dev['mobile'], $dev['desktop'] ) && $dev['mobile']['c'] >= 20 && $dev['desktop']['rate'] > 0 && $dev['mobile']['rate'] < $dev['desktop']['rate'] / 2 ) {
			$out[] = array( 'attention', __( 'Mobile visitors buy much less often than desktop visitors. Check your mobile product and checkout pages.', 'ecomm-user-tracker' ), $dev['mobile']['rate'] . '% vs ' . $dev['desktop']['rate'] . '%', 'traffic' );
		}
		$best = null;
		foreach ( $this->channels() as $c ) {
			if ( $c['c'] >= 10 && ( ! $best || $c['rate'] > $best['rate'] ) ) {
				$best = $c;
			}
		}
		if ( $best && $best['rate'] > 0 ) {
			/* translators: 1: channel, 2: conversion rate */
			$out[] = array( 'growth', sprintf( __( '%1$s converts best (%2$s%%). Consider investing more in this channel.', 'ecomm-user-tracker' ), '<b>' . esc_html( $best['k'] ) . '</b>', $best['rate'] ), '', 'marketing' );
		}
		$ab = $this->abandoned( 1 );
		if ( $ab['value'] > 0 ) {
			/* translators: %s: amount */
			$out[] = array( 'growth', sprintf( __( 'Abandoned carts are worth %s. A cart recovery email could win some of these back.', 'ecomm-user-tracker' ), '<b>' . esc_html( function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( $ab['value'] ) ) : $ab['value'] ) . '</b>' ), $ab['count'] . ' carts', 'marketing' );
		}
		$wd   = $this->weekdays();
		$best_day = array_search( max( $wd ), $wd, true );
		global $wp_locale;
		if ( $wp_locale && max( $wd ) > 0 ) {
			/* translators: %s: weekday */
			$out[] = array( 'trend', sprintf( __( 'Your busiest day is %s.', 'ecomm-user-tracker' ), '<b>' . esc_html( $wp_locale->get_weekday( $best_day ) ) . '</b>' ), '', 'traffic' );
		}
		$ai = $this->channel_detail( 'ai' )['rows'];
		if ( $ai ) {
			$n = array_sum( wp_list_pluck( $ai, 'c' ) );
			/* translators: 1: share percent, 2: top AI tool */
			$out[] = array( 'trend', sprintf( __( 'AI platforms bring %1$s%% of your visits, led by %2$s.', 'ecomm-user-tracker' ), round( 100 * $n / max( 1, $t['sessions'] ), 1 ), '<b>' . esc_html( $ai[0]['k'] ) . '</b>' ), '', 'marketing' );
		}
		return $out;
	}

	/** Typical e-commerce values used for Benchmarks (no cross-store data is collected). */
	public static function benchmarks() {
		return array(
			'bounce'     => 47,
			'duration'   => 150,
			'per_sess'   => 3.5,
			'returning'  => 25,
			'conversion' => 1.8,
			'abandon'    => 70,
			'organic'    => 30,
			'social'     => 10,
		);
	}

	/* ---------------- More store reports ---------------- */

	/** Orders, sales and average order value per day. */
	public function woo_daily() {
		$days = array();
		for ( $t = $this->from; $t <= $this->to; $t += DAY_IN_SECONDS ) {
			$days[ wp_date( 'Y-m-d', $t ) ] = array( 'k' => wp_date( 'M j, Y', $t ), 'c' => 0, 'rev' => 0.0, 'aov' => 0.0 );
		}
		foreach ( ECT_Woo::orders( $this->from, $this->to ) as $o ) {
			$d = $o->get_date_created() ? wp_date( 'Y-m-d', $o->get_date_created()->getTimestamp() ) : '';
			if ( isset( $days[ $d ] ) ) {
				$days[ $d ]['c']++;
				$days[ $d ]['rev'] += (float) $o->get_total() - (float) $o->get_total_refunded();
			}
		}
		foreach ( $days as &$d ) {
			$d['aov'] = $d['c'] ? $d['rev'] / $d['c'] : 0;
		}
		return array_values( $days );
	}

	public function coupons() {
		$out = array();
		foreach ( ECT_Woo::orders( $this->from, $this->to ) as $o ) {
			foreach ( $o->get_items( 'coupon' ) as $c ) {
				$code = strtoupper( $c->get_code() );
				if ( ! isset( $out[ $code ] ) ) {
					$out[ $code ] = array( 'k' => $code, 'c' => 0, 'disc' => 0.0, 'rev' => 0.0 );
				}
				$out[ $code ]['c']++;
				$out[ $code ]['disc'] += (float) $c->get_discount();
				$out[ $code ]['rev']  += (float) $o->get_total();
			}
		}
		usort( $out, function ( $a, $b ) { return $b['c'] <=> $a['c']; } );
		return array_values( $out );
	}

	public function refunds() {
		if ( ! ECT_Woo::active() ) {
			return array();
		}
		$rows = array();
		foreach ( wc_get_orders( array( 'type' => 'shop_order_refund', 'date_created' => $this->from . '...' . $this->to, 'limit' => 2000 ) ) as $r ) {
			$parent = wc_get_order( $r->get_parent_id() );
			$rows[] = array(
				'k'      => '#' . ( $parent ? $parent->get_order_number() : $r->get_parent_id() ),
				'date'   => $r->get_date_created() ? wp_date( get_option( 'date_format' ), $r->get_date_created()->getTimestamp() ) : '',
				'reason' => $r->get_reason(),
				'rev'    => abs( (float) $r->get_amount() ),
			);
		}
		return $rows;
	}

	/** New customers per day and new vs returning customers (by billing email). */
	public function customers() {
		global $wpdb;
		$daily  = array();
		$new    = 0;
		$ret    = 0;
		$seen   = array();
		foreach ( ECT_Woo::orders( $this->from, $this->to ) as $o ) {
			$email = strtolower( (string) $o->get_billing_email() );
			if ( ! $email || isset( $seen[ $email ] ) ) {
				continue;
			}
			$seen[ $email ] = 1;
			$earlier        = wc_get_orders(
				array(
					'billing_email' => $email,
					'date_created'  => '<' . $this->from,
					'limit'         => 1,
					'return'        => 'ids',
					'status'        => ECT_Woo::all_statuses(),
				)
			);
			if ( $earlier ) {
				$ret++;
				continue;
			}
			$new++;
			$d = $o->get_date_created() ? wp_date( 'M j, Y', $o->get_date_created()->getTimestamp() ) : '';
			if ( ! isset( $daily[ $d ] ) ) {
				$daily[ $d ] = array( 'k' => $d, 'c' => 0 );
			}
			$daily[ $d ]['c']++;
		}
		return array(
			'daily' => array_values( $daily ),
			'split' => array(
				array( 'k' => __( 'New customers', 'ecomm-user-tracker' ), 'c' => $new ),
				array( 'k' => __( 'Returning customers', 'ecomm-user-tracker' ), 'c' => $ret ),
			),
		);
	}

	/** Inventory: low stock, out of stock, or no sales in this period. */
	public function inventory( $type ) {
		if ( ! ECT_Woo::active() ) {
			return array();
		}
		$args = array( 'limit' => 500, 'status' => 'publish', 'type' => array( 'simple', 'variation' ) );
		if ( 'out' === $type ) {
			$args['stock_status'] = 'outofstock';
		}
		$sold = array();
		if ( 'slow' === $type ) {
			foreach ( ECT_Woo::orders( $this->from, $this->to ) as $o ) {
				foreach ( $o->get_items() as $it ) {
					$sold[ $it->get_variation_id() ? $it->get_variation_id() : $it->get_product_id() ] = 1;
					$sold[ $it->get_product_id() ] = 1;
				}
			}
		}
		$rows = array();
		foreach ( wc_get_products( $args ) as $p ) {
			$qty = $p->get_stock_quantity();
			if ( 'low' === $type ) {
				$low = (int) ( $p->get_low_stock_amount() ? $p->get_low_stock_amount() : get_option( 'woocommerce_notify_low_stock_amount', 2 ) );
				if ( ! $p->managing_stock() || null === $qty || $qty > $low || $qty <= 0 ) {
					continue;
				}
			}
			if ( 'slow' === $type && ( isset( $sold[ $p->get_id() ] ) || 'outofstock' === $p->get_stock_status() ) ) {
				continue;
			}
			$rows[] = array(
				'k'     => $p->get_name(),
				'sku'   => $p->get_sku(),
				'stock' => $p->managing_stock() ? (string) (int) $qty : ( wc_get_stock_html( $p ) ? wp_strip_all_tags( wc_get_stock_html( $p ) ) : $p->get_stock_status() ),
				'rev'   => (float) $p->get_price(),
			);
		}
		return $rows;
	}

	/** Per product: views → add to cart → purchased, with rates. */
	public function product_analytics() {
		global $wpdb;
		$e     = ECT_DB::events();
		$views = array();
		foreach ( (array) $wpdb->get_results( "SELECT label, COUNT(*) AS c FROM {$e} WHERE type = 'product_view' AND " . $this->range_sql( 'ts' ) . ' GROUP BY label', ARRAY_A ) as $r ) {
			$views[ trim( $r['label'] ) ] = (int) $r['c'];
		}
		$carts = array();
		foreach ( (array) $wpdb->get_results( "SELECT label, COUNT(*) AS c FROM {$e} WHERE type = 'add_to_cart' AND " . $this->range_sql( 'ts' ) . ' GROUP BY label', ARRAY_A ) as $r ) {
			$carts[ trim( $r['label'] ) ] = (int) $r['c'];
		}
		$bought = array();
		foreach ( ECT_Woo::orders( $this->from, $this->to ) as $o ) {
			foreach ( $o->get_items() as $it ) {
				$n            = trim( $it->get_name() );
				$bought[ $n ] = ( isset( $bought[ $n ] ) ? $bought[ $n ] : 0 ) + (int) $it->get_quantity();
			}
		}
		$rows = array();
		foreach ( array_unique( array_merge( array_keys( $views ), array_keys( $carts ), array_keys( $bought ) ) ) as $n ) {
			if ( '' === $n ) {
				continue;
			}
			$v      = isset( $views[ $n ] ) ? $views[ $n ] : 0;
			$c      = isset( $carts[ $n ] ) ? $carts[ $n ] : 0;
			$b      = isset( $bought[ $n ] ) ? $bought[ $n ] : 0;
			$rows[] = array(
				'k'     => $n,
				'views' => $v,
				'cart'  => $c,
				'c'     => $b,
				'vc'    => $v ? round( 100 * $c / $v, 1 ) . '%' : '—',
				'cb'    => $c ? round( 100 * min( $b, $c ) / $c, 1 ) . '%' : '—',
			);
		}
		usort( $rows, function ( $a, $b ) { return $b['views'] <=> $a['views'] ?: $b['c'] <=> $a['c']; } );
		return $rows;
	}

	/** Products people looked at while they were out of stock (lost sales). */
	public function out_of_stock_viewed() {
		$out = array();
		foreach ( $this->inventory( 'out' ) as $p ) {
			$out[ trim( $p['k'] ) ] = 1;
		}
		return array_values(
			array_filter(
				$this->events_by( 'product_view', 500 ),
				function ( $r ) use ( $out ) {
					return isset( $out[ trim( $r['k'] ) ] );
				}
			)
		);
	}

	public function searches( $no_results = false, $limit = 50 ) {
		global $wpdb;
		$e = ECT_DB::events();
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT label AS k, COUNT(*) AS c, MAX(value) AS res FROM {$e} WHERE type = 'search' " . ( $no_results ? 'AND value = 0 ' : '' ) . 'AND ' . $this->range_sql( 'ts' ) . ' GROUP BY label ORDER BY c DESC LIMIT %d', $limit ),
			ARRAY_A
		);
	}

	public function errors_404( $limit = 100 ) {
		global $wpdb;
		$b    = ECT_DB::bots();
		$from = wp_date( 'Y-m-d', $this->from, new DateTimeZone( 'UTC' ) );
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT path AS k, SUM(hits) AS c FROM {$b} WHERE bot = '404' AND day >= %s GROUP BY path ORDER BY c DESC LIMIT %d", $from, $limit ), ARRAY_A );
	}

	/** Blog posts by views, and posts read during visits that ended in a sale. */
	public function blog_posts( $with_sales = false, $limit = 50 ) {
		global $wpdb;
		$p = ECT_DB::pageviews();
		$s = ECT_DB::sessions();
		if ( $with_sales ) {
			$rows = (array) $wpdb->get_results( "SELECT pv.path AS k, COUNT(DISTINCT pv.session_id) AS c FROM {$p} pv JOIN {$s} se ON se.id = pv.session_id WHERE se.stage >= 4 AND pv." . $this->range_sql( 'ts' ) . ' GROUP BY pv.path ORDER BY c DESC LIMIT 500', ARRAY_A );
		} else {
			$rows = $this->top_pages( 500 );
		}
		$out = array();
		foreach ( $rows as $r ) {
			$id = url_to_postid( home_url( $r['k'] ) );
			if ( $id && 'post' === get_post_type( $id ) ) {
				$out[] = array( 'k' => get_the_title( $id ), 'page' => $r['k'], 'c' => $r['c'] );
			}
			if ( count( $out ) >= $limit ) {
				break;
			}
		}
		return $out;
	}

	public function subscriptions() {
		if ( ! function_exists( 'wcs_get_subscriptions' ) ) {
			return array();
		}
		$rows = array();
		foreach ( array( 'active', 'on-hold', 'pending-cancel', 'cancelled', 'expired' ) as $st ) {
			$rows[] = array( 'k' => wc_get_order_status_name( $st ), 'c' => count( wcs_get_subscriptions( array( 'subscription_status' => $st, 'subscriptions_per_page' => -1 ) ) ) );
		}
		$new = 0;
		foreach ( wcs_get_subscriptions( array( 'subscription_status' => 'any', 'subscriptions_per_page' => -1 ) ) as $sub ) {
			$t = $sub->get_date( 'start' );
			if ( $t && strtotime( $t ) >= $this->from ) {
				$new++;
			}
		}
		$rows[] = array( 'k' => __( 'New in this period', 'ecomm-user-tracker' ), 'c' => $new );
		return $rows;
	}

	/* ---------------- Accounting (Pro+) ---------------- */

	public function accounting() {
		$out = array(
			'gross'    => 0.0,
			'tax'      => 0.0,
			'shipping' => 0.0,
			'discount' => 0.0,
			'fees'     => 0.0,
			'refunds'  => 0.0,
			'methods'  => array(),
			'shipping_methods' => array(),
		);
		foreach ( ECT_Woo::orders( $this->from, $this->to ) as $o ) {
			$out['gross']    += (float) $o->get_total();
			$out['tax']      += (float) $o->get_total_tax();
			$out['shipping'] += (float) $o->get_shipping_total();
			$out['discount'] += (float) $o->get_discount_total();
			$out['refunds']  += (float) $o->get_total_refunded();
			foreach ( $o->get_fees() as $fee ) {
				$out['fees'] += (float) $fee->get_total();
			}
			$m = $o->get_payment_method_title() ? $o->get_payment_method_title() : __( 'Other', 'ecomm-user-tracker' );
			if ( ! isset( $out['methods'][ $m ] ) ) {
				$out['methods'][ $m ] = array( 'k' => $m, 'c' => 0, 'rev' => 0 );
			}
			$out['methods'][ $m ]['c']++;
			$out['methods'][ $m ]['rev'] += (float) $o->get_total();
			foreach ( $o->get_shipping_methods() as $sm ) {
				$n = $sm->get_name();
				if ( ! isset( $out['shipping_methods'][ $n ] ) ) {
					$out['shipping_methods'][ $n ] = array( 'k' => $n, 'c' => 0, 'rev' => 0 );
				}
				$out['shipping_methods'][ $n ]['c']++;
				$out['shipping_methods'][ $n ]['rev'] += (float) $sm->get_total();
			}
		}
		$out['net']              = $out['gross'] - $out['refunds'] - $out['tax'] - $out['shipping'];
		$out['methods']          = array_values( $out['methods'] );
		$out['shipping_methods'] = array_values( $out['shipping_methods'] );
		return $out;
	}

	/* ---------------- WooCommerce ---------------- */

	public function sales() {
		$out = array(
			'orders'   => 0,
			'revenue'  => 0.0,
			'aov'      => 0.0,
			'items'    => array(),
			'sources'  => array(),
			'customers' => array(),
		);
		if ( ! ECT_Woo::active() ) {
			return $out;
		}
		global $wpdb;
		$t      = ECT_DB::sessions();
		$skeys  = array();
		$orders = ECT_Woo::orders( $this->from, $this->to );
		foreach ( $orders as $order ) {
			$total = (float) $order->get_total() - (float) $order->get_total_refunded();
			$out['orders']++;
			$out['revenue'] += $total;
			foreach ( $order->get_items() as $item ) {
				$name = $item->get_name();
				if ( ! isset( $out['items'][ $name ] ) ) {
					$out['items'][ $name ] = array(
						'k'   => $name,
						'c'   => 0,
						'rev' => 0,
					);
				}
				$out['items'][ $name ]['c']   += (int) $item->get_quantity();
				$out['items'][ $name ]['rev'] += (float) $item->get_total();
			}
			if ( ect_get_option( 'hide_names' ) ) {
				$email = strtolower( (string) $order->get_billing_email() );
				/* translators: %s: short anonymous customer id */
				$who = sprintf( __( 'Customer #%s', 'ecomm-user-tracker' ), $email ? strtoupper( substr( md5( $email . wp_salt( 'auth' ) ), 0, 5 ) ) : '—' );
			} else {
				$who = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
				$who = $who ? $who : __( 'Guest', 'ecomm-user-tracker' );
			}
			if ( ! isset( $out['customers'][ $who ] ) ) {
				$out['customers'][ $who ] = array(
					'k'   => $who,
					'c'   => 0,
					'rev' => 0,
				);
			}
			$out['customers'][ $who ]['c']++;
			$out['customers'][ $who ]['rev'] += $total;

			$label = ECT_Woo::order_source( $order, $skeys );
			if ( ! isset( $out['sources'][ $label ] ) ) {
				$out['sources'][ $label ] = array(
					'k'   => $label,
					'c'   => 0,
					'rev' => 0,
				);
			}
			$out['sources'][ $label ]['c']++;
			$out['sources'][ $label ]['rev'] += $total;
		}
		$out['aov'] = $out['orders'] ? $out['revenue'] / $out['orders'] : 0;
		foreach ( array( 'items', 'sources', 'customers' ) as $k ) {
			$list = array_values( $out[ $k ] );
			usort(
				$list,
				function ( $a, $b ) {
					return $b['rev'] <=> $a['rev'];
				}
			);
			$out[ $k ] = array_slice( $list, 0, 25 );
		}
		return $out;
	}
}
