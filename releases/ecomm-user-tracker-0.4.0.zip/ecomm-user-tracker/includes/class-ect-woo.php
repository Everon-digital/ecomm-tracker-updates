<?php
/**
 * WooCommerce: link each new order to the visit it came from (for "sales by source").
 * Orders themselves are read from WooCommerce (HPOS compatible), not copied.
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Woo {

	const META = '_ect_session';

	public static function active() {
		return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_orders' );
	}

	public static function init() {
		add_action( 'woocommerce_new_order', array( __CLASS__, 'attach' ), 10, 2 );
		add_action( 'woocommerce_add_to_cart', array( __CLASS__, 'added_to_cart' ), 10, 4 );
	}

	/** Visit (session row id) of the current browser, from the tracker cookie. */
	public static function current_session() {
		$sid = isset( $_COOKIE['ect_sid'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['ect_sid'] ) ) : '';
		if ( ! preg_match( '/^[a-zA-Z0-9]{16,40}$/', $sid ) ) {
			return array( '', 0 );
		}
		$skey = ECT_Tracker::session_key( $sid );
		return array( $skey, ECT_DB::session_id_by_key( $skey ) );
	}

	/** Pro+: add to cart step for the funnel and abandoned carts. */
	public static function added_to_cart( $cart_key, $product_id, $quantity, $variation_id ) {
		if ( ! ECT_License::has( 'proplus' ) ) {
			return;
		}
		list( , $session_id ) = self::current_session();
		if ( ! $session_id ) {
			return;
		}
		$product = wc_get_product( $variation_id ? $variation_id : $product_id );
		$value   = $product ? (float) wc_get_price_to_display( $product ) * (int) $quantity : 0;
		ECT_DB::stage( $session_id, 2, $value );
		ECT_DB::event( $session_id, 'add_to_cart', $product ? $product->get_name() : '#' . $product_id, '', $value );
	}

	public static function attach( $order_id, $order = null ) {
		if ( ! ECT_License::has( 'pro' ) || is_admin() && ! wp_doing_ajax() ) {
			return;
		}
		$sid = isset( $_COOKIE['ect_sid'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['ect_sid'] ) ) : '';
		if ( ! preg_match( '/^[a-zA-Z0-9]{16,40}$/', $sid ) ) {
			return;
		}
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order_id );
		if ( $order ) {
			$skey = ECT_Tracker::session_key( $sid );
			$order->update_meta_data( self::META, $skey );
			$order->save_meta_data();
			$session_id = ECT_DB::session_id_by_key( $skey );
			if ( $session_id && ECT_License::has( 'proplus' ) ) {
				ECT_DB::stage( $session_id, 4 );
				ECT_DB::event( $session_id, 'purchase', '#' . $order->get_id(), '', (float) $order->get_total() );
				if ( in_array( 'checkout', ECT_Reports::form_types(), true ) ) {
					ECT_DB::event( $session_id, 'form_submit', 'checkout', '' );
				}
			}
		}
	}

	/** Statuses that are never a sale. Everything else counts (incl. custom ones like "Shipped", "Delivered"). */
	public static function unpaid_statuses() {
		return apply_filters( 'ect_unpaid_order_statuses', array( 'pending', 'failed', 'cancelled', 'refunded', 'checkout-draft', 'trash', 'draft', 'auto-draft' ) );
	}

	/** Every order status known on this site, including custom statuses from other plugins. */
	public static function all_statuses() {
		$all = function_exists( 'wc_get_order_statuses' ) ? array_keys( wc_get_order_statuses() ) : array();
		foreach ( array_keys( get_post_stati() ) as $st ) {
			if ( 0 === strpos( $st, 'wc-' ) ) {
				$all[] = $st;
			}
		}
		return array_values( array_unique( $all ) );
	}

	public static function is_paid( $order ) {
		return ! in_array( $order->get_status(), self::unpaid_statuses(), true );
	}

	/** @return WC_Order[] Paid orders created between two timestamps. */
	public static function orders( $from, $to ) {
		if ( ! self::active() ) {
			return array();
		}
		$orders = wc_get_orders(
			array(
				'status'       => self::all_statuses(),
				'date_created' => $from . '...' . $to,
				'limit'        => 5000,
				'type'         => 'shop_order',
			)
		);
		return array_values( array_filter( $orders, array( __CLASS__, 'is_paid' ) ) );
	}

	/**
	 * Where an order came from. Uses our own visit tracking first, then WooCommerce's
	 * built-in Order Attribution (WooCommerce 8.5+), so older orders get a source too.
	 */
	public static function order_source( $order, &$cache = array() ) {
		global $wpdb;
		$skey = $order->get_meta( self::META );
		if ( $skey ) {
			if ( ! isset( $cache[ $skey ] ) ) {
				$t              = ECT_DB::sessions();
				$row            = $wpdb->get_row( $wpdb->prepare( "SELECT channel, source FROM {$t} WHERE skey = %s", $skey ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$cache[ $skey ] = $row ? ECT_Source::label( $row['channel'], $row['source'] ) : '';
			}
			if ( $cache[ $skey ] ) {
				return $cache[ $skey ];
			}
		}
		$type = (string) $order->get_meta( '_wc_order_attribution_source_type' );
		if ( $type ) {
			switch ( $type ) {
				case 'typein':
					return __( 'Direct', 'ecomm-user-tracker' );
				case 'admin':
					return __( 'Manual order (admin)', 'ecomm-user-tracker' );
				case 'mobile_app':
					return __( 'Mobile app', 'ecomm-user-tracker' );
			}
			$q = array_filter(
				array(
					'utm_source'   => (string) $order->get_meta( '_wc_order_attribution_utm_source' ),
					'utm_medium'   => (string) $order->get_meta( '_wc_order_attribution_utm_medium' ),
					'utm_campaign' => (string) $order->get_meta( '_wc_order_attribution_utm_campaign' ),
				)
			);
			$ref = (string) $order->get_meta( '_wc_order_attribution_referrer' );
			if ( 'organic' === $type && $ref ) {
				$q = array();
			}
			list( $channel, $source ) = ECT_Source::classify( $ref, $q );
			return ECT_Source::label( $channel, $source );
		}
		return __( 'Not tracked', 'ecomm-user-tracker' );
	}
}
