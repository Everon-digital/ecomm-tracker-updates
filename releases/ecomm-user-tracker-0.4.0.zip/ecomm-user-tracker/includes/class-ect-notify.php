<?php
/**
 * Scheduled email reports (Pro), alerts (Pro+) and white-label branding (Agency).
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Notify {

	const OPTION = 'ect_notify';

	public static function init() {
		add_action( 'ect_notify', array( __CLASS__, 'run' ) );
		if ( ! wp_next_scheduled( 'ect_notify' ) ) {
			wp_schedule_event( time() + 5 * MINUTE_IN_SECONDS, 'hourly', 'ect_notify' );
		}
		add_action( 'admin_post_ect_notify', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_ect_notify_test', array( __CLASS__, 'send_test' ) );
	}

	public static function get( $key = null ) {
		$o = wp_parse_args(
			(array) get_option( self::OPTION, array() ),
			array(
				'report_freq'     => 'off',
				'report_to'       => get_option( 'admin_email' ),
				'sales_above'     => 0,
				'traffic_drop'    => 0,
				'abandoned_above' => 0,
				'alert_to'        => get_option( 'admin_email' ),
				'brand_name'      => '',
				'brand_logo'      => '',
				'brand_color'     => '#2271b1',
				'last_report'     => '',
				'alerted'         => array(),
			)
		);
		return null === $key ? $o : ( isset( $o[ $key ] ) ? $o[ $key ] : null );
	}

	private static function set( $data ) {
		update_option( self::OPTION, array_merge( self::get(), $data ), false );
	}

	public static function emails( $list ) {
		$out = array();
		foreach ( preg_split( '/[\s,;]+/', (string) $list ) as $e ) {
			$e = sanitize_email( $e );
			if ( is_email( $e ) ) {
				$out[] = $e;
			}
		}
		return array_slice( array_unique( $out ), 0, 10 );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_notify' );
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$p    = wp_unslash( $_POST );
		$data = array();
		if ( ECT_License::has( 'pro' ) ) {
			$freq                = isset( $p['report_freq'] ) ? sanitize_key( $p['report_freq'] ) : 'off';
			$data['report_freq'] = in_array( $freq, array( 'off', 'daily', 'weekly', 'monthly' ), true ) ? $freq : 'off';
			$data['report_to']   = implode( ', ', self::emails( isset( $p['report_to'] ) ? $p['report_to'] : '' ) );
		}
		if ( ECT_License::has( 'proplus' ) ) {
			$data['sales_above']     = max( 0, (float) ( isset( $p['sales_above'] ) ? $p['sales_above'] : 0 ) );
			$data['traffic_drop']    = min( 100, max( 0, (int) ( isset( $p['traffic_drop'] ) ? $p['traffic_drop'] : 0 ) ) );
			$data['abandoned_above'] = max( 0, (float) ( isset( $p['abandoned_above'] ) ? $p['abandoned_above'] : 0 ) );
			$data['alert_to']        = implode( ', ', self::emails( isset( $p['alert_to'] ) ? $p['alert_to'] : '' ) );
		}
		if ( ECT_License::has( 'agency' ) ) {
			$data['brand_name']  = isset( $p['brand_name'] ) ? sanitize_text_field( $p['brand_name'] ) : '';
			$data['brand_logo']  = isset( $p['brand_logo'] ) ? esc_url_raw( $p['brand_logo'] ) : '';
			$color               = isset( $p['brand_color'] ) ? sanitize_hex_color( $p['brand_color'] ) : '';
			$data['brand_color'] = $color ? $color : '#2271b1';
		}
		// phpcs:enable
		self::set( $data );
		wp_safe_redirect( admin_url( 'admin.php?page=ecomm-user-tracker-settings&ect_saved=1#ect-alerts' ) );
		exit;
	}

	public static function send_test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_notify_test' );
		$ok = self::send_report( 'weekly', true );
		wp_safe_redirect( admin_url( 'admin.php?page=ecomm-user-tracker-settings&ect_test=' . ( $ok ? 'ok' : 'fail' ) . '#ect-alerts' ) );
		exit;
	}

	/** Hourly: send the scheduled report when due, then check alerts. */
	public static function run() {
		$o   = self::get();
		$now = new DateTime( 'now', wp_timezone() );
		if ( ECT_License::has( 'pro' ) && 'off' !== $o['report_freq'] && (int) $now->format( 'G' ) >= 8 ) {
			$due = false;
			$key = '';
			switch ( $o['report_freq'] ) {
				case 'daily':
					$key = $now->format( 'Y-m-d' );
					$due = true;
					break;
				case 'weekly':
					$key = $now->format( 'o-\WW' );
					$due = '1' === $now->format( 'N' );
					break;
				case 'monthly':
					$key = $now->format( 'Y-m' );
					$due = '1' === $now->format( 'j' );
					break;
			}
			if ( $due && $o['last_report'] !== $key ) {
				self::set( array( 'last_report' => $key ) );
				self::send_report( $o['report_freq'] );
			}
		}
		if ( ECT_License::has( 'proplus' ) ) {
			self::check_alerts( $o );
		}
	}

	/* ---------------- Alerts ---------------- */

	private static function check_alerts( $o ) {
		$today   = wp_date( 'Y-m-d' );
		$alerted = isset( $o['alerted'][ $today ] ) ? $o['alerted'][ $today ] : array();
		$to      = self::emails( $o['alert_to'] );
		if ( ! $to ) {
			return;
		}
		$day   = new ECT_Reports( 1 );
		$fired = array();

		if ( $o['sales_above'] > 0 && empty( $alerted['sales'] ) && ECT_Woo::active() ) {
			$rev = $day->sales()['revenue'];
			if ( $rev >= $o['sales_above'] ) {
				/* translators: %s: amount */
				self::mail( $to, sprintf( __( '🎉 Sales today passed %s', 'ecomm-user-tracker' ), self::money( $o['sales_above'] ) ), self::alert_body( sprintf( /* translators: %s: amount */ __( 'Your store has made %s in sales today.', 'ecomm-user-tracker' ), self::money( $rev ) ) ) );
				$fired['sales'] = 1;
			}
		}
		if ( $o['traffic_drop'] > 0 && empty( $alerted['traffic'] ) ) {
			$now  = ECT_Reports::between( time() - DAY_IN_SECONDS, time() )->totals()['sessions'];
			$prev = ECT_Reports::between( time() - 2 * DAY_IN_SECONDS, time() - DAY_IN_SECONDS - 1 )->totals()['sessions'];
			if ( $prev >= 20 && $now < $prev * ( 1 - $o['traffic_drop'] / 100 ) ) {
				$drop = round( 100 * ( $prev - $now ) / $prev );
				/* translators: %d: percent */
				self::mail( $to, sprintf( __( '⚠️ Traffic dropped by %d%%', 'ecomm-user-tracker' ), $drop ), self::alert_body( sprintf( /* translators: 1: sessions now, 2: sessions before */ __( 'Sessions in the last 24 hours: %1$s (previous 24 hours: %2$s).', 'ecomm-user-tracker' ), number_format_i18n( $now ), number_format_i18n( $prev ) ) ) );
				$fired['traffic'] = 1;
			}
		}
		if ( $o['abandoned_above'] > 0 && empty( $alerted['abandoned'] ) ) {
			$ab = $day->abandoned( 1 );
			if ( $ab['value'] >= $o['abandoned_above'] ) {
				/* translators: %s: amount */
				self::mail( $to, sprintf( __( '🛒 Abandoned carts today: %s', 'ecomm-user-tracker' ), self::money( $ab['value'] ) ), self::alert_body( sprintf( /* translators: 1: carts, 2: amount */ __( '%1$s carts worth %2$s were left today.', 'ecomm-user-tracker' ), number_format_i18n( $ab['count'] ), self::money( $ab['value'] ) ) ) );
				$fired['abandoned'] = 1;
			}
		}
		if ( $fired ) {
			self::set( array( 'alerted' => array( $today => array_merge( $alerted, $fired ) ) ) );
		}
	}

	private static function alert_body( $text ) {
		return self::wrap( '<p style="font-size:16px;margin:0 0 16px">' . esc_html( $text ) . '</p>' . self::button( admin_url( 'admin.php?page=ecomm-user-tracker' ), __( 'Open dashboard', 'ecomm-user-tracker' ) ) );
	}

	/* ---------------- Email report ---------------- */

	public static function send_report( $freq, $test = false ) {
		$to = self::emails( self::get( 'report_to' ) );
		if ( ! $to ) {
			return false;
		}
		$days = array(
			'daily'   => 1,
			'weekly'  => 7,
			'monthly' => 30,
		);
		$d   = isset( $days[ $freq ] ) ? $days[ $freq ] : 7;
		$end = ( new DateTime( 'today', wp_timezone() ) )->getTimestamp() - 1;
		$rep = ECT_Reports::between( $end - $d * DAY_IN_SECONDS + 1, $end );
		$prv = $rep->previous();
		$t   = $rep->totals();
		$pt  = $prv->totals();
		$s   = $rep->sales();
		$ps  = $prv->sales();

		$kpis = array(
			array( __( 'Sessions', 'ecomm-user-tracker' ), number_format_i18n( $t['sessions'] ), self::pct( $t['sessions'], $pt['sessions'] ) ),
			array( __( 'Visitors', 'ecomm-user-tracker' ), number_format_i18n( $t['visitors'] ), self::pct( $t['visitors'], $pt['visitors'] ) ),
		);
		if ( ECT_Woo::active() ) {
			$kpis[] = array( __( 'Sales', 'ecomm-user-tracker' ), self::money( $s['revenue'] ), self::pct( $s['revenue'], $ps['revenue'] ) );
			$kpis[] = array( __( 'Orders', 'ecomm-user-tracker' ), number_format_i18n( $s['orders'] ), self::pct( $s['orders'], $ps['orders'] ) );
		}
		$h = '<table role="presentation" width="100%" style="border-collapse:collapse;margin:0 0 20px"><tr>';
		foreach ( $kpis as $k ) {
			$h .= '<td style="padding:12px;border:1px solid #e2e4e7;border-radius:8px;width:25%"><div style="color:#50575e;font-size:12px">' . esc_html( $k[0] ) . '</div><div style="font-size:22px;font-weight:700">' . esc_html( $k[1] ) . '</div><div style="font-size:12px;color:#757575">' . esc_html( $k[2] ) . '</div></td>';
		}
		$h .= '</tr></table>';
		$h .= self::list_html( __( 'Top traffic sources', 'ecomm-user-tracker' ), $rep->sources( 5 ) );
		$h .= self::list_html( __( 'Most visited pages', 'ecomm-user-tracker' ), $rep->top_pages( 5 ) );
		if ( ECT_Woo::active() ) {
			$h .= self::list_html( __( 'Top selling items', 'ecomm-user-tracker' ), array_slice( $s['items'], 0, 5 ), true );
		}
		$h .= self::button( admin_url( 'admin.php?page=ecomm-user-tracker' ), __( 'Open full dashboard', 'ecomm-user-tracker' ) );

		$labels = array(
			'daily'   => __( 'Daily report', 'ecomm-user-tracker' ),
			'weekly'  => __( 'Weekly report', 'ecomm-user-tracker' ),
			'monthly' => __( 'Monthly report', 'ecomm-user-tracker' ),
		);
		/* translators: 1: report type, 2: site name, 3: date range */
		$subject = sprintf( __( '%1$s · %2$s · %3$s', 'ecomm-user-tracker' ), $labels[ $freq ] ?? $labels['weekly'], wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), wp_date( 'M j', $rep->from ) . ' – ' . wp_date( 'M j', $rep->to ) );
		return self::mail( $to, ( $test ? '[Test] ' : '' ) . $subject, self::wrap( $h ) );
	}

	private static function list_html( $title, $rows, $money = false ) {
		$h = '<h3 style="font-size:14px;margin:18px 0 6px">' . esc_html( $title ) . '</h3><table role="presentation" width="100%" style="border-collapse:collapse">';
		if ( ! $rows ) {
			return $h . '<tr><td style="color:#757575;padding:6px 0">—</td></tr></table>';
		}
		foreach ( $rows as $r ) {
			$h .= '<tr><td style="padding:6px 0;border-bottom:1px solid #f0f0f1">' . esc_html( $r['k'] ) . '</td><td style="padding:6px 0;border-bottom:1px solid #f0f0f1;text-align:right">' . esc_html( $money ? self::money( $r['rev'] ) : number_format_i18n( $r['c'] ) ) . '</td></tr>';
		}
		return $h . '</table>';
	}

	/* ---------------- Branding / helpers ---------------- */

	/** Brand shown on emails and printed reports: agency's own brand, else Ecomm User Tracker. */
	public static function brand() {
		$o = self::get();
		if ( ECT_License::has( 'agency' ) && ( $o['brand_name'] || $o['brand_logo'] ) ) {
			return array(
				'name'  => $o['brand_name'],
				'logo'  => $o['brand_logo'],
				'color' => $o['brand_color'],
			);
		}
		return array(
			'name'  => 'Ecomm User Tracker',
			'logo'  => '',
			'color' => '#2271b1',
		);
	}

	private static function wrap( $inner ) {
		$b    = self::brand();
		$head = $b['logo'] ? '<img src="' . esc_url( $b['logo'] ) . '" alt="' . esc_attr( $b['name'] ) . '" style="max-height:40px">' : '<strong style="font-size:18px;color:' . esc_attr( $b['color'] ) . '">' . esc_html( $b['name'] ) . '</strong>';
		return '<div style="background:#f0f0f1;padding:24px;font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#1d2327"><div style="max-width:600px;margin:0 auto;background:#fff;border-radius:10px;padding:24px">'
			. '<div style="border-bottom:3px solid ' . esc_attr( $b['color'] ) . ';padding-bottom:12px;margin-bottom:18px">' . $head . '<div style="color:#757575;font-size:12px;margin-top:4px">' . esc_html( get_bloginfo( 'name' ) . ' · ' . home_url() ) . '</div></div>'
			. $inner . '</div></div>';
	}

	private static function button( $url, $label ) {
		$b = self::brand();
		return '<p style="margin:22px 0 0"><a href="' . esc_url( $url ) . '" style="background:' . esc_attr( $b['color'] ) . ';color:#fff;text-decoration:none;padding:10px 18px;border-radius:6px;display:inline-block">' . esc_html( $label ) . '</a></p>';
	}

	private static function mail( $to, $subject, $html ) {
		return wp_mail( $to, $subject, $html, array( 'Content-Type: text/html; charset=UTF-8' ) );
	}

	private static function money( $v ) {
		return function_exists( 'wc_price' ) ? html_entity_decode( wp_strip_all_tags( wc_price( $v ) ), ENT_QUOTES, 'UTF-8' ) : number_format_i18n( $v, 2 );
	}

	private static function pct( $now, $before ) {
		if ( ! $before ) {
			return '';
		}
		$p = round( 100 * ( $now - $before ) / $before );
		/* translators: %s: change like +12% */
		return sprintf( __( '%s vs previous period', 'ecomm-user-tracker' ), ( $p > 0 ? '+' : '' ) . $p . '%' );
	}

	/* ---------------- Settings card ---------------- */

	public static function settings_card() {
		if ( ! ECT_License::has( 'pro' ) ) {
			return;
		}
		$o = self::get();
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['ect_test'] ) ) {
			$ok = 'ok' === $_GET['ect_test'];
			echo '<div class="notice notice-' . ( $ok ? 'success' : 'error' ) . '"><p>' . esc_html( $ok ? __( 'Test report sent.', 'ecomm-user-tracker' ) : __( 'The email could not be sent. Check the email address or your site’s mail setup.', 'ecomm-user-tracker' ) ) . '</p></div>';
		}
		// phpcs:enable
		echo '<div class="ect-card ect-settings" id="ect-alerts"><h3>' . esc_html__( 'Email reports & alerts', 'ecomm-user-tracker' ) . '</h3>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ect_notify' );
		echo '<input type="hidden" name="action" value="ect_notify">';
		echo '<p><label>' . esc_html__( 'Send me a report', 'ecomm-user-tracker' ) . '<br><select name="report_freq">';
		foreach ( array(
			'off'     => __( 'Off', 'ecomm-user-tracker' ),
			'daily'   => __( 'Daily (every morning)', 'ecomm-user-tracker' ),
			'weekly'  => __( 'Weekly (Monday morning)', 'ecomm-user-tracker' ),
			'monthly' => __( 'Monthly (1st of the month)', 'ecomm-user-tracker' ),
		) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $o['report_freq'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></label></p><p><label>' . esc_html__( 'Send reports to (comma separated)', 'ecomm-user-tracker' ) . '<br><input type="text" class="regular-text" name="report_to" value="' . esc_attr( $o['report_to'] ) . '"></label></p>';

		if ( ECT_License::has( 'proplus' ) ) {
			$cur = function_exists( 'get_woocommerce_currency_symbol' ) ? html_entity_decode( get_woocommerce_currency_symbol() ) : '';
			echo '<h4>🔔 ' . esc_html__( 'Alerts', 'ecomm-user-tracker' ) . '</h4><p class="ect-muted">' . esc_html__( 'Leave 0 to turn an alert off. Each alert is sent at most once a day.', 'ecomm-user-tracker' ) . '</p>';
			echo '<p><label>' . esc_html__( 'Email me when sales today pass', 'ecomm-user-tracker' ) . ' ' . esc_html( $cur ) . ' <input type="number" min="0" step="1" class="small-text" name="sales_above" value="' . esc_attr( $o['sales_above'] ) . '"></label></p>';
			echo '<p><label>' . esc_html__( 'Email me when traffic drops by more than', 'ecomm-user-tracker' ) . ' <input type="number" min="0" max="100" class="small-text" name="traffic_drop" value="' . esc_attr( $o['traffic_drop'] ) . '"> % <span class="ect-muted">' . esc_html__( '(last 24 hours vs the 24 hours before)', 'ecomm-user-tracker' ) . '</span></label></p>';
			echo '<p><label>' . esc_html__( 'Email me when abandoned carts today are worth more than', 'ecomm-user-tracker' ) . ' ' . esc_html( $cur ) . ' <input type="number" min="0" step="1" class="small-text" name="abandoned_above" value="' . esc_attr( $o['abandoned_above'] ) . '"></label></p>';
			echo '<p><label>' . esc_html__( 'Send alerts to', 'ecomm-user-tracker' ) . '<br><input type="text" class="regular-text" name="alert_to" value="' . esc_attr( $o['alert_to'] ) . '"></label></p>';
		}
		if ( ECT_License::has( 'agency' ) ) {
			echo '<h4>🏷 ' . esc_html__( 'White-label (your brand on reports and emails)', 'ecomm-user-tracker' ) . '</h4>';
			echo '<p><label>' . esc_html__( 'Brand name', 'ecomm-user-tracker' ) . '<br><input type="text" class="regular-text" name="brand_name" value="' . esc_attr( $o['brand_name'] ) . '"></label></p>';
			echo '<p><label>' . esc_html__( 'Logo URL', 'ecomm-user-tracker' ) . '<br><input type="url" class="regular-text" name="brand_logo" value="' . esc_attr( $o['brand_logo'] ) . '" placeholder="https://"></label></p>';
			echo '<p><label>' . esc_html__( 'Brand color', 'ecomm-user-tracker' ) . ' <input type="color" name="brand_color" value="' . esc_attr( $o['brand_color'] ) . '"></label></p>';
		}
		submit_button( __( 'Save', 'ecomm-user-tracker' ), 'primary', 'submit', false );
		echo '</form>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="ect-inline-form">';
		wp_nonce_field( 'ect_notify_test' );
		echo '<input type="hidden" name="action" value="ect_notify_test">';
		submit_button( __( 'Send a test report now', 'ecomm-user-tracker' ), 'secondary', 'submit', false );
		echo '</form></div>';
	}
}
