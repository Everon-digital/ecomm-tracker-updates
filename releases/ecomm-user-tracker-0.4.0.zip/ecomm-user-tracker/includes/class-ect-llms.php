<?php
/**
 * llms.txt generator (Pro+): serves /llms.txt built from the site's pages, posts and products.
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Llms {

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'serve' ), 0 );
		add_action( 'admin_post_ect_llms', array( __CLASS__, 'save' ) );
		foreach ( array( 'save_post', 'deleted_post', 'update_option_blogdescription' ) as $hook ) {
			add_action( $hook, array( __CLASS__, 'flush' ) );
		}
	}

	public static function opts() {
		return wp_parse_args( (array) get_option( 'ect_llms', array() ), array( 'enabled' => 0, 'intro' => '' ) );
	}

	public static function enabled() {
		return ECT_License::has( 'proplus' ) && self::opts()['enabled'] && ! file_exists( ABSPATH . 'llms.txt' );
	}

	public static function flush() {
		delete_transient( 'ect_llms_txt' );
	}

	public static function serve() {
		$path = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$home = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		if ( $home . '/llms.txt' !== $path || ! self::enabled() ) {
			return;
		}
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		echo self::build(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	private static function line( $post ) {
		$desc = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_trim_words( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ), 20, '…' );
		$desc = trim( preg_replace( '/\s+/', ' ', html_entity_decode( $desc, ENT_QUOTES, 'UTF-8' ) ) );
		return '- [' . html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ) . '](' . get_permalink( $post ) . ')' . ( $desc ? ': ' . $desc : '' ) . "\n";
	}

	public static function build() {
		$cached = get_transient( 'ect_llms_txt' );
		if ( is_string( $cached ) ) {
			return $cached;
		}
		$o     = self::opts();
		$out   = '# ' . html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' ) . "\n\n";
		$intro = trim( $o['intro'] ) ? $o['intro'] : get_bloginfo( 'description' );
		if ( $intro ) {
			$out .= '> ' . trim( preg_replace( '/\s+/', ' ', html_entity_decode( $intro, ENT_QUOTES, 'UTF-8' ) ) ) . "\n\n";
		}
		$groups = array(
			'page'    => array( __( 'Pages', 'ecomm-user-tracker' ), 50 ),
			'product' => array( __( 'Products', 'ecomm-user-tracker' ), 100 ),
			'post'    => array( __( 'Blog', 'ecomm-user-tracker' ), 30 ),
		);
		foreach ( $groups as $type => $g ) {
			if ( ! post_type_exists( $type ) ) {
				continue;
			}
			$posts = get_posts(
				array(
					'post_type'      => $type,
					'post_status'    => 'publish',
					'posts_per_page' => $g[1],
					'orderby'        => 'page' === $type ? 'menu_order' : 'date',
					'order'          => 'page' === $type ? 'ASC' : 'DESC',
					'has_password'   => false,
				)
			);
			if ( ! $posts ) {
				continue;
			}
			$out .= '## ' . $g[0] . "\n\n";
			foreach ( $posts as $p ) {
				$out .= self::line( $p );
			}
			$out .= "\n";
		}
		if ( function_exists( 'get_terms' ) && taxonomy_exists( 'product_cat' ) ) {
			$cats = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => true, 'number' => 30 ) );
			if ( $cats && ! is_wp_error( $cats ) ) {
				$out .= '## ' . __( 'Product categories', 'ecomm-user-tracker' ) . "\n\n";
				foreach ( $cats as $c ) {
					$out .= '- [' . html_entity_decode( $c->name, ENT_QUOTES, 'UTF-8' ) . '](' . get_term_link( $c ) . ")\n";
				}
				$out .= "\n";
			}
		}
		set_transient( 'ect_llms_txt', $out, DAY_IN_SECONDS );
		return $out;
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'ecomm-user-tracker' ) );
		}
		check_admin_referer( 'ect_llms' );
		update_option(
			'ect_llms',
			array(
				'enabled' => empty( $_POST['enabled'] ) ? 0 : 1,
				'intro'   => isset( $_POST['intro'] ) ? sanitize_textarea_field( wp_unslash( $_POST['intro'] ) ) : '',
			),
			false
		);
		self::flush();
		delete_transient( 'ect_ai_readiness' );
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url() );
		exit;
	}

	/** Small form shown under the AI visibility score. */
	public static function form() {
		if ( file_exists( ABSPATH . 'llms.txt' ) ) {
			return '<p class="ect-muted">' . esc_html__( 'Your site already has its own llms.txt file.', 'ecomm-user-tracker' ) . '</p>';
		}
		$o  = self::opts();
		$h  = '<h4>llms.txt</h4><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="ect-inline-form">';
		$h .= wp_nonce_field( 'ect_llms', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="ect_llms">';
		$h .= '<p><label><input type="checkbox" name="enabled" value="1"' . checked( $o['enabled'], 1, false ) . '> ' . esc_html__( 'Create llms.txt automatically (pages, products and posts)', 'ecomm-user-tracker' ) . '</label></p>';
		$h .= '<p><textarea name="intro" rows="2" class="large-text" placeholder="' . esc_attr__( 'Short summary of your store (optional)', 'ecomm-user-tracker' ) . '">' . esc_textarea( $o['intro'] ) . '</textarea></p>';
		$h .= '<p><button class="button">' . esc_html__( 'Save', 'ecomm-user-tracker' ) . '</button>';
		if ( $o['enabled'] ) {
			$h .= ' <a class="button" target="_blank" rel="noopener" href="' . esc_url( home_url( '/llms.txt' ) ) . '">' . esc_html__( 'View llms.txt', 'ecomm-user-tracker' ) . '</a>';
		}
		return $h . '</p></form>';
	}
}
