=== Ecomm User Tracker ===
Contributors: everondigital
Tags: analytics, live visitors, woocommerce, real-time, statistics
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.3.3
License: GPLv2 or later

Live visitors and their countries for WordPress & WooCommerce. Lightweight and privacy-friendly — data stays on your own site.

== Description ==

* Live visitors count (last 5 minutes)
* Live visitors by country (with flags)
* Dashboard widget
* Pro / Pro+ / Agency unlock traffic sources (incl. AI tools), pages, orders, funnels, reports and more

IP geolocation by DB-IP (https://db-ip.com), CC BY 4.0.

== Changelog ==

= 0.3.3 =
* Real-time page updates every second without refreshing (recent visitors, live activity, pages/sources/devices, visitor snapshot).
* Live activity shows add to cart, checkout, purchases and form submissions; recent visitors show their shopping stage.

= 0.3.2 =
* Sales now include orders with custom statuses (e.g. Shipped, Delivered).

= 0.3.1 =
* Complimentary plan support for Everon Digital sites.

= 0.3.0 =
* Pro: button click tracking, new vs returning visitors, avg. time on page.
* Pro+: conversion funnel, visitor snapshot, abandoned carts, device/browser/OS report with conversion.
* Pro+: navigation flows, form submissions (any form on the site).
* Pro+: Marketing — performance by channel, AI platforms, AI bots, AI visibility score, email click & sales tracking.
* Pro+: session recordings via Microsoft Clarity, accounting reports, All Reports with CSV export, 90-day and 12-month ranges.
* Agency: insights and benchmarks.

= 0.2.0 =
* Pro: page visits, entry & exit pages, sessions over time, avg. session duration, bounce rate.
* Pro: traffic sources — Google / Facebook organic vs ads, AI tools (ChatGPT, Claude, Gemini, Perplexity…), direct, email, referral.
* Pro: device type, sessions by country, real-time recent visitors and live activity.
* Pro: WooCommerce sales, orders, top products, sales by source, top customers.
* License key activation (Settings).

= 0.1.4 =
* Cleaner settings page.
* "Delete all plugin data" on by default.
* Optional feedback when deactivating.

= 0.1.3 =
* Tracker file renamed so common ad-block filter lists no longer block it (visitors were missing).
* More precise bot detection (fewer real visitors filtered out).

= 0.1.2 =
* Dashboard → Updates → "Check again" now fetches the latest plugin version immediately.

= 0.1.1 =
* Live visitors appear right away on sites using LiteSpeed Cache, WP Rocket, Autoptimize and similar (tracker excluded from JS delay/defer).
* Admin live view refreshes every 10 seconds.

= 0.1.0 =
* First release: live visitors + countries, admin menu, dashboard widget, self-hosted auto-updates.
