<?php
/**
 * Front-end tracker script + REST endpoint that receives heartbeats.
 *
 * @package EcommUserTracker
 */

defined( 'ABSPATH' ) || exit;

class ECT_Tracker {

	const BOT_PATTERN = '/bot\b|bot\/|crawl|spider|slurp|facebookexternalhit|headlesschrome|lighthouse|pingdom|python-requests|curl\/|wget|httpclient/i';

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'template_redirect', array( __CLASS__, 'log_bot' ), 1 );
		add_filter( 'script_loader_tag', array( __CLASS__, 'no_optimize' ), 20, 2 );
		add_filter( 'rocket_delay_js_exclusions', array( __CLASS__, 'rocket_exclude' ) );
		add_filter( 'rocket_exclude_defer_js', array( __CLASS__, 'rocket_exclude' ) );
		add_filter( 'rocket_exclude_js', array( __CLASS__, 'rocket_exclude' ) );
		add_filter( 'litespeed_optm_js_defer_exc', array( __CLASS__, 'rocket_exclude' ) );
		add_filter( 'litespeed_optimize_js_excludes', array( __CLASS__, 'rocket_exclude' ) );
		add_filter( 'autoptimize_filter_js_exclude', array( __CLASS__, 'autoptimize_exclude' ) );
	}

	/** Pro+: count visits from AI and search crawlers (server side — bots don't run JavaScript). */
	public static function log_bot() {
		if ( ! ECT_License::has( 'proplus' ) || empty( $_SERVER['HTTP_USER_AGENT'] ) ) {
			return;
		}
		$bot = ECT_Source::bot( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) );
		if ( $bot ) {
			$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '/';
			ECT_DB::bot_hit( $bot, $path ? $path : '/' );
		}
	}

	public static function should_track() {
		if ( ! ect_get_option( 'tracking' ) ) {
			return false;
		}
		if ( ect_get_option( 'exclude_admins' ) && is_user_logged_in() && current_user_can( 'edit_posts' ) ) {
			return false;
		}
		return true;
	}

	public static function enqueue() {
		if ( ! self::should_track() || is_preview() || is_customize_preview() ) {
			return;
		}
		wp_enqueue_script( 'ect-tracker', ECT_URL . 'assets/js/ect-live.js', array(), ECT_VERSION, true );
		wp_add_inline_script(
			'ect-tracker',
			'window.ectCfg=' . wp_json_encode(
				array(
					'endpoint' => esc_url_raw( rest_url( 'ect/v1/hit' ) ),
					'interval' => 30,
					'dnt'      => (bool) ect_get_option( 'respect_dnt' ),
					'pro'      => ECT_License::has( 'pro' ),
					'events'   => ECT_License::has( 'proplus' ),
					'pt'       => self::page_type(),
					'forms'    => ECT_License::has( 'proplus' ) ? ECT_Reports::form_types() : array(),
				)
			) . ';',
			'before'
		);
	}

	private static function page_type() {
		if ( ! function_exists( 'is_product' ) ) {
			return '';
		}
		if ( is_product() ) {
			return 'product';
		}
		if ( is_checkout() && ! is_wc_endpoint_url( 'order-received' ) ) {
			return 'checkout';
		}
		if ( is_cart() ) {
			return 'cart';
		}
		return '';
	}

	/**
	 * Keep cache/optimization plugins (LiteSpeed, WP Rocket, Autoptimize, SG Optimizer…)
	 * from delaying the tracker until user interaction — otherwise live visitors show up late.
	 */
	public static function no_optimize( $tag, $handle ) {
		if ( 'ect-tracker' !== $handle && 'ect-tracker-js-before' !== $handle ) {
			return $tag;
		}
		return str_replace( '<script ', '<script data-no-optimize="1" data-no-defer="1" data-no-minify="1" data-cfasync="false" nowprocket ', $tag );
	}

	public static function rocket_exclude( $list ) {
		$list[] = 'ecomm-user-tracker/assets/js/ect-live.js';
		$list[] = 'ectCfg';
		return $list;
	}

	public static function autoptimize_exclude( $exclude ) {
		return $exclude . ', ecomm-user-tracker/assets/js/ect-live.js, ectCfg';
	}

	public static function routes() {
		register_rest_route(
			'ect/v1',
			'/hit',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'hit' ),
				'permission_callback' => '__return_true', // Public: cached pages cannot carry nonces. Input is strictly validated.
			)
		);
		register_rest_route(
			'ect/v1',
			'/live',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'live' ),
				'permission_callback' => function () {
					return current_user_can( 'manage_options' );
				},
			)
		);
	}

	public static function hit( WP_REST_Request $req ) {
		$resp = new WP_REST_Response( null, 204 );
		$resp->header( 'Cache-Control', 'no-store' );

		if ( ! ect_get_option( 'tracking' ) ) {
			return $resp;
		}
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		if ( '' === $ua || preg_match( self::BOT_PATTERN, $ua ) ) {
			return $resp;
		}

		$params = $req->get_json_params();
		if ( ! is_array( $params ) ) {
			$params = $req->get_body_params();
		}
		$vid = isset( $params['v'] ) ? (string) $params['v'] : '';
		if ( ! preg_match( '/^[a-zA-Z0-9]{16,40}$/', $vid ) ) {
			return $resp;
		}
		$page = isset( $params['p'] ) ? (string) $params['p'] : '';
		$page = substr( sanitize_text_field( wp_parse_url( $page, PHP_URL_PATH ) ?: '/' ), 0, 255 );

		// Visitor key rotates daily with a site secret, so it can't be linked across days.
		$salt    = wp_salt( 'auth' ) . gmdate( 'Y-m-d' );
		$visitor = substr( hash( 'sha256', $vid . $salt ), 0, 32 );

		$country = null;
		$geo     = function () use ( &$country ) {
			if ( null === $country ) {
				$country = ECT_Geo::country();
			}
			return $country;
		};
		ECT_DB::touch( $visitor, $page, $geo );

		// Pro: full visit history (pages, entry/exit, source, device).
		$sid = isset( $params['s'] ) ? (string) $params['s'] : '';
		if ( ECT_License::has( 'pro' ) && preg_match( '/^[a-zA-Z0-9]{16,40}$/', $sid ) ) {
			$type     = isset( $params['e'] ) ? (string) $params['e'] : 'hb';
			$e        = 'pv' === $type ? 'pv' : 'hb';
			$stable   = substr( hash( 'sha256', $vid . wp_salt( 'auth' ) ), 0, 32 );
			$skey     = self::session_key( $sid );
			$referrer = isset( $params['r'] ) ? esc_url_raw( substr( (string) $params['r'], 0, 500 ) ) : '';
			$q        = array();
			if ( isset( $params['q'] ) && is_array( $params['q'] ) ) {
				foreach ( array( 'utm_source', 'utm_medium', 'utm_campaign', 'gclid', 'gbraid', 'wbraid', 'msclkid', 'fbclid', 'ttclid' ) as $k ) {
					if ( isset( $params['q'][ $k ] ) && is_scalar( $params['q'][ $k ] ) ) {
						$q[ $k ] = substr( sanitize_text_field( (string) $params['q'][ $k ] ), 0, 100 );
					}
				}
			}
			$session_id = ECT_DB::track_session(
				$skey,
				$stable,
				$e,
				$page,
				function () use ( $referrer, $q, $ua, $geo ) {
					list( $channel, $source ) = ECT_Source::classify( $referrer, $q );
					return array(
						'channel' => $channel,
						'source'  => $source,
						'device'  => ECT_Source::device( $ua ),
						'country'  => call_user_func( $geo ),
						'browser'  => ECT_Source::browser( $ua ),
						'os'       => ECT_Source::os( $ua ),
						'campaign' => isset( $q['utm_campaign'] ) ? $q['utm_campaign'] : '',
					);
				}
			);
			if ( $session_id ) {
				self::events( $session_id, $type, $params, $page );
			}
		}
		return $resp;
	}

	/** Pro+: clicks, forms and store steps sent by the tracker. */
	private static function events( $session_id, $type, $params, $page ) {
		$label = isset( $params['l'] ) && is_scalar( $params['l'] ) ? sanitize_text_field( (string) $params['l'] ) : '';
		// Clicks, forms and store steps are Pro+.
		if ( ! ECT_License::has( 'proplus' ) ) {
			return;
		}
		switch ( $type ) {
			case 'pv':
				$pt = isset( $params['pt'] ) ? (string) $params['pt'] : '';
				if ( 'product' === $pt ) {
					ECT_DB::stage( $session_id, 1 );
					ECT_DB::event( $session_id, 'product_view', $label, $page );
				} elseif ( 'checkout' === $pt ) {
					ECT_DB::stage( $session_id, 3 );
					ECT_DB::event( $session_id, 'checkout', '', $page );
				}
				if ( ! empty( $params['f'] ) && is_array( $params['f'] ) ) {
					foreach ( array_slice( $params['f'], 0, 5 ) as $form ) {
						if ( is_scalar( $form ) ) {
							ECT_DB::event( $session_id, 'form_view', sanitize_text_field( (string) $form ), $page );
						}
					}
				}
				break;
			case 'ck':
			case 'fs':
			case 'fx':
				if ( '' !== $label ) {
					$map = array(
						'ck' => 'click',
						'fs' => 'form_start',
						'fx' => 'form_submit',
					);
					ECT_DB::event( $session_id, $map[ $type ], $label, $page );
				}
				break;
		}
	}

	/** Session cookie / id → stored key. Also used to link WooCommerce orders to visits. */
	public static function session_key( $sid ) {
		return substr( hash( 'sha256', 'ect-session|' . $sid . wp_salt( 'auth' ) ), 0, 32 );
	}

	public static function live( WP_REST_Request $req ) {
		$data = ECT_DB::live_stats();
		if ( $req->get_param( 'sections' ) && class_exists( 'ECT_Admin' ) ) {
			$data['sections'] = ECT_Admin::live_sections_html( (bool) $req->get_param( 'full' ) );
		}
		$resp = new WP_REST_Response( $data );
		$resp->header( 'Cache-Control', 'no-store' );
		return $resp;
	}
}
